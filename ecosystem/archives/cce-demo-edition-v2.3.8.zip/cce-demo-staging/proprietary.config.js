// CCE Demo Edition — All engines locked to dry run.
// Purchase the Local Edition to enable live trading.
// jamesthegiblet.gumroad.com/l/uptecy
module.exports = {
  execution: { dryRun: true },
  forex:  { dryRun: true },
  rme:    { dryRun: true },
  cme:    { dryRun: true },
  como:   { dryRun: true },
  egp:    { dryRun: true },
  grid:   { dryRun: true },
  mom:    { dryRun: true },
  brk:    { dryRun: true },
  lce:    { dryRun: true },
};

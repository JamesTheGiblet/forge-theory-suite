// config.js
// Production configuration

// --- Validate Circuit Breaker ---
const circuitBreakerRaw = process.env.CIRCUIT_BREAKER_PCT;
let circuitBreakerPct = -20;
if (circuitBreakerRaw !== undefined && circuitBreakerRaw !== '') {
  const parsed = parseFloat(circuitBreakerRaw);
  if (isNaN(parsed)) {
    throw new Error(`CRITICAL CONFIG ERROR: CIRCUIT_BREAKER_PCT must be a number. Received: "${circuitBreakerRaw}"`);
  }
  if (parsed > 0 || parsed < -100) {
    throw new Error(`CRITICAL CONFIG ERROR: CIRCUIT_BREAKER_PCT must be between -100 and 0. Received: ${parsed}`);
  }
  circuitBreakerPct = parsed;
}

// --- Validate Starting Capital ---
const capitalRaw = process.env.STARTING_CAPITAL;
let startingCapital = 300.0;
if (capitalRaw !== undefined && capitalRaw !== '') {
  const parsed = parseFloat(capitalRaw);
  if (isNaN(parsed)) {
    throw new Error(`CRITICAL CONFIG ERROR: STARTING_CAPITAL must be a number. Received: "${capitalRaw}"`);
  }
  if (parsed < 10) {
    throw new Error(`CRITICAL CONFIG ERROR: STARTING_CAPITAL must be at least $10. Received: ${parsed}`);
  }
  startingCapital = parsed;
}

// --- Validate API Credentials (only required when live trading) ---
if (process.env.CCE_DRY_RUN === 'false') {
  if (!process.env.KRAKEN_API_KEY || !process.env.KRAKEN_API_SECRET) {
    throw new Error('CRITICAL CONFIG ERROR: KRAKEN_API_KEY and KRAKEN_API_SECRET are required when not in dry run mode');
  }
}

// --- Export Config ---
const forexCapitalRaw = process.env.FOREX_STARTING_CAPITAL;
let forexStartingCapital = 300.0;
if (forexCapitalRaw !== undefined && forexCapitalRaw !== "") {
  const parsed = parseFloat(forexCapitalRaw);
  if (!isNaN(parsed) && parsed >= 10) forexStartingCapital = parsed;
}
const forexConfig = {
  enabled:         process.env.FOREX_ENABLED !== "false",
  pair:            "EURUSD=X",
  startingCapital: forexStartingCapital,
  intervalHours:   1,
  dryRun:          process.env.FOREX_DRY_RUN !== "false",
  period:   "5d",
  interval: "1h",
  fsm: {
    zScoreEntry:      -1.5,
    rsiEntry:         35,
    zScoreStop:       -3.0,
    maxHoldHours:     48,
    anchorPartialPct: 0.5,
    minPipProfit:     5
  }
};
module.exports = {
  system: {
    name: 'Cascade Compounding Engine',
    version: '2.1.0-stable',
    environment: process.env.CCE_ENVIRONMENT || 'production'
  },

  trading: {
    startingCapital,
    baseCurrency: process.env.BASE_CURRENCY || 'USD',
    maxPositionSizePct: 40,
    circuitBreakerPct,
    minTradeValue: 10.0  // Minimum $10 per trade
  },

  strategy: {
    // Allocations per state (Default / Fallback)
    allocations: {
      DORMANT:      { USDC: 1.0 },
      ACCUMULATION: { BTC: 0.25, USDC: 0.75 },
      ANCHOR:       { BTC: 0.5,  USDC: 0.5 },
      IGNITION:     { BTC: 1.0 },
      CASCADE_1:    { BTC: 0.8, ETH: 0.1, SOL: 0.1 },
      CASCADE_2:    { BTC: 0.6, ETH: 0.2, SOL: 0.2 },
      SPILLWAY:     { BTC: 0.9, USDC: 0.1 },
      EXTRACTION:   { USDC: 1.0 }
    },
    // Signal parameters
    signals: {
      smaFast: 10,
      smaMedium: 20,
      smaSlow: 50,
      lagShort: 3,
      lagLong: 7,
      bbWidthThreshold: 0.29,
      rocShort: -0.05,
      rocReversal: -0.10,
      rocBreakout: 0.15
    },
    // Sentiment weights
    sentiment: {
      fearGreedWeight: 0.7,
      lunarCrushWeight: 0.3
    },
    // Logic thresholds
    thresholds: {
      dormantSentimentOverride: 60,
      accumulationReadySentiment: 30,
      ignitionTakeProfitSentiment: 90,
      panicSentiment: 20,
      anchorFailureSentimentHigh: 45,
      anchorFailureSentimentLow: 40
    }
  },

  states: {
    minDormantDays: 30,             // Optimized: 30 days (was 45)
    cascadeFailureHours: 72,
    ignitionTrailingStopPct: 0.021, // Optimized: 2.1% stop (was 4.8%)
    zombieScoreThreshold: 70,
    minHoldDays: {
      IGNITION: 4,
      CASCADE_1: 21,
      CASCADE_2: 19,
      SPILLWAY: 14
    }
  },

  execution: {
    checkIntervalHours: 4,
    enableAutoTrading: true,
    dryRun: process.env.CCE_DRY_RUN !== 'false'  // Default to DRY RUN for safety
  },

  database: {
    path: './data/cce-production.db'
  },

  exchange: {
    name: 'kraken',
    apiKey: process.env.KRAKEN_API_KEY,
    apiSecret: process.env.KRAKEN_API_SECRET
  },

  notifications: {
    telegram: {
      enabled: process.env.TELEGRAM_ENABLED === 'true',
      botToken: process.env.TELEGRAM_BOT_TOKEN,
      chatId: process.env.TELEGRAM_CHAT_ID
    }
  },

  apis: {
    fearGreed: 'https://api.alternative.me/fng/',
    lunarCrushKey: process.env.LUNARCRUSH_API_KEY
  },

  monitoring: {
    healthCheckInterval: 300,
    dataRefreshInterval: 900
  },
  forex: forexConfig,   // ← ADD THIS
  rme: {
    enabled: true,
    dryRun: true,
    symbol: 'O',
    startingCapital: 300,
    intervalHours: 24,
    fsm: {}
  },
  cme: {
    enabled: true,
    dryRun: true,
    symbol: 'SPY',
    startingCapital: 300,
    intervalHours: 24,
    fsm: {}
  },
  str: {
    enabled:         false,  // Enable after Observer has 96+ observations (~24h)
    intervalMinutes: 60,     // Run analysis every hour
    totalCapital:    516     // Total capital under management ($391 crypto + $125 grid)
  },

  sentinel: {
    enabled:         true,
    intervalMinutes: 15,          // Runs alongside Observer
  },

  obs: {
    enabled:         true,   // Observer is always on — passive only
    intervalMinutes: 15,     // Observe every 15 minutes
    patternInterval: 96      // Run pattern analysis every 96 obs (~24h)
  },
  egp: {
    enabled:          true,  // Set to true when ready
    dryRun:           true,
    intervalMinutes:  10080,  // Weekly (7 days)

    // CBE data — update on meeting days
    cbeRate:          19.0,   // Current overnight deposit rate %
    prevCbeRate:      20.0,   // Previous rate (before last cut)
    inflation:        13.4,   // Latest CPI % (Feb 2026)
    prevInflation:    12.0,   // Prior month CPI %
    reserves:         52.7,   // Net international reserves $bn
    prevReserves:     47.1,   // Prior month reserves $bn
    cdsDelta:         0,      // CDS spread delta (manual watch)
    nextCbeMeeting:   '2026-04-02'
  },
  brk: {
    enabled:         true,   // Set to true when ready
    dryRun:          true,    // Set to false for live trading
    capitalUSDC:     100,     // $100 USDC
    pairs:           ['BTC/USDC', 'ETH/USDC', 'SOL/USDC'],
    intervalMinutes: 60,      // 1H cycle
    maxPositions:    2,
    riskPct:         0.02,
    maxDailyLoss:    0.03,
    bbPeriod:        20,
    bbStdDev:        2.0,
    squeezePct:      0.02,    // Band width < 2% = squeeze
    squeezeBars:     6,       // Min bars in squeeze before watching
    volumeMult:      1.8,     // Volume must be 1.8x average
    atrPeriod:       14,
    atrStopMult:     1.5,     // Tighter stop than momentum
    atrTpMult:       2.5,
    maxHoldBars:     6,       // 6 hours max hold
    feeRate:         0.0016
  },
  mom: {
    enabled:         true,   // Set to true when ready
    dryRun:          true,    // Set to false for live trading
    capitalUSDC:     125,     // $125 USDC (~£100 from S.E Crypto)
    pairs:           ['BTC/USDC', 'ETH/USDC', 'SOL/USDC'],
    intervalMinutes: 120,     // 2H cycle
    maxPositions:    2,       // Max concurrent positions
    riskPct:         0.02,    // 2% risk per trade
    maxDailyLoss:    0.03,    // 3% max daily loss circuit breaker
    cooldownCandles: 2,       // Candles to wait after a loss
    emaFast:         9,
    emaSlow:         21,
    emaTrend:        50,
    rsiPeriod:       14,
    rsiEntry:        55,
    volumeMult:      1.5,
    atrPeriod:       14,
    atrStopMult:     2.0,
    atrTpMult:       3.0,
    atrTrailMult:    1.5,
    maxHoldCandles:  3,
    feeRate:         0.0016
  },
  grid: {
    enabled:      true,   // Set to true when ready to run grid
    dryRun:       true,    // Set to false for live trading
    capitalUSDC:  125,     // $125 USDC (~£100)
    spacing:      0.01,    // 1% between levels
    levels:       10,      // Total grid levels
    intervalMinutes: 5,    // Check every 5 minutes
    makerFee:     0.0016,  // Kraken maker fee
    takerFee:     0.0026,  // Kraken taker fee
    stopLossPct:  0.15,    // Stop if BTC drops 15% from centre
    recentrePct:  0.05,    // Recentre if price drifts 5%
    fsm:          {}
  },
  como: {
    enabled: true,
    dryRun: true,
    startingCapital: 300,
    intervalHours: 24,
    fsm: {}
  },
  lce: {
    enabled:         true,
    dryRun:          true,
    capitalUSDC:     100,
    intervalMinutes: 5,
    watchlist:       ['BTC/USDT', 'ETH/USDT', 'SOL/USDT'],
    minLiqUsd5m:     5_000_000,
    minLiqUsd15m:    20_000_000,
    minOiDropPct:    1.5,
    minMomentumPct:  0.3,
    rsiMin:          25,
    rsiMax:          75,
    stopLossPct:     0.8,
    takeProfitPct:   1.6,
    trailingStopPct: 0.5,
    maxDailyLossPct: 3.0,
    tradeWindowMs:   1_800_000,
  },
};

================================================================
   CASCADE COMPOUNDING ENGINE (CCE) - WINDOWS EDITION
================================================================

Thank you for downloading CCE.

IMPORTANT:
You must EXTRACT this zip file before running it.
Do not try to run "start.bat" from inside the zip viewer.

----------------------------------------------------------------
   HOW TO INSTALL
----------------------------------------------------------------
1. Right-click this zip file.
2. Select "Extract All...".
3. Choose a location (like your Desktop) and click Extract.
4. Open the new folder that was created.

----------------------------------------------------------------
   HOW TO START
----------------------------------------------------------------
1. Double-click the "start.bat" file.

   (If Windows shows a "PC protected" warning, click 
   "More info" -> "Run anyway". This happens because we are 
   an independent developer, not Microsoft.)

2. FIRST RUN SETUP:
   - The black window will tell you it's creating a config file.
   - Notepad will open automatically.
   - Paste your Licence Key and API Keys into this file.
   - Save and Close Notepad.

3. The engine will now start.
   - Keep the black window open to keep the bot running.
   - You can minimize it, but don't close it.

----------------------------------------------------------------
   THE DASHBOARD
----------------------------------------------------------------
Once the engine is running, open your web browser and go to:

   http://localhost:3000

This is your mission control. You can see what the bot is doing,
check your portfolio, and use the Emergency Stop if needed.

Happy Compounding.
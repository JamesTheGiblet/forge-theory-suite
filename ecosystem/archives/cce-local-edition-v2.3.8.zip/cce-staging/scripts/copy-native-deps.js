const fs = require('fs');
const path = require('path');

console.log('🔧 Manual Native Dependency Copier');

const rootDir = path.join(__dirname, '..');
const distDir = path.join(rootDir, 'dist');

// 1. Ensure dist exists
if (!fs.existsSync(distDir)) {
    console.error('❌ dist/ folder not found. Run "npm run build-win" first.');
    process.exit(1);
}

// 2. Look for sqlite3 binding
console.log('🔍 Searching for sqlite3 binary...');
const sqliteBase = path.join(rootDir, 'node_modules', 'sqlite3', 'lib', 'binding');

if (!fs.existsSync(sqliteBase)) {
    console.error('❌ Could not find sqlite3 bindings folder.');
    console.error('   Try running: npm install sqlite3 --build-from-source');
    process.exit(1);
}

const folders = fs.readdirSync(sqliteBase);
if (folders.length === 0) {
    console.error('❌ sqlite3 bindings folder is empty.');
    process.exit(1);
}

// 3. Copy the first valid binding found
const bindingFolder = path.join(sqliteBase, folders[0]);
const sourceFile = path.join(bindingFolder, 'node_sqlite3.node');
const targetFile = path.join(distDir, 'node_sqlite3.node');

if (fs.existsSync(sourceFile)) {
    fs.copyFileSync(sourceFile, targetFile);
    console.log(`✅ Copied: ${folders[0]}/node_sqlite3.node`);
    console.log(`   To:     dist/node_sqlite3.node`);
} else {
    console.error(`❌ File not found: ${sourceFile}`);
}
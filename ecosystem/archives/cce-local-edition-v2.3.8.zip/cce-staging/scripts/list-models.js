const axios = require('axios');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

async function run() {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    console.error('❌ No GEMINI_API_KEY found in .env');
    return;
  }

  console.log('📡 Fetching available Gemini models...');
  try {
    const response = await axios.get(`https://generativelanguage.googleapis.com/v1beta/models?key=${key}`);
    const models = response.data.models || [];
    
    console.log(`✅ Found ${models.length} models. These support generateContent:`);
    models.forEach(m => {
      if (m.supportedGenerationMethods && m.supportedGenerationMethods.includes('generateContent')) {
        console.log(`   - ${m.name.replace('models/', '')}`);
      }
    });
  } catch (e) {
    console.error('❌ Failed to list models:', e.message);
    if (e.response) console.error('   Details:', JSON.stringify(e.response.data, null, 2));
  }
}

run();
const path = require('path');
const fs = require('fs');

console.log('🔍 Verifying Environment Paths...');

const isPkg = typeof process.pkg !== 'undefined';
const execPath = process.execPath;
// External path for writing logs/data (outside the snapshot)
const basePath = isPkg ? path.dirname(execPath) : path.join(__dirname, '..');
// Internal path for checking bundled files (inside the snapshot/source)
const projectRoot = path.join(__dirname, '..');

console.log(`   Mode:      ${isPkg ? 'PACKAGED (.exe)' : 'SOURCE (node)'}`);
console.log(`   Base Path: ${basePath}`);

const logDir = path.join(basePath, 'logs');
const dataDir = path.join(basePath, 'data');

console.log(`   Logs Dir:  ${logDir}`);
console.log(`   Data Dir:  ${dataDir}`);

// 1. Verify Bundled Files (Snapshot Check)
if (isPkg) {
    const requiredFiles = ['src/strategy.js', 'src/storage.js', 'config.js'];
    console.log('\n🔍 Verifying Bundled Files...');
    requiredFiles.forEach(file => {
        const filePath = path.join(projectRoot, file);
        const exists = fs.existsSync(filePath);
        console.log(`   ${exists ? '✅' : '❌'} ${file}`);
    });
}

// 2. Logs Dir Write Test
try {
    if (!fs.existsSync(logDir)) {
        console.log('   Creating logs dir...');
        fs.mkdirSync(logDir, { recursive: true });
    }
    const testFile = path.join(logDir, 'path_test.txt');
    fs.writeFileSync(testFile, `Write test successful at ${new Date().toISOString()}`);
    console.log('✅ Logs Dir Write Test: SUCCESS');
    fs.unlinkSync(testFile);
} catch (e) {
    console.error('❌ Logs Dir Write Test: FAILED');
    console.error(e);
}

// 3. Data Dir Write Test
try {
    if (!fs.existsSync(dataDir)) {
        console.log('   Creating data dir...');
        fs.mkdirSync(dataDir, { recursive: true });
    }
    const testFile = path.join(dataDir, 'path_test.txt');
    fs.writeFileSync(testFile, `Write test successful at ${new Date().toISOString()}`);
    console.log('✅ Data Dir Write Test: SUCCESS');
    fs.unlinkSync(testFile);
} catch (e) {
    console.error('❌ Data Dir Write Test: FAILED');
    console.error(e);
}

if (isPkg) {
    console.log('\nPress Enter to exit...');
    process.stdin.resume();
    process.stdin.on('data', process.exit.bind(process, 0));
}
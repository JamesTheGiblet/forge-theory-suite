const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('📦 Building Windows Installer Package...');

// 1. Ensure dist directory exists
const rootDir = path.join(__dirname, '..');
const distDir = path.join(rootDir, 'dist');

if (fs.existsSync(distDir)) {
    fs.rmSync(distDir, { recursive: true, force: true });
}
fs.mkdirSync(distDir);

// 2. Run pkg to create the executable
console.log('   Compiling executable (this may take a moment)...');
try {
    // Compiles for Node 18 on Windows x64
    execSync('npx pkg . --targets node18-win-x64 --output dist/cce-engine.exe --compress GZip', { 
        stdio: 'inherit',
        cwd: rootDir,
        env: { ...process.env, NODE_OPTIONS: '--max-old-space-size=4096' }
    });

    console.log('   Compiling restore tool...');
    execSync('npx pkg scripts/restore-backup.js --targets node18-win-x64 --output dist/restore.exe --compress GZip', {
        stdio: 'inherit',
        cwd: rootDir,
        env: { ...process.env, NODE_OPTIONS: '--max-old-space-size=4096' }
    });

} catch (e) {
    console.error('❌ Build failed. Ensure you have run "npm install" first.');
    process.exit(1);
}

// 3. Copy essential files
console.log('   Copying setup files...');
const filesToCopy = ['.env.example', 'start.bat', 'README_WINDOWS.txt', 'Troubleshooting_Windows.md', 'reset-demo.bat'];

filesToCopy.forEach(file => {
    const srcPath = path.join(rootDir, file);
    if (fs.existsSync(srcPath)) {
        fs.copyFileSync(srcPath, path.join(distDir, file));
    } else {
        console.log(`   ⚠️  Warning: Could not find ${file} to copy.`);
    }
});

// 4. Create empty structure for data/logs so the user doesn't get errors
fs.mkdirSync(path.join(distDir, 'data'));
fs.mkdirSync(path.join(distDir, 'logs'));

// 5. Handle Native Modules (SQLite3)
console.log('   Handling native modules (sqlite3)...');
try {
    // Find the sqlite3 binding file. It's usually in lib/binding/node-vXX-win32-x64/
    const sqliteBase = path.join(rootDir, 'node_modules', 'sqlite3', 'lib', 'binding');
    if (fs.existsSync(sqliteBase)) {
        const folders = fs.readdirSync(sqliteBase);
        // Just grab the first folder found (usually only one exists matching current node version)
        if (folders.length > 0) {
            const bindingFolder = path.join(sqliteBase, folders[0]);
            const sourceFile = path.join(bindingFolder, 'node_sqlite3.node');
            if (fs.existsSync(sourceFile)) {
                fs.copyFileSync(sourceFile, path.join(distDir, 'node_sqlite3.node'));
                console.log(`   ✅ Copied sqlite3 binding: ${folders[0]}`);
            }
        }
    }
} catch (e) {
    console.log('   ⚠️  Could not auto-copy sqlite3 binding. You may need to copy node_sqlite3.node manually.');
}

// 6. Zip it up (Windows only)
console.log('   Creating release zip...');
const zipName = 'cce-windows-release.zip';
const zipPath = path.join(rootDir, zipName);
if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

try {
    // Compress the CONTENTS of dist, not the dist folder itself
    execSync(`powershell Compress-Archive -Path "dist\\*" -DestinationPath "${zipName}"`, {
        stdio: 'inherit',
        cwd: rootDir
    });
    console.log(`\n📦 ZIP CREATED: ${zipName}`);
} catch (e) {
    console.log('   (Could not auto-zip. Please zip the "dist" folder manually.)');
}

console.log('\n✅ Build Complete!');
console.log(`   Folder: ${distDir}`);
console.log(`   Zip:    ${zipName}`);
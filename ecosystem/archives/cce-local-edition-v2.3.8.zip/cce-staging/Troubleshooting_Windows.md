# Windows Troubleshooting Guide

**"Computer says no?" Here is how to fix it.**

Windows tries very hard to protect you. Sometimes it protects you from software you actually want to run. Here are the common issues and how to solve them in 30 seconds.

---

### 1. The Blue "Windows protected your PC" Popup

**Symptom:** You double-click `start.bat` and get a blue window preventing the app from starting.
**Why:** We are an independent developer, not Microsoft. We haven't paid thousands of dollars for a corporate digital certificate, so Windows treats us as "Unknown."
**Fix:**

1. Click **"More info"** (the underlined text).
2. Click the **"Run anyway"** button that appears.
3. *You only have to do this once.*

### 2. Anti-Virus Deleted My File

**Symptom:** `cce-engine.exe` disappears, or you get a "Threat Detected" notification.
**Why:** The engine is built with a tool called `pkg`. Sometimes, aggressive anti-virus software (like McAfee, Norton, or Windows Defender) sees a new `.exe` file it doesn't recognize and assumes it's a virus. This is called a "False Positive."
**Fix:**

1. Open your Anti-Virus dashboard.
2. Look for **"Quarantine"** or **"Protection History"**.
3. Find the file `cce-engine.exe` and select **"Restore"** or **"Allow"**.
4. **Pro Tip:** Add the `cce-production` folder to your Anti-Virus "Exclusions" or "Whitelist" to prevent this from happening again.

### 3. Dashboard Won't Load (localhost:3000)

**Symptom:** The black window says the dashboard is running, but your browser says "Unable to connect."
**Why:** Windows Firewall might be blocking the connection.
**Fix:**

1. Press the **Windows Key** and type "Firewall".
2. Select **"Allow an app through Windows Firewall"**.
3. Click **"Change settings"** (top right).
4. Look for `cce-engine` or `Node.js JavaScript Runtime` in the list.
5. Check the boxes for both **Private** and **Public**.
6. Click **OK** and refresh the page.

### 4. The Black Window Closes Immediately

**Symptom:** You double-click `start.bat`, a black box flashes, and then disappears instantly.
**Why:** The program crashed, usually because it can't find its files.
**Fix:**

1. **Did you unzip it?** This is the #1 cause. You cannot run the bot from inside the zip file. Right-click the zip file and select **"Extract All"**.
2. **Are you running start.bat?** Do not run `cce-engine.exe` directly. The batch file handles the setup and keeps the window open if there is an error.
3. **Check the logs:** Open the `logs` folder and look for a text file. It will tell you what went wrong.

### 5. "Edit with Notepad" isn't working

**Symptom:** The setup script tries to open your config file, but nothing happens.
**Fix:**

1. Right-click the file named `.env`.
2. Select **"Open with"**.
3. Choose **Notepad**.

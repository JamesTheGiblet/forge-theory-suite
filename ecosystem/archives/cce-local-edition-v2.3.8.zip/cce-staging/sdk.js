// sdk.js
// Public API for integrating CCE into other applications

'use strict';

const CCEEngine = require('./src/cce-engine');
const { CCEStateMachine, CCERebalancer, TechnicalSignals, SentimentSignals } = require('./src/strategy');
const MarketDataFeed = require('./src/data-feed');
const ExchangeConnector = require('./src/exchange-connector');
const StorageManager = require('./src/storage');
const { version, name } = require('./package.json');

/**
 * Create and return a configured CCE engine instance.
 * This is the recommended entry point for SDK consumers.
 *
 * @param {object} config - Full CCE configuration object. See config.js for shape.
 * @returns {CCEEngine} Configured engine instance, ready to call .start()
 */
function createEngine(config) {
  if (!config || typeof config !== 'object') {
    throw new Error('CCE SDK: createEngine() requires a valid config object');
  }
  return new CCEEngine(config);
}

/**
 * Default config shape for reference.
 * Do not use this directly in production — construct your own config
 * with appropriate environment variables and secrets.
 */
const defaultConfigShape = {
  system: { name: String, version: String, environment: String },
  trading: { startingCapital: Number, baseCurrency: String, maxPositionSizePct: Number, circuitBreakerPct: Number, minTradeValue: Number },
  execution: { checkIntervalHours: Number, enableAutoTrading: Boolean, dryRun: Boolean },
  exchange: { name: String, apiKey: String, apiSecret: String }
};

module.exports = {
  // SDK metadata
  version,
  name,

  // Factory — recommended entry point
  createEngine,

  // Core engine class — use createEngine() unless you need direct instantiation
  Engine: CCEEngine,

  // Strategy components
  StateMachine: CCEStateMachine,
  Rebalancer: CCERebalancer,
  Signals: {
    Technical: TechnicalSignals,
    Sentiment: SentimentSignals
  },

  // Infrastructure classes
  DataFeed: MarketDataFeed,
  Exchange: ExchangeConnector,
  Storage: StorageManager,

  // Config reference shape — do not use the live config instance directly
  defaultConfigShape
};
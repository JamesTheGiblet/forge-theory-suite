// src/egp-strategy.js
// S.E EGP — USD/EGP Regime Classification Engine
// Policy-driven managed float strategy
// Signals: CBE rate, CPI, reserves, Brent crude, CDS spread

'use strict';

class EGPStrategy {
  // Regime thresholds
  static ACCUMULATE_THRESHOLD =  2;  // score >= +2 → short USD/EGP
  static FADE_THRESHOLD       = -2;  // score <= -2 → long USD/EGP
  static BRENT_PRESSURE       = 85;  // Brent > $85 = EGP pressure

  // ============================================================================
  // COMPOSITE SCORE
  // Each signal: +1 (bullish EGP), 0 (neutral), -1 (bearish EGP)
  // ============================================================================

  static scoreSignals(inputs) {
    const scores = {};

    // 1. CBE rate delta — cutting = bullish EGP (controlled easing)
    //    but check divergence flag first
    if (inputs.cbe_rate_delta < 0) {
      scores.cbe_rate = +1; // cutting = accumulation signal
    } else if (inputs.cbe_rate_delta > 0) {
      scores.cbe_rate = -1; // hiking = pressure signal
    } else {
      scores.cbe_rate = 0;
    }

    // 2. Inflation delta — rising inflation = bearish EGP
    if (inputs.inflation_delta > 0) {
      scores.inflation = -1;
    } else if (inputs.inflation_delta < 0) {
      scores.inflation = +1;
    } else {
      scores.inflation = 0;
    }

    // 3. Reserves delta — rising = stable, falling = pressure
    if (inputs.reserves_delta > 0) {
      scores.reserves = +1;
    } else if (inputs.reserves_delta < 0) {
      scores.reserves = -1;
    } else {
      scores.reserves = 0;
    }

    // 4. Brent crude level — above $85 = EGP pressure
    if (inputs.brent_level > this.BRENT_PRESSURE) {
      scores.brent = -1;
    } else if (inputs.brent_level < 70) {
      scores.brent = +1;
    } else {
      scores.brent = 0;
    }

    // 5. CDS spread delta — rising = devaluation risk
    if (inputs.cds_delta > 0) {
      scores.cds = -1;
    } else if (inputs.cds_delta < 0) {
      scores.cds = +1;
    } else {
      scores.cds = 0;
    }

    const composite = Object.values(scores).reduce((a, b) => a + b, 0);

    return { scores, composite };
  }

  // ============================================================================
  // DIVERGENCE FLAG
  // Rate cutting WHILE inflation rising = most dangerous regime
  // Overrides composite score
  // ============================================================================

  static checkDivergence(inputs) {
    return inputs.cbe_rate_delta < -0.5 && inputs.inflation_delta > 0.5;
  }

  // ============================================================================
  // STATE DETERMINATION
  // ============================================================================

  static determineState(inputs) {
    const divergence       = this.checkDivergence(inputs);
    const { scores, composite } = this.scoreSignals(inputs);

    let state, reason;

    if (divergence) {
      state  = 'CAUTION';
      reason = 'Policy divergence — CBE cutting while inflation rising. Exit all positions.';
    } else if (composite >= this.ACCUMULATE_THRESHOLD) {
      state  = 'ACCUMULATE';
      reason = `Score +${composite} — CBE controlled easing, EGP strengthening conditions.`;
    } else if (composite <= this.FADE_THRESHOLD) {
      state  = 'FADE';
      reason = `Score ${composite} — External pressure, EGP devaluation risk elevated.`;
    } else {
      state  = 'DORMANT';
      reason = `Score ${composite} — Mixed signals, no clear regime. Hold cash.`;
    }

    return {
      state,
      reason,
      composite,
      divergence_flag: divergence,
      scores
    };
  }

  // ============================================================================
  // STATE DESCRIPTIONS
  // ============================================================================

  static describe(state) {
    switch (state) {
      case 'ACCUMULATE':
        return 'CBE controlled easing — short USD/EGP (buy EGP)';
      case 'FADE':
        return 'EGP devaluation surge — long USD/EGP (short EGP)';
      case 'CAUTION':
        return 'Policy divergence active — exit all, monitor for resolution';
      default:
        return 'Mixed signals — holding cash, awaiting regime clarity';
    }
  }
}

module.exports = EGPStrategy;

// src/str-strategy.js
// O.E Strategist — Pattern Recognition and Prediction Engine
// Reads Observer data and generates insights, predictions, recommendations.
// PASSIVE ONLY — never makes decisions, never affects engines.

'use strict';

class STRPatternEngine {

  // ============================================================================
  // STATE TRANSITION PREDICTIONS
  // ============================================================================

  // Predict when each engine is likely to transition next
  predictTransitions(observations, transitions) {
    const predictions = {};
    const engines = ['crypto', 'forex', 'reit', 'stocks', 'como', 'grid'];

    engines.forEach(engine => {
      const engineTransitions = transitions.filter(t => t.engine === engine);
      if (!engineTransitions.length) {
        predictions[engine] = {
          currentState: this._getLatestState(observations, engine),
          prediction:   'Insufficient transition history',
          confidence:   0,
          dataPoints:   0
        };
        return;
      }

      const currentState = this._getLatestState(observations, engine);
      const latestObs    = observations[observations.length - 1];

      // Find similar historical conditions
      const similar = this._findSimilarConditions(observations, latestObs, engine);
      const avgDaysInState = this._avgDaysInState(observations, engine, currentState);
      const currentDaysInState = this._currentDaysInState(observations, engine, currentState);

      // Calculate confidence based on data volume
      const confidence = Math.min(
        Math.round((engineTransitions.length / 10) * 100),
        95
      );

      let prediction = '';
      let timeframe  = '';

      if (avgDaysInState > 0 && currentDaysInState > 0) {
        const remaining = avgDaysInState - currentDaysInState;
        if (remaining <= 0) {
          prediction = `Overdue for transition — avg ${avgDaysInState.toFixed(1)}d in ${currentState}`;
          timeframe  = 'Imminent';
        } else {
          prediction = `~${remaining.toFixed(1)} days remaining in ${currentState}`;
          timeframe  = `${remaining.toFixed(0)}d`;
        }
      } else {
        prediction = `${currentState} — monitoring for transition signals`;
        timeframe  = 'Unknown';
      }

      predictions[engine] = {
        currentState,
        daysInState:     +currentDaysInState.toFixed(1),
        avgDaysInState:  +avgDaysInState.toFixed(1),
        prediction,
        timeframe,
        confidence,
        transitionCount: engineTransitions.length,
        similarConditions: similar.length,
        dataPoints:      observations.length
      };
    });

    return predictions;
  }

  // ============================================================================
  // MARKET REGIME ANALYSIS
  // ============================================================================

  analyseCurrentRegime(observations) {
    if (!observations.length) return null;

    const recent  = observations.slice(-96); // last 24h
    const latest  = observations[observations.length - 1];

    const avgFG   = this._avg(recent, 'fear_greed');
    const avgVIX  = this._avg(recent, 'vix');
    const avgBTC  = this._avg(recent, 'btc_price');
    const fgTrend = this._trend(recent, 'fear_greed');
    const btcTrend = this._trend(recent, 'btc_price');
    const vixTrend = this._trend(recent, 'vix');

    // Classify regime
    let regime = '';
    let description = '';
    let outlook = '';

    if (avgFG <= 20) {
      regime = 'EXTREME FEAR';
      description = 'Market in extreme fear — capital preservation optimal';
      outlook = fgTrend > 0 ? 'Improving — fear easing' : 'Deteriorating — fear deepening';
    } else if (avgFG <= 40) {
      regime = 'FEAR';
      description = 'Market fearful — defensive positioning appropriate';
      outlook = fgTrend > 0 ? 'Recovering — watch for accumulation signals' : 'Weakening — maintain defensive posture';
    } else if (avgFG <= 60) {
      regime = 'NEUTRAL';
      description = 'Market neutral — transitional phase';
      outlook = fgTrend > 0 ? 'Building momentum' : 'Losing momentum';
    } else if (avgFG <= 80) {
      regime = 'GREED';
      description = 'Market greedy — momentum favourable but risk rising';
      outlook = fgTrend > 0 ? 'Approaching extreme — consider partial exits' : 'Cooling — monitor closely';
    } else {
      regime = 'EXTREME GREED';
      description = 'Market extremely greedy — high risk of reversal';
      outlook = 'Caution — extraction signals likely imminent';
    }

    return {
      regime,
      description,
      outlook,
      avgFearGreed:  +avgFG.toFixed(1),
      currentFG:     latest.fear_greed,
      fgTrend:       fgTrend > 0 ? 'RISING' : fgTrend < 0 ? 'FALLING' : 'FLAT',
      avgVIX:        +avgVIX.toFixed(2),
      currentVIX:    latest.vix,
      vixTrend:      vixTrend > 0 ? 'RISING' : vixTrend < 0 ? 'FALLING' : 'FLAT',
      btcPrice:      latest.btc_price,
      btcTrend:      btcTrend > 0 ? 'RISING' : btcTrend < 0 ? 'FALLING' : 'FLAT',
      obsCount:      observations.length
    };
  }

  // ============================================================================
  // ALLOCATION RECOMMENDATIONS
  // ============================================================================

  recommendAllocations(observations, transitions, totalCapital = 1000) {
    if (!observations.length) return null;

    const latest   = observations[observations.length - 1];
    const regime   = this.analyseCurrentRegime(observations);
    const engines  = ['crypto', 'forex', 'reit', 'stocks', 'como', 'grid'];

    // Base scores per engine based on current state and market conditions
    const scores = {};

    engines.forEach(engine => {
      const state = this._getLatestState(observations, engine);
      let score = 50; // baseline

      // Active state = higher score
      const activeStates = [
        'ACCUMULATION', 'ANCHOR', 'IGNITION', 'CASCADE_1', 'CASCADE_2',
        'SPILLWAY', 'WATCHING', 'ENTERING', 'HOLDING', 'PRIMED',
        'ROTATING', 'CASCADING', 'ACTIVE', 'OBSERVE'
      ];
      if (activeStates.includes(state)) score += 25;
      if (state === 'DORMANT')          score -= 10;

      // Market regime adjustments
      if (regime) {
        if (engine === 'grid') {
          // Grid works in any market — boost in fear
          if (regime.avgFearGreed <= 30) score += 15;
        }
        if (engine === 'crypto') {
          // Crypto needs favourable sentiment
          if (regime.avgFearGreed <= 20) score -= 20;
          if (regime.avgFearGreed >= 50) score += 15;
        }
        if (engine === 'stocks') {
          // Stocks need low VIX
          if (regime.avgVIX >= 25) score -= 20;
          if (regime.avgVIX <= 18) score += 20;
        }
        if (engine === 'reit') {
          // REIT likes rate cuts
          if (latest.fed_rate > 0 && latest.treasury_yield > 0) {
            if (latest.fed_rate < 4.0) score += 15;
          }
        }
      }

      scores[engine] = Math.max(0, Math.min(100, score));
    });

    // Normalise scores to allocations
    const totalScore = Object.values(scores).reduce((a, b) => a + b, 0);
    const allocations = {};
    engines.forEach(engine => {
      allocations[engine] = +(totalCapital * scores[engine] / totalScore).toFixed(2);
    });

    return {
      allocations,
      scores,
      regime:      regime?.regime,
      totalCapital,
      rationale:   this._buildRationale(scores, regime, latest)
    };
  }

  // ============================================================================
  // ANOMALY DETECTION
  // ============================================================================

  detectAnomalies(observations) {
    if (observations.length < 10) return [];

    const anomalies = [];
    const latest  = observations[observations.length - 1];
    const recent  = observations.slice(-48); // last 12h

    // BTC price anomaly — sudden large move
    const btcPrices = recent.map(o => o.btc_price).filter(Boolean);
    if (btcPrices.length >= 2) {
      const btcChange = (btcPrices[btcPrices.length-1] - btcPrices[0]) / btcPrices[0] * 100;
      if (Math.abs(btcChange) > 5) {
        anomalies.push({
          type:        'PRICE_MOVE',
          severity:    Math.abs(btcChange) > 10 ? 'HIGH' : 'MEDIUM',
          description: `BTC moved ${btcChange > 0 ? '+' : ''}${btcChange.toFixed(1)}% in 12 hours`,
          value:       btcChange,
          engine:      'crypto'
        });
      }
    }

    // VIX spike anomaly
    const vixValues = recent.map(o => o.vix).filter(Boolean);
    if (vixValues.length >= 2) {
      const vixChange = vixValues[vixValues.length-1] - vixValues[0];
      if (vixChange > 5) {
        anomalies.push({
          type:        'VIX_SPIKE',
          severity:    vixChange > 10 ? 'HIGH' : 'MEDIUM',
          description: `VIX spiked +${vixChange.toFixed(1)} in 12 hours`,
          value:       vixChange,
          engine:      'stocks'
        });
      }
    }

    // F&G rapid change
    const fgValues = recent.map(o => o.fear_greed).filter(o => o > 0);
    if (fgValues.length >= 2) {
      const fgChange = fgValues[fgValues.length-1] - fgValues[0];
      if (Math.abs(fgChange) > 15) {
        anomalies.push({
          type:        'SENTIMENT_SHIFT',
          severity:    Math.abs(fgChange) > 25 ? 'HIGH' : 'MEDIUM',
          description: `Fear & Greed shifted ${fgChange > 0 ? '+' : ''}${fgChange} in 12 hours`,
          value:       fgChange,
          engine:      'crypto'
        });
      }
    }

    // Grid no cycles but wide range
    if (latest.grid_cycles === 0 && latest.grid_state === 'ACTIVE') {
      const btcHigh = Math.max(...recent.map(o => o.btc_price || 0));
      const btcLow  = Math.min(...recent.map(o => o.btc_price || Infinity));
      const range   = btcHigh - btcLow;
      if (range > 2000) {
        anomalies.push({
          type:        'GRID_NO_CYCLES',
          severity:    'LOW',
          description: `Grid active with $${Math.round(range)} range but 0 completed cycles — check grid levels`,
          value:       range,
          engine:      'grid'
        });
      }
    }

    return anomalies;
  }

  // ============================================================================
  // PLAIN ENGLISH BRIEFING
  // ============================================================================

  generateBriefing(observations, transitions, totalCapital) {
    if (!observations.length) return 'No observation data available yet.';

    const regime      = this.analyseCurrentRegime(observations);
    const predictions = this.predictTransitions(observations, transitions);
    const allocRec    = this.recommendAllocations(observations, transitions, totalCapital);
    const anomalies   = this.detectAnomalies(observations);
    const latest      = observations[observations.length - 1];

    const lines = [];

    lines.push(`📊 PLATFORM BRIEFING — ${new Date().toLocaleString()}`);
    lines.push(`Observations: ${observations.length} | Transitions: ${transitions.length}`);
    lines.push('');

    // Regime
    lines.push(`🌡️ MARKET REGIME: ${regime?.regime}`);
    lines.push(regime?.description || '');
    lines.push(`Outlook: ${regime?.outlook || '--'}`);
    lines.push(`F&G: ${regime?.currentFG} (${regime?.fgTrend}) | VIX: ${regime?.currentVIX} (${regime?.vixTrend})`);
    lines.push('');

    // Anomalies
    if (anomalies.length) {
      lines.push('⚠️ ANOMALIES DETECTED:');
      anomalies.forEach(a => lines.push(`  [${a.severity}] ${a.description}`));
      lines.push('');
    }

    // Predictions
    lines.push('🔮 ENGINE PREDICTIONS:');
    Object.entries(predictions).forEach(([engine, pred]) => {
      lines.push(`  ${engine.toUpperCase()}: ${pred.currentState} — ${pred.prediction}`);
    });
    lines.push('');

    // Allocation recommendation
    if (allocRec) {
      lines.push('💰 RECOMMENDED ALLOCATIONS:');
      Object.entries(allocRec.allocations).forEach(([engine, amt]) => {
        lines.push(`  ${engine.toUpperCase()}: $${amt}`);
      });
    }

    return lines.join('\n');
  }

  // ============================================================================
  // HELPERS
  // ============================================================================

  _getLatestState(observations, engine) {
    const key = `${engine}_state`;
    for (let i = observations.length - 1; i >= 0; i--) {
      if (observations[i][key] && observations[i][key] !== 'UNKNOWN') {
        return observations[i][key];
      }
    }
    return 'UNKNOWN';
  }

  _avgDaysInState(observations, engine, state) {
    const key = `${engine}_state`;
    let totalDays = 0;
    let count     = 0;
    let start     = null;

    observations.forEach((obs, i) => {
      if (obs[key] === state) {
        if (!start) start = new Date(obs.timestamp);
      } else {
        if (start) {
          const days = (new Date(obs.timestamp) - start) / 86400000;
          totalDays += days;
          count++;
          start = null;
        }
      }
    });

    return count > 0 ? totalDays / count : 0;
  }

  _currentDaysInState(observations, engine, state) {
    const key = `${engine}_state`;
    for (let i = observations.length - 1; i >= 0; i--) {
      if (observations[i][key] !== state) {
        const sinceChange = new Date(observations[observations.length-1].timestamp) - new Date(observations[i].timestamp);
        return sinceChange / 86400000;
      }
    }
    return 0;
  }

  _findSimilarConditions(observations, latest, engine) {
    if (!latest) return [];
    return observations.filter(obs => {
      const fgSimilar  = Math.abs((obs.fear_greed || 0) - (latest.fear_greed || 0)) <= 5;
      const vixSimilar = Math.abs((obs.vix || 0) - (latest.vix || 0)) <= 3;
      return fgSimilar && vixSimilar;
    });
  }

  _avg(arr, key) {
    const vals = arr.map(o => o[key]).filter(v => v > 0);
    return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
  }

  _trend(arr, key) {
    const vals = arr.map(o => o[key]).filter(v => v > 0);
    if (vals.length < 2) return 0;
    const first = vals.slice(0, Math.floor(vals.length / 2));
    const last  = vals.slice(Math.floor(vals.length / 2));
    const avgFirst = first.reduce((a, b) => a + b, 0) / first.length;
    const avgLast  = last.reduce((a, b) => a + b, 0) / last.length;
    return avgLast - avgFirst;
  }

  _buildRationale(scores, regime, latest) {
    const top = Object.entries(scores).sort((a, b) => b[1] - a[1]).slice(0, 3);
    return `Top allocations: ${top.map(([e, s]) => `${e} (score: ${s})`).join(', ')}. Regime: ${regime?.regime}.`;
  }
}

module.exports = STRPatternEngine;

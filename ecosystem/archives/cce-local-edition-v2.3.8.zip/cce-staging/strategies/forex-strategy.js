// src/forex-strategy.js
'use strict';

class ForexSignals {
  calculateRSI(prices, period = 14) {
    if (!prices || prices.length < period + 1) return 50;
    let gains = 0, losses = 0;
    for (let i = prices.length - period; i < prices.length; i++) {
      const diff = prices[i] - prices[i - 1];
      if (diff >= 0) gains += diff;
      else losses += Math.abs(diff);
    }
    const avgGain = gains / period;
    const avgLoss = losses / period;
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  calculateZScore(prices, period = 20) {
    if (!prices || prices.length < period) return 0;
    const slice = prices.slice(-period);
    const mean = slice.reduce((a, b) => a + b, 0) / period;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / period;
    const stdDev = Math.sqrt(variance);
    if (stdDev === 0) return 0;
    return (prices[prices.length - 1] - mean) / stdDev;
  }

  calculateATR(prices, period = 14) {
    if (!prices || prices.length < period + 1) return 0;
    let trSum = 0;
    for (let i = prices.length - period; i < prices.length; i++) {
      trSum += Math.abs(prices[i] - prices[i - 1]);
    }
    return trSum / period;
  }

  getSession(hourUTC) {
    const isLondon  = hourUTC >= 7  && hourUTC < 16;
    const isNY      = hourUTC >= 13 && hourUTC < 21;
    const isOverlap = hourUTC >= 13 && hourUTC < 16;
    if (isOverlap) return { name: 'London/NY Overlap', isTrading: true };
    if (isLondon)  return { name: 'London',            isTrading: true };
    if (isNY)      return { name: 'New York',           isTrading: true };
    return           { name: 'Off-hours',               isTrading: false };
  }

  getAllSignals(prices, currentPrice, hourUTC, dayOfWeek) {
    const rsi     = this.calculateRSI(prices);
    const zScore  = this.calculateZScore(prices);
    const atr     = this.calculateATR(prices);
    const session = this.getSession(hourUTC);
    const slice20 = prices.slice(-20);
    const mean20  = slice20.length > 0 ? slice20.reduce((a, b) => a + b, 0) / slice20.length : currentPrice;
    const atr5    = this.calculateATR(prices, 5);
    const atrRatio = atr > 0 ? atr5 / atr : 1;

    return {
      rsi, zScore, atr, atrRatio, mean20, session,
      isOversold:        zScore <= -1.5 && rsi < 35,
      isExtremeOversold: zScore <= -2.0 && rsi < 30,
      isLondonSession:   session.isTrading,
      isGoodDay:         dayOfWeek >= 1 && dayOfWeek <= 4,
      isFriday:          dayOfWeek === 5,
      atrSpike:          atrRatio > 2.0,
      reachedMean:       currentPrice >= mean20 * 0.9995,
      isOverbought:      zScore >= 1.0,
      deeperLoss:        zScore <= -3.0,
    };
  }
}

class ForexStateMachine {
  constructor(config = {}) {
    this.states = { DORMANT:'DORMANT', OBSERVE:'OBSERVE', ANALYSE:'ANALYSE', EXECUTE:'EXECUTE', MONITOR:'MONITOR', ANCHOR:'ANCHOR', EXTRACT:'EXTRACT', EVALUATE:'EVALUATE' };
    this.currentState   = this.states.DORMANT;
    this.previousState  = null;
    this.stateEnteredAt = new Date();
    this.position       = null;
    this.lastEvaluation = null;
    this.cfg = {
      zScoreEntry:      config.zScoreEntry      ?? -1.5,
      rsiEntry:         config.rsiEntry         ?? 35,
      zScoreStop:       config.zScoreStop       ?? -3.0,
      maxHoldHours:     config.maxHoldHours     ?? 48,
      anchorPartialPct: config.anchorPartialPct ?? 0.5,
      minPipProfit:     config.minPipProfit      ?? 5,
    };
  }

  evaluateTransition(context) {
    const next = this._getNextState(context);
    if (next !== this.currentState) return this._transition(next, context);
    return { transitioned: false, state: this.currentState };
  }

  _transition(newState, context) {
    this.previousState  = this.currentState;
    this.currentState   = newState;
    this.stateEnteredAt = new Date();
    if (newState === this.states.EXECUTE && context.signals) {
      const sig = context.signals;
      const stopPips   = Math.round(sig.atr * 10000 * 1.5);
      const targetPips = Math.round(sig.atr * 10000 * 3.0);
      this.position = {
        entryPrice: context.price,
        stopLoss:   +(context.price - stopPips / 10000).toFixed(5),
        target:     +(context.price + targetPips / 10000).toFixed(5),
        stopPips, targetPips,
        entryTime:  new Date(),
        direction:  'BUY',
        partialClosed: false
      };
    }
    if (newState === this.states.EVALUATE) {
      this.lastEvaluation = { ...this.position, exitTime: new Date() };
      this.position = null;
    }
    return {
      transitioned: true,
      from: this.previousState,
      to:   newState,
      reason: this._getTransitionReason(this.previousState, newState, context),
      position: this.position,
      timestamp: this.stateEnteredAt
    };
  }

  _getNextState(context) {
    const { signals, price } = context;
    const hoursInState = (Date.now() - this.stateEnteredAt.getTime()) / 3600000;
    switch (this.currentState) {
      case this.states.DORMANT:
        return (signals.isLondonSession && signals.isGoodDay && !signals.atrSpike) ? this.states.OBSERVE : this.states.DORMANT;
      case this.states.OBSERVE:
        if (!signals.isLondonSession || signals.isFriday) return this.states.DORMANT;
        if (signals.zScore <= -1.0) return this.states.ANALYSE;
        return this.states.OBSERVE;
      case this.states.ANALYSE:
        if (signals.zScore > -1.0)        return this.states.OBSERVE;
        if (!signals.isLondonSession)     return this.states.DORMANT;
        if (signals.atrSpike)             return this.states.OBSERVE;
        if (signals.isOversold && signals.isGoodDay) return this.states.EXECUTE;
        return this.states.ANALYSE;
      case this.states.EXECUTE:
        return this.states.MONITOR;
      case this.states.MONITOR:
        if (!this.position) return this.states.EVALUATE;
        if (price <= this.position.stopLoss) return this.states.EXTRACT;
        if (price >= this.position.target)   return this.states.EXTRACT;
        if (!this.position.partialClosed) {
          const pipProfit = Math.round((price - this.position.entryPrice) * 10000);
          if (pipProfit >= this.cfg.minPipProfit) return this.states.ANCHOR;
        }
        if (hoursInState >= this.cfg.maxHoldHours) return this.states.EXTRACT;
        if (!signals.isLondonSession && !signals.isGoodDay) return this.states.EXTRACT;
        return this.states.MONITOR;
      case this.states.ANCHOR:
        if (this.position) this.position.partialClosed = true;
        return this.states.MONITOR;
      case this.states.EXTRACT:
        return this.states.EVALUATE;
      case this.states.EVALUATE:
        return this.states.DORMANT;
      default:
        return this.states.DORMANT;
    }
  }

  _getTransitionReason(from, to, context) {
    const sig = context.signals;
    const p   = context.price;
    if (from === 'DORMANT'  && to === 'OBSERVE')  return `Session open — scanning (z=${sig.zScore?.toFixed(2)})`;
    if (from === 'OBSERVE'  && to === 'ANALYSE')  return `Oversold zone (z=${sig.zScore?.toFixed(2)})`;
    if (from === 'OBSERVE'  && to === 'DORMANT')  return 'Session ended or Friday';
    if (from === 'ANALYSE'  && to === 'EXECUTE')  return `Entry: z=${sig.zScore?.toFixed(2)}, RSI=${sig.rsi?.toFixed(1)}`;
    if (from === 'ANALYSE'  && to === 'OBSERVE')  return `Signal weakened (z=${sig.zScore?.toFixed(2)})`;
    if (from === 'EXECUTE'  && to === 'MONITOR')  return `Alert sent @ ${p}`;
    if (from === 'MONITOR'  && to === 'ANCHOR')   return 'Partial profit — reduce position';
    if (from === 'MONITOR'  && to === 'EXTRACT')  return this.position && p <= this.position.stopLoss ? `Stop hit @ ${p}` : `Target/timeout @ ${p}`;
    if (from === 'ANCHOR'   && to === 'MONITOR')  return 'Partial close done';
    if (from === 'EXTRACT'  && to === 'EVALUATE') return 'Trade closed';
    if (from === 'EVALUATE' && to === 'DORMANT')  return 'Reset';
    return `${from} → ${to}`;
  }

  getStateSummary() {
    const s = { DORMANT:'Standing by', OBSERVE:'Scanning EUR/USD', ANALYSE:'Signal emerging', EXECUTE:'Entry alert sent', MONITOR:'In trade', ANCHOR:'Partial profit', EXTRACT:'Exiting', EVALUATE:'Post-trade review' };
    return s[this.currentState] || 'Unknown';
  }
}

module.exports = { ForexSignals, ForexStateMachine };

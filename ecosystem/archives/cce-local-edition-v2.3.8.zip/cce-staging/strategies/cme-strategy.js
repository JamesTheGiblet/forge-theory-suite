// src/cme-strategy.js
// CCE Stocks Engine (CME) — 6-State FSM
// Thesis: SPY momentum lag — exploit the window between institutional
// breakout confirmation and retail participation.
//
// States:
//   DORMANT   — SPY below SMA200 or VIX > 30. Bear market. 100% cash.
//   WATCHING  — SPY above SMA200, VIX calming. Market healthy. Scanning.
//   PRIMED    — Breakout conditions forming. SPY above SMA50, volume building.
//   ENTERING  — All conditions met. Trade alert sent. Deploy capital.
//   HOLDING   — In position. Trailing SMA50 as dynamic stop.
//   EXITING   — Exit conditions triggered. Alert sent. Back to cash.

'use strict';

class CMEStateMachine {
  constructor(config = {}) {
    this.currentState   = 'DORMANT';
    this.previousState  = 'DORMANT';
    this.stateEnteredAt = Date.now();

    // Configurable thresholds
    this.vixBearThreshold  = config.vixBearThreshold  || 30;   // Above = bear market
    this.vixEntryMax       = config.vixEntryMax       || 20;   // Must be below to enter
    this.vixExitThreshold  = config.vixExitThreshold  || 25;   // Spike triggers exit
    this.rsiEntryMin       = config.rsiEntryMin       || 50;   // Momentum building
    this.rsiEntryMax       = config.rsiEntryMax       || 70;   // Not overbought
    this.rsiTakeProfit     = config.rsiTakeProfit     || 80;   // Overbought — take profit
    this.breadthMin        = config.breadthMin        || 60;   // Min breadth score to enter
    this.minPrimedDays     = config.minPrimedDays     || 2;    // Min days in PRIMED before entry
    this.minHoldDays       = config.minHoldDays       || 5;    // Min hold before exit scan
    this.maxHoldDays       = config.maxHoldDays       || 60;   // Force exit after 60 days
  }

  getDaysInState() {
    return (Date.now() - this.stateEnteredAt) / 86400000;
  }

  getStateSummary() {
    const summaries = {
      DORMANT:  'Bear market / high volatility — holding cash',
      WATCHING: 'Market healthy — scanning for setup',
      PRIMED:   'Breakout conditions forming — ready to enter',
      ENTERING: 'Entry confirmed — deploying capital',
      HOLDING:  'In position — trailing SMA50',
      EXITING:  'Exit triggered — rotating to cash'
    };
    return summaries[this.currentState] || this.currentState;
  }

  evaluateTransition(context) {
    const from = this.currentState;
    let to     = null;
    let reason = '';

    switch (this.currentState) {

      case 'DORMANT':
        // Wake up when market structure is healthy
        if (context.aboveSma200 && !context.vixHigh) {
          to     = 'WATCHING';
          reason = `SPY above SMA200 ($${context.sma200}), VIX ${context.vix} — market structure healthy`;
        }
        break;

      case 'WATCHING':
        // Return to DORMANT if bear market returns
        if (!context.aboveSma200 || context.vixHigh) {
          to     = 'DORMANT';
          reason = `${!context.aboveSma200 ? 'SPY broke below SMA200' : `VIX spiked to ${context.vix}`} — returning to cash`;
          break;
        }

        // Advance to PRIMED when momentum builds
        if (
          context.aboveSma50 &&
          context.rsi >= this.rsiEntryMin &&
          context.vixLow &&
          context.goldenCross
        ) {
          to     = 'PRIMED';
          reason = `SPY above SMA50 ($${context.sma50}), RSI ${context.rsi}, VIX ${context.vix}, golden cross confirmed`;
        }
        break;

      case 'PRIMED': {
        const daysPrimed = this.getDaysInState();

        // Drop back to WATCHING if conditions deteriorate
        if (!context.aboveSma50 || context.vixElevated || context.vixHigh) {
          to     = 'WATCHING';
          reason = `Conditions deteriorated — ${!context.aboveSma50 ? 'SPY below SMA50' : `VIX elevated at ${context.vix}`}`;
          break;
        }

        // Full entry when all conditions confirmed
        const allConditionsMet = (
          daysPrimed >= this.minPrimedDays &&
          context.aboveSma50 &&
          context.aboveSma200 &&
          context.volumeConfirming &&
          context.rsi >= this.rsiEntryMin &&
          context.rsi <= this.rsiEntryMax &&
          context.vix < this.vixEntryMax &&
          context.breadthHealthy &&
          context.momentum4w > 0
        );

        if (allConditionsMet) {
          to     = 'ENTERING';
          reason = `All conditions met — SPY $${context.price}, RSI ${context.rsi}, VIX ${context.vix}, breadth ${context.breadthScore.toFixed(0)}%, volume confirming`;
        }
        break;
      }

      case 'ENTERING':
        // Move straight to HOLDING after entry signal
        to     = 'HOLDING';
        reason = 'Entry executed — monitoring position';
        break;

      case 'HOLDING': {
        const daysHeld = this.getDaysInState();

        // Force exit at max hold
        if (daysHeld > this.maxHoldDays) {
          to     = 'EXITING';
          reason = `Max hold period reached (${Math.round(daysHeld)} days)`;
          break;
        }

        // Minimum hold — don't exit too early
        if (daysHeld < this.minHoldDays) break;

        // SMA50 breakdown — primary exit signal
        if (!context.aboveSma50) {
          to     = 'EXITING';
          reason = `SPY broke below SMA50 ($${context.sma50}) — structural breakdown`;
          break;
        }

        // VIX spike — fear entering market
        if (context.vix >= this.vixExitThreshold) {
          to     = 'EXITING';
          reason = `VIX spiked to ${context.vix} (threshold: ${this.vixExitThreshold}) — fear entering market`;
          break;
        }

        // Overbought — take profit
        if (context.rsi >= this.rsiTakeProfit) {
          to     = 'EXITING';
          reason = `RSI overbought at ${context.rsi} — taking profit`;
          break;
        }

        // Death cross — structural shift
        if (context.deathCross) {
          to     = 'EXITING';
          reason = `SMA50 crossed below SMA200 (death cross) — exiting`;
          break;
        }

        // Momentum failure
        if (context.momentum4w < -5) {
          to     = 'EXITING';
          reason = `4-week momentum failed: ${context.momentum4w}%`;
        }
        break;
      }

      case 'EXITING':
        // Re-evaluate after exit
        if (!context.aboveSma200 || context.vixHigh) {
          to     = 'DORMANT';
          reason = 'Bear market conditions — returning to cash';
        } else {
          to     = 'WATCHING';
          reason = 'Exited position — market still healthy, re-entering watch';
        }
        break;
    }

    if (to && to !== from) {
      this.previousState  = from;
      this.currentState   = to;
      this.stateEnteredAt = Date.now();
      return { transitioned: true, from, to, reason };
    }

    return { transitioned: false, from, to: from, reason: '' };
  }
}

class CMESignals {
  getDrawdownFromPeak(closes) {
    if (!closes.length) return 0;
    const peak    = Math.max(...closes.slice(-60));
    const current = closes[closes.length - 1];
    return +((current - peak) / peak * 100).toFixed(2);
  }

  getAllSignals(market) {
    return {
      rsi:              market.rsi,
      momentum4w:       market.momentum4w,
      drawdownFromPeak: this.getDrawdownFromPeak(market.closes),
      aboveSma50:       market.aboveSma50,
      aboveSma200:      market.aboveSma200,
      goldenCross:      market.goldenCross,
      deathCross:       market.deathCross,
      vix:              market.vix,
      vixLow:           market.vixLow,
      vixHigh:          market.vixHigh,
      breadthScore:     market.breadthScore,
      breadthHealthy:   market.breadthHealthy,
      volumeConfirming: market.volumeConfirming
    };
  }
}

module.exports = { CMEStateMachine, CMESignals };

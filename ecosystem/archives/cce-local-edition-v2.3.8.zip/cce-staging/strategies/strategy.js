// src/strategy.js
// CENTRALISED TRADING STRATEGY
// Contains: Signals, Zombie Scanner, Rebalancer, and State Machine

'use strict';

// ============================================================================
// 1. SIGNALS (The Eyes)
// ============================================================================

class TechnicalSignals {
  constructor(config = {}) {
    this.s = config.strategy?.signals || {};
  }

  calculateSMA(data, period) {
    if (!data || data.length < period) return 0;
    const slice = data.slice(-period);
    return slice.reduce((a, b) => a + b, 0) / period;
  }

  calculateStandardDeviation(data, period) {
    if (!data || data.length < period) return 0;
    const slice = data.slice(-period);
    const mean = slice.reduce((a, b) => a + b, 0) / period;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / period;
    return Math.sqrt(variance);
  }

  getAllSignals(currentPrice, btcDominance, historicalPrices) {
    const prices  = historicalPrices || [];
    const current = currentPrice || 0;

    const sma10 = this.calculateSMA(prices, this.s.smaFast || 10);
    const sma20 = this.calculateSMA(prices, this.s.smaMedium || 20);
    const sma50 = this.calculateSMA(prices, this.s.smaSlow || 50);

    // Lagged signals: BTC strength 3 and 7 days ago
    // Leading indicator for alt pumps — BTC strength T-3/T-7 precedes alt rotation
    let btc_was_strong_3d_ago = false;
    let btc_was_strong_7d_ago = false;

    if (prices.length >= 30) {
      const prices3d    = prices.slice(0, -(this.s.lagShort || 3));
      const sma20_3d    = this.calculateSMA(prices3d, 27);
      const price3d     = prices3d[prices3d.length - 1];
      btc_was_strong_3d_ago = price3d > sma20_3d;

      const prices7d    = prices.slice(0, -(this.s.lagLong || 7));
      const sma20_7d    = this.calculateSMA(prices7d, 23);
      const price7d     = prices7d[prices7d.length - 1];
      btc_was_strong_7d_ago = price7d > sma20_7d;
    }

    // Bollinger Band Width for consolidation detection
    // Width = (4 × StdDev) / SMA20 — requires sma20 > 0 to avoid divide-by-zero
    const stdDev20 = this.calculateStandardDeviation(prices, this.s.smaMedium || 20);
    const bbWidth  = sma20 > 0 ? (4 * stdDev20) / sma20 : 1; // Default 1 (wide) when no data

    // Velocity/Momentum: 5-day Rate of Change — matches backtest.js logic
    let recentGain = 0;
    if (prices.length >= 5) {
      const price5dAgo = prices[prices.length - 5];
      recentGain = price5dAgo > 0 ? (current - price5dAgo) / price5dAgo : 0;
    }

    return {
      // Trend
      btc_below_key_support:        sma50 > 0 && current < sma50 * 0.94,
      sma_20_above_50:              sma20 > sma50,
      btc_above_20_sma:             current > sma20,
      sma_10_above_20:              sma10 > sma20,
      btc_was_strong_3d_ago,
      btc_was_strong_7d_ago,
      btc_below_10_sma:             sma10 > 0 && current < sma10,

      // Volatility
      // TODO: btc_5_percent_drop requires 24h OHLC data — not yet implemented
      btc_5_percent_drop:           false,
      btc_consolidating:            bbWidth < (this.s.bbWidthThreshold || 0.29),

      // Velocity (5-day ROC)
      velocity_underperforming_btc_72h: recentGain < (this.s.rocShort || -0.05),
      velocity_reversal:                recentGain < (this.s.rocReversal || -0.10),
      velocity_asset_breaking_out:      recentGain > (this.s.rocBreakout || 0.15),

      // Multipliers (High Beta) — not yet implemented
      // TODO: Requires per-asset RSI and relative performance tracking
      multiplier_underperforming_48h: false,
      multiplier_rsi_above_85:        false,

      // Dominance
      // TODO: btc_d_rising_sharply requires multi-day dominance history
      btc_d_rising_sharply: false,
      btc_d_topping:        btcDominance > 55,
      btc_d_rsi_below_70:   true,

      // TODO: alt_season_index requires tracking top-50 alt performance vs BTC
      alt_season_index_above_75: false
    };
  }
}

class SentimentSignals {
  constructor(config = {}) {
    this.weights = config.strategy?.sentiment || { fearGreedWeight: 0.7, lunarCrushWeight: 0.3 };
  }

  getSentimentScore(marketData) {
    let score = 50; // Default: neutral

    if (marketData?.fear_greed_index?.value) {
      score = parseInt(marketData.fear_greed_index.value);
    }

    // Weighted blend: 70% Fear & Greed, 30% LunarCrush Galaxy Score
    if (marketData?.lunarcrush?.galaxy_score) {
      const galaxyScore = parseFloat(marketData.lunarcrush.galaxy_score);
      score = (score * this.weights.fearGreedWeight) + (galaxyScore * this.weights.lunarCrushWeight);
    }

    return score;
  }
}

// ============================================================================
// 2. ZOMBIE SCANNER (Risk Management)
// Filters out assets with missing or invalid price data before buying
// ============================================================================

class ZombieScanner {
  constructor(config) {
    this.threshold    = config.states?.zombieScoreThreshold || 70;
    this.assetPriceKeys = {
      ETH:  'eth_price',
      SOL:  'sol_price',
      RNDR: 'rndr_price',
      FET:  'fet_price'
    };
  }

  scan(marketData) {
    const zombies = [];

    for (const [asset, priceKey] of Object.entries(this.assetPriceKeys)) {
      const price = marketData[priceKey];
      if (price !== undefined && (price <= 0 || isNaN(price))) {
        console.warn(`🧟 ZOMBIE DETECTED: ${asset} (Invalid price for key '${priceKey}')`);
        zombies.push(asset);
      } else if (price === undefined) {
        zombies.push(asset); // silently skip — data not yet fetched
      }
    }

    if (zombies.length > 0) {
      console.log(`🧟 Zombie Scan Results: ${zombies.join(', ')}`);
    }

    return zombies;
  }
}

// ============================================================================
// 3. REBALANCER (The Calculator)
// ============================================================================

class CCERebalancer {
  constructor(config = {}) {
    this.minTradeValue = config.trading?.minTradeValue ?? 10.0;
    this.baseCurrency = config.trading?.baseCurrency || 'USD';

    const defaultConfig = require("../config.js");
    this.allocations = config.strategy?.allocations || defaultConfig.strategy.allocations;
  }

  rebalanceForState(currentHoldings, targetState, prices, zombies = []) {
    const targetAlloc = this.allocations[targetState];
    if (!targetAlloc) {
      console.warn(`⚠️  Unknown state for rebalancing: ${targetState}`);
      return { actions: [], newPortfolio: currentHoldings };
    }

    // Calculate total portfolio value
    // Cash is tracked as USDC in allocations and USD in the mock portfolio —
    // sum both to get the full cash position
    let totalValueUSD = 0;
    for (const [asset, amount] of Object.entries(currentHoldings)) {
      if (asset === 'USD' || asset === 'USDC' || asset === this.baseCurrency) {
        totalValueUSD += amount;
      } else {
        totalValueUSD += amount * (prices[asset] || 0);
      }
    }

    // Build full asset set: all target assets + all currently held non-cash assets
    const allAssets = new Set([
      ...Object.keys(targetAlloc),
      ...Object.keys(currentHoldings).filter(k => k !== 'USD' && k !== 'USDC' && k !== this.baseCurrency)
    ]);

    const actions = [];

    for (const asset of allAssets) {
      const targetPct = targetAlloc[asset] || 0;

      // Zombie check: skip BUY orders for zombie assets but allow SELLs (targetPct 0)
      if (zombies.includes(asset) && targetPct > 0) {
        console.log(`⏭️  Skipping ${asset} — marked as zombie`);
        continue;
      }

      const isCash = asset === 'USDC' || asset === 'USD' || asset === this.baseCurrency;
      if (isCash) continue; // Cash handled implicitly as residual

      const currentAmount = currentHoldings[asset] || 0;
      const currentVal    = currentAmount * (prices[asset] || 0);
      const targetVal     = totalValueUSD * targetPct;
      const diff          = targetVal - currentVal;

      if (Math.abs(diff) <= this.minTradeValue) continue;

      const price = prices[asset];
      if (!price || price <= 0) {
        console.warn(`⚠️  No valid price for ${asset}, skipping rebalance action.`);
        continue;
      }

      actions.push({
        action: diff > 0 ? 'buy' : 'sell',
        symbol: asset,
        amount: Math.abs(diff) / price,
        price,
        value:  Math.abs(diff),
        reason: `Rebalance to ${targetState} (${(targetPct * 100).toFixed(0)}%)`
      });
    }

    return { actions, newPortfolio: currentHoldings };
  }
}

// ============================================================================
// 4. STATE MACHINE (The Brain)
// ============================================================================

class CCEStateMachine {
  constructor(config = {}) {
    this.states = {
      DORMANT:      'DORMANT',
      ACCUMULATION: 'ACCUMULATION',
      ANCHOR:       'ANCHOR',
      IGNITION:     'IGNITION',
      CASCADE_1:    'CASCADE_1',
      CASCADE_2:    'CASCADE_2',
      SPILLWAY:     'SPILLWAY',
      EXTRACTION:   'EXTRACTION'
    };

    this.currentState           = this.states.DORMANT;
    this.previousState          = null;
    this.stateEnteredAt         = new Date();
    this.ignitionHighWaterMark  = 0;
    this.minDormantDays         = config.minDormantDays || 30;
    this.trailingStopPct        = config.ignitionTrailingStopPct || 0.021;
    this.minHoldDays            = config.minHoldDays || {
      IGNITION:  7,
      CASCADE_1: 14,
      CASCADE_2: 14,
      SPILLWAY:  7,
      ANCHOR:    5
    };
    this.thresholds = config.strategy?.thresholds || {};
  }

  evaluateTransition(context) {
    // Track high water mark for IGNITION trailing stop
    if (this.currentState === this.states.IGNITION && context.btcPrice) {
      if (context.btcPrice > this.ignitionHighWaterMark) {
        this.ignitionHighWaterMark = context.btcPrice;
      }
    } else {
      this.ignitionHighWaterMark = 0;
    }

    const reversion = this._checkStateReversion(context);
    if (reversion) {
      return this._executeTransition(reversion, 'Failure reversion', context.currentTimestamp);
    }

    const nextState = this._evaluateForwardTransition(context);
    if (nextState !== this.currentState) {
      return this._executeTransition(nextState, 'Forward progression', context.currentTimestamp);
    }

    return { transitioned: false, state: this.currentState };
  }

  _executeTransition(newState, reason, timestamp) {
    this.previousState  = this.currentState;
    this.currentState   = newState;
    this.stateEnteredAt = timestamp || new Date();
    return {
      transitioned: true,
      from:         this.previousState,
      to:           newState,
      reason,
      timestamp:    this.stateEnteredAt
    };
  }

  _getDaysInState(context) {
    const current = context.currentTimestamp || new Date();
    return (current - this.stateEnteredAt) / (1000 * 60 * 60 * 24);
  }

  getTransitionProgress(context) {
    const days = this._getDaysInState(context);
    let percent = 0;
    let label   = 'Monitoring...';

    switch (this.currentState) {
      case this.states.DORMANT: {
        const isBear  = context.signals.btc_below_key_support;
        const reqDays = isBear ? 60 : this.minDormantDays;
        percent = Math.min(100, (days / reqDays) * 100);
        label   = `Dormancy Period (${days.toFixed(1)}/${reqDays}d)`;
        if (context.fearGreedIndex >= (this.thresholds.dormantSentimentOverride || 60)) {
          percent = 100;
          label   = `Sentiment Override (Greed ≥ ${this.thresholds.dormantSentimentOverride || 60})`;
        }
        break;
      }

      case this.states.ACCUMULATION: {
        if (context.signals.sma_20_above_50) {
          percent = 80;
          label   = 'Golden Cross Active — Waiting for Sentiment';
          if (context.fearGreedIndex > (this.thresholds.accumulationReadySentiment || 30) && context.etfFlows7d >= 0) {
            percent = 100;
            label   = 'Ready for IGNITION';
          }
        } else {
          percent = 25;
          label   = 'Waiting for Golden Cross';
        }
        break;
      }

      case this.states.IGNITION: {
        percent = Math.min(100, (days / 3) * 100);
        label   = `Trend Confirmation (${days.toFixed(1)}/3d)`;
        if (percent >= 100 && !context.signals.btc_d_topping) {
          label = 'Waiting for Alt Signals';
        }
        break;
      }

      case this.states.CASCADE_1: {
        percent = Math.min(100, (days / 2) * 100);
        label   = `Rotation Period (${days.toFixed(1)}/2d)`;
        break;
      }

      case this.states.CASCADE_2: {
        percent = Math.max(0, Math.min(100, ((context.fearGreedIndex - 50) / 25) * 100));
        label   = `Market Heat (F&G: ${context.fearGreedIndex}/75)`;
        break;
      }

      default:
        break;
    }

    return { percent, label };
  }

  _checkStateReversion(context) {
    switch (this.currentState) {
      case this.states.DORMANT:
        return null;
      case this.states.ACCUMULATION:
        return this._checkAccumulationFailure(context) ? this.states.DORMANT : null;
      case this.states.ANCHOR:
        return this._checkAnchorFailure(context) ? this.states.DORMANT : null;
      case this.states.IGNITION: {
        if (this._checkIgnitionTakeProfit(context))  return this.states.ANCHOR;
        if (this._checkIgnitionTrailingStop(context)) return this.states.ANCHOR;
        return this._checkIgnitionFailure(context) ? this.states.ANCHOR : null;
      }
      case this.states.CASCADE_1:
        return this._checkCascade1Failure(context)
          ? (this._isSevereFailure(context) ? this.states.DORMANT : this.states.IGNITION)
          : null;
      case this.states.CASCADE_2:
        return this._checkCascade2Failure(context)
          ? (this._isSevereFailure(context) ? this.states.DORMANT : this.states.CASCADE_1)
          : null;
      case this.states.SPILLWAY:
        return this._checkSpillwayFailure(context) ? this.states.EXTRACTION : null;
      default:
        return null;
    }
  }

  _checkAccumulationFailure(context) {
    if (!context.signals.btc_above_20_sma) return true;
    if (this._getDaysInState(context) > 25) return true; // Stagnation guard
    return false;
  }

  _checkIgnitionTakeProfit(context) {
    return context.fearGreedIndex > (this.thresholds.ignitionTakeProfitSentiment || 90); // Extreme Greed — scale back to ANCHOR
  }

  _checkIgnitionTrailingStop(context) {
    if (this.ignitionHighWaterMark > 0 && context.btcPrice > 0) {
      const dropPct = (this.ignitionHighWaterMark - context.btcPrice) / this.ignitionHighWaterMark;
      return dropPct > this.trailingStopPct;
    }
    return false;
  }

  _checkIgnitionFailure(context) {
    const days = this._getDaysInState(context);
    const catastrophic = context.fearGreedIndex < (this.thresholds.panicSentiment || 20);
    const btcWasStrongRecently = context.signals.btc_was_strong_3d_ago ||
                                  context.signals.btc_was_strong_7d_ago;
    const bearExit = context.signals.btc_below_key_support &&
                     context.fearGreedIndex < (this.thresholds.panicSentiment || 20) &&
                     !btcWasStrongRecently;

    return days < this.minHoldDays.IGNITION
      ? catastrophic
      : catastrophic || bearExit;
  }

  _checkAnchorFailure(context) {
    if (context.signals.btc_below_key_support) return true;
    if (!context.signals.btc_above_20_sma && context.fearGreedIndex < (this.thresholds.anchorFailureSentimentHigh || 45)) return true;
    return !context.signals.sma_20_above_50 && context.fearGreedIndex < (this.thresholds.anchorFailureSentimentLow || 40);
  }

  _checkCascade1Failure(context) {
    if (this._getDaysInState(context) < this.minHoldDays.CASCADE_1) return false;
    return [
      context.signals.velocity_underperforming_btc_72h,
      context.signals.btc_d_rising_sharply,
      !context.signals.btc_above_20_sma && !context.signals.sma_20_above_50
    ].some(Boolean);
  }

  _checkCascade2Failure(context) {
    if (this._getDaysInState(context) < this.minHoldDays.CASCADE_2) return false;
    return [
      context.signals.multiplier_underperforming_48h,
      context.signals.velocity_reversal,
      context.signals.btc_below_key_support,
      context.fearGreedIndex < (this.thresholds.panicSentiment || 20)
    ].some(Boolean);
  }

  _checkSpillwayFailure(context) {
    if (this._getDaysInState(context) < this.minHoldDays.SPILLWAY) return false;
    return context.signals.btc_below_10_sma || context.signals.btc_5_percent_drop;
  }

  _isSevereFailure(context) {
    return context.fearGreedIndex < (this.thresholds.panicSentiment || 20) || context.etfFlows7d <= -500000000;
  }

  _evaluateForwardTransition(context) {
    switch (this.currentState) {
      case this.states.DORMANT:      return this._dormantToAccumulation(context);
      case this.states.ACCUMULATION: return this._accumulationToIgnition(context);
      case this.states.ANCHOR:       return this._anchorToIgnition(context);
      case this.states.IGNITION:     return this._ignitionToCascade1(context);
      case this.states.CASCADE_1:    return this._cascade1ToCascade2(context);
      case this.states.CASCADE_2:    return this._cascade2ToSpillway(context);
      case this.states.SPILLWAY:     return this._spillwayToExtraction(context);
      case this.states.EXTRACTION:   return this.states.ANCHOR;
      default:                       return this.currentState;
    }
  }

  _dormantToAccumulation(context) {
    const isBear  = context.signals.btc_below_key_support;
    let reqDays   = isBear ? 60 : this.minDormantDays;
    // Sentiment override: F&G >= 60 bypasses time requirement
    // Note: the F&G <= 40 guard below cannot block when this fires (F&G >= 60)
    if (context.fearGreedIndex >= (this.thresholds.dormantSentimentOverride || 60)) reqDays = 0;
    if (this._getDaysInState(context) < reqDays) return this.states.DORMANT;
    if (context.fearGreedIndex <= (this.thresholds.anchorFailureSentimentLow || 40)) return this.states.DORMANT;
    if (context.signals.btc_above_20_sma && context.signals.sma_10_above_20) {
      return this.states.ACCUMULATION;
    }
    return this.states.DORMANT;
  }

  _accumulationToIgnition(context) {
    if (!context.signals.sma_20_above_50)    return this.states.ACCUMULATION;
    if (context.fearGreedIndex <= (this.thresholds.anchorFailureSentimentLow || 40)) return this.states.ACCUMULATION;
    if (context.etfFlows7d < 0)              return this.states.ACCUMULATION;
    if (!context.signals.btc_above_20_sma)   return this.states.ACCUMULATION;
    return this.states.IGNITION;
  }

  _anchorToIgnition(context) {
    if (this._getDaysInState(context) < (this.minHoldDays.ANCHOR || 0)) return this.states.ANCHOR;
    return context.fearGreedIndex > (this.thresholds.anchorFailureSentimentLow || 40) && context.signals.btc_above_20_sma
      ? this.states.IGNITION
      : this.states.ANCHOR;
  }

  _ignitionToCascade1(context) {
    if (this._getDaysInState(context) < 3) return this.states.IGNITION;
    if (!context.signals.btc_consolidating ||
        !context.signals.btc_d_topping     ||
        !context.signals.btc_d_rsi_below_70) {
      return this.states.IGNITION;
    }
    return this.states.CASCADE_1;
  }

  _cascade1ToCascade2(context) {
    if (this._getDaysInState(context) < 2) return this.states.CASCADE_1;
    return context.signals.velocity_asset_breaking_out
      ? this.states.CASCADE_2
      : this.states.CASCADE_1;
  }

  _cascade2ToSpillway(context) {
    if (context.fearGreedIndex >= 70 ||
        context.signals.alt_season_index_above_75 ||
        context.signals.multiplier_rsi_above_85) {
      return this.states.SPILLWAY;
    }
    return this.states.CASCADE_2;
  }

  _spillwayToExtraction(context) {
    return context.signals.btc_below_10_sma || context.signals.btc_5_percent_drop
      ? this.states.EXTRACTION
      : this.states.SPILLWAY;
  }
}

module.exports = { TechnicalSignals, SentimentSignals, ZombieScanner, CCERebalancer, CCEStateMachine };
// src/storage.js
// SQLite persistence layer for CCE engine state, trades, cycles, and reports
// Android/Termux compatible — uses sql.js (pure JS) with binary file persistence

'use strict';

const initSqlJs = require('sql.js');
const path      = require('path');
const fs        = require('fs');

class StorageManager {
  constructor(dbPath) {
    const isPkg = typeof process.pkg !== 'undefined';
    const basePath = isPkg ? path.dirname(process.execPath) : path.join(__dirname, '..');

    this.dbPath = dbPath || path.join(basePath, 'data', 'cce-production.db');
    this.db = null;
    this._saveTimer = null;

    // _ready resolves once the DB is initialised
    this._ready = this._initDb();
  }

  // ============================================================================
  // INIT
  // ============================================================================

  async _initDb() {
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const SQL = await initSqlJs();

    if (fs.existsSync(this.dbPath)) {
      const fileBuffer = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(fileBuffer);
    } else {
      this.db = new SQL.Database();
    }

    this._createTables();
    this._migrate('cce_cycles', 'transition_progress', 'REAL');
    this._migrate('cce_cycles', 'transition_message',  'TEXT');

    // Auto-save every 30 seconds
    this._saveTimer = setInterval(() => this._persist(), 30000);
  }

  _createTables() {
    this.db.run(`CREATE TABLE IF NOT EXISTS state_history (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      from_state TEXT,
      to_state   TEXT,
      reason     TEXT,
      timestamp  DATETIME
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS trades (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      symbol    TEXT,
      side      TEXT,
      amount    REAL,
      price     REAL,
      value     REAL,
      reason    TEXT,
      order_id  TEXT,
      timestamp DATETIME
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS portfolio_snapshots (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      state     TEXT,
      holdings  TEXT,
      timestamp DATETIME
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS cce_cycles (
      id                    INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp             DATETIME,
      cycle_number          INTEGER,
      btc_price             REAL,
      fear_greed            INTEGER,
      btc_dominance         REAL,
      etf_flows_7d          REAL,
      current_state         TEXT,
      previous_state        TEXT,
      days_in_state         REAL,
      portfolio_value       REAL,
      btc_holdings          REAL,
      usdc_holdings         REAL,
      daily_return          REAL,
      total_return          REAL,
      btc_above_20_sma      BOOLEAN,
      sma_20_above_50       BOOLEAN,
      btc_was_strong_3d_ago BOOLEAN,
      btc_was_strong_7d_ago BOOLEAN,
      transition_progress   REAL,
      transition_message    TEXT
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS daily_reports (
      id                 INTEGER PRIMARY KEY AUTOINCREMENT,
      report_date        DATE,
      cycles_completed   INTEGER,
      start_value        REAL,
      end_value          REAL,
      daily_return       REAL,
      btc_return         REAL,
      alpha              REAL,
      state_changes      INTEGER,
      trades_executed    INTEGER,
      avg_fear_greed     REAL,
      max_drawdown_24h   REAL,
      time_in_market_pct REAL,
      report_json        TEXT,
      timestamp          DATETIME
    )`);
  }

  _migrate(table, column, type) {
    try {
      this.db.run(`ALTER TABLE ${table} ADD COLUMN ${column} ${type}`);
    } catch (err) {
      if (err && !err.message.includes('duplicate column name')) {
        console.error(`Migration warning (${table}.${column}):`, err.message);
      }
    }
  }

  // Persist in-memory DB to disk
  _persist() {
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (err) {
      console.error('DB persist error:', err.message);
    }
  }

  // ============================================================================
  // WRITE METHODS (Promisified for API compatibility)
  // ============================================================================

  async logStateChange(data) {
    await this._ready;
    return this._run(
      'INSERT INTO state_history (from_state, to_state, reason, timestamp) VALUES (?, ?, ?, ?)',
      [data.from, data.to, data.reason, data.timestamp || new Date().toISOString()]
    );
  }

  async logTrade(data) {
    await this._ready;
    return this._run(
      'INSERT INTO trades (symbol, side, amount, price, value, reason, order_id, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [data.symbol, data.side, data.amount, data.price, data.amount * data.price,
       data.reason, data.orderId, new Date().toISOString()]
    );
  }

  async savePortfolioSnapshot(portfolio, state) {
    await this._ready;
    return this._run(
      'INSERT INTO portfolio_snapshots (state, holdings, timestamp) VALUES (?, ?, ?)',
      [state, JSON.stringify(portfolio), new Date().toISOString()]
    );
  }

  async logCycle(data) {
    await this._ready;
    return this._run(
      `INSERT INTO cce_cycles (
        timestamp, cycle_number, btc_price, fear_greed, btc_dominance, etf_flows_7d,
        current_state, previous_state, days_in_state, portfolio_value,
        btc_holdings, usdc_holdings, daily_return, total_return,
        btc_above_20_sma, sma_20_above_50, btc_was_strong_3d_ago, btc_was_strong_7d_ago,
        transition_progress, transition_message
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.cycle_number, data.btc_price,
        data.fear_greed, data.btc_dominance, data.etf_flows_7d,
        data.current_state, data.previous_state, data.days_in_state, data.portfolio_value,
        data.btc_holdings, data.usdc_holdings, data.daily_return, data.total_return,
        data.btc_above_20_sma  ? 1 : 0, data.sma_20_above_50   ? 1 : 0,
        data.btc_was_strong_3d_ago ? 1 : 0, data.btc_was_strong_7d_ago ? 1 : 0,
        data.transition_progress ?? 0, data.transition_message ?? ''
      ]
    );
  }

  async saveDailyReport(data) {
    await this._ready;
    return this._run(
      `INSERT INTO daily_reports (
        report_date, cycles_completed, start_value, end_value, daily_return,
        btc_return, alpha, state_changes, trades_executed, avg_fear_greed,
        max_drawdown_24h, time_in_market_pct, report_json, timestamp
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        data.report_date, data.cycles_completed, data.start_value, data.end_value,
        data.daily_return, data.btc_return, data.alpha, data.state_changes,
        data.trades_executed, data.avg_fear_greed, data.max_drawdown_24h,
        data.time_in_market_pct, JSON.stringify(data.report_json), new Date().toISOString()
      ]
    );
  }

  // ============================================================================
  // READ METHODS
  // ============================================================================

  async getCycleHistory(limit = 100) {
    await this._ready;
    const rows = this._all(
      'SELECT * FROM cce_cycles ORDER BY timestamp DESC LIMIT ?', [limit]
    );
    return rows.reverse();
  }

  async getDailyReports(limit = 30) {
    await this._ready;
    return this._all('SELECT * FROM daily_reports ORDER BY timestamp DESC LIMIT ?', [limit]);
  }

  async getLatestCycle() {
    await this._ready;
    return this._get('SELECT * FROM cce_cycles ORDER BY timestamp DESC LIMIT 1', []);
  }

  async getStateTransitions(limit = 10) {
    await this._ready;
    return this._all('SELECT * FROM state_history ORDER BY timestamp DESC LIMIT ?', [limit]);
  }

  async getTrades(limit = 10) {
    await this._ready;
    return this._all('SELECT * FROM trades ORDER BY timestamp DESC LIMIT ?', [limit]);
  }

  // ============================================================================
  // LIFECYCLE
  // ============================================================================

  async close() {
    await this._ready;
    if (this._saveTimer) clearInterval(this._saveTimer);
    this._persist();
    this.db.close();
    console.log('📦 Database connection closed.');
  }

  // ============================================================================
  // PRIVATE HELPERS
  // ============================================================================

  _run(sql, params = []) {
    this.db.run(sql, params);
    this._persist();
    const lastId = this.db.exec('SELECT last_insert_rowid()');
    return { lastID: lastId[0]?.values[0][0], changes: 1 };
  }

  _get(sql, params = []) {
    const stmt = this.db.prepare(sql);
    stmt.bind(params);
    if (stmt.step()) {
      const row = stmt.getAsObject();
      stmt.free();
      return row;
    }
    stmt.free();
    return undefined;
  }

  _all(sql, params = []) {
    const result = this.db.exec(sql, params);
    if (!result.length) return [];
    const { columns, values } = result[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  }
}

module.exports = StorageManager;

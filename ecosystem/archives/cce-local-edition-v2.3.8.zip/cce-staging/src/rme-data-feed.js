// src/rme-data-feed.js
// CCE REIT Engine (RME) — Alpha Vantage Data Feed
// Fetches: Fed funds rate, 10Y Treasury yield, VNQ price history
'use strict';

const https = require('https');

class RMEDataFeed {
  constructor(config = {}) {
    this.apiKey     = process.env.ALPHA_VANTAGE_API_KEY || 'demo';
    this.reitSymbol = config.rme?.symbol || 'VNQ';
    this._cache     = null;
    this._cacheTime = 0;
    this._cacheTTL  = 4 * 60 * 60 * 1000; // 4 hours — daily data, no need to refresh often
  }

  async getMarketData() {
    if (this._cache && (Date.now() - this._cacheTime) < this._cacheTTL) {
      return this._cache;
    }

    try {
      // Sequential fetches to avoid Alpha Vantage rate limiting (5 req/min free tier)
      const reitData     = await this._fetchREIT();
      await this._delay(15000);
      const treasuryData = await this._fetchTreasuryYield();
      await this._delay(15000);
      const fedRateData  = await this._fetchFedFundsRate();

      const data = this._buildMarketContext(reitData, treasuryData, fedRateData);
      this._cache     = data;
      this._cacheTime = Date.now();
      return data;

    } catch (err) {
      console.error('[RME] Data feed error:', err.message);
      if (this._cache) {
        console.warn('[RME] Using stale cache');
        return { ...this._cache, stale: true };
      }
      return this._neutralData();
    }
  }

  // ============================================================================
  // ALPHA VANTAGE FETCHERS
  // ============================================================================

  _fetchREIT() {
    // Daily adjusted prices for VNQ (or configured REIT ETF)
    const url = `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${this.reitSymbol}&outputsize=compact&apikey=${this.apiKey}`;
    return this._fetch(url).then(raw => {
      const series = raw['Time Series (Daily)'];
      if (!series) throw new Error(`No REIT data for ${this.reitSymbol}`);

      const entries = Object.entries(series)
        .sort(([a], [b]) => new Date(a) - new Date(b))
        .slice(-60); // Last 60 trading days

      const closes = entries.map(([, v]) => parseFloat(v['4. close']));
      const dates  = entries.map(([d]) => d);
      const price  = closes[closes.length - 1];

      return { closes, dates, price, symbol: this.reitSymbol };
    });
  }

  _fetchTreasuryYield() {
    // 10-year Treasury yield — key inverse driver of REIT prices
    const url = `https://api.stlouisfed.org/fred/series/observations?series_id=DGS10&api_key=${process.env.FRED_API_KEY_2}&file_type=json&limit=60&sort_order=desc`;
    return this._fetch(url).then(raw => {
      const data = raw?.observations;
      if (!data || !data.length) throw new Error('No Treasury yield data');

      const entries = data
        .filter(d => d.value !== '.')
        .sort((a, b) => new Date(a.date) - new Date(b.date))
        .slice(-60);

      const yields = entries.map(d => parseFloat(d.value));
      const current = yields[yields.length - 1];
      const prev30d  = yields[yields.length - 31] || yields[0];
      const change30d = current - prev30d;

      return {
        current,
        yields,
        change30d,
        falling: change30d < -0.15,   // Yield falling >15bps in 30d = bullish REITs
        rising:  change30d > +0.15    // Yield rising >15bps in 30d = bearish REITs
      };
    });
  }

  _fetchFedFundsRate() {
    // Federal funds rate — the primary lag driver
    const url = `https://api.stlouisfed.org/fred/series/observations?series_id=FEDFUNDS&api_key=${process.env.FRED_API_KEY_1}&file_type=json&limit=24&sort_order=desc`;
    return this._fetch(url).then(raw => {
      const data = raw?.observations;
      if (!data || !data.length) throw new Error('No Fed funds rate data');

      const entries = data
        .filter(d => d.value !== '.')
        .sort((a, b) => new Date(a.date) - new Date(b.date))
        .slice(-24); // Last 24 months

      const rates = entries.map(d => ({
        date:  d.date,
        value: parseFloat(d.value)
      }));

      const current  = rates[rates.length - 1].value;
      const prev     = rates[rates.length - 2]?.value || current;
      const prev6m   = rates[rates.length - 7]?.value || current;

      const lastChange = current - prev;
      const trend6m    = current - prev6m;

      return {
        current,
        rates,
        lastChange,
        trend6m,
        cutting:  lastChange < 0,           // Most recent move was a cut
        easing:   trend6m < -0.25,          // Cutting cycle in progress (>25bps over 6m)
        holding:  Math.abs(lastChange) < 0.01, // No change last month
        hiking:   lastChange > 0            // Most recent move was a hike
      };
    });
  }

  // ============================================================================
  // CONTEXT BUILDER
  // ============================================================================

  _buildMarketContext(reit, treasury, fed) {
    const closes  = reit.closes;
    const price   = reit.price;

    // SMA calculations
    const sma20 = this._sma(closes, 20);
    const sma50 = this._sma(closes, 50);

    // Price momentum
    const price4wAgo  = closes[closes.length - 20] || closes[0];
    const momentum4w  = ((price - price4wAgo) / price4wAgo) * 100;

    // Yield spread: REIT dividend yield vs 10Y Treasury
    // VNQ current yield ~4.0% — use as estimate if not available
    const reitYield     = 4.0; // Approximate — can be made dynamic
    const yieldSpread   = reitYield - treasury.current;
    const spreadFav     = yieldSpread > 0.5; // REITs yielding >50bps over Treasury

    // Days since last Fed decision (estimated from rate change detection)
    const rateHistory = fed.rates;
    let daysSinceDecision = 999;
    for (let i = rateHistory.length - 1; i >= 1; i--) {
      if (Math.abs(rateHistory[i].value - rateHistory[i - 1].value) > 0.01) {
        const decisionDate = new Date(rateHistory[i].date);
        daysSinceDecision  = Math.floor((Date.now() - decisionDate.getTime()) / 86400000);
        break;
      }
    }

    const now = new Date();

    return {
      symbol:            reit.symbol,
      price,
      closes,
      dates:             reit.dates,

      // Technical
      sma20,
      sma50,
      aboveSma20:        price > sma20,
      aboveSma50:        price > sma50,
      momentum4w,

      // Fed / Rate data
      fedRate:           fed.current,
      fedCutting:        fed.cutting,
      fedEasing:         fed.easing,
      fedHolding:        fed.holding,
      fedHiking:         fed.hiking,
      fedTrend6m:        fed.trend6m,
      daysSinceDecision,

      // Treasury
      treasuryYield:     treasury.current,
      treasuryFalling:   treasury.falling,
      treasuryRising:    treasury.rising,
      yieldChange30d:    treasury.change30d,

      // Spread
      yieldSpread,
      spreadFavourable:  spreadFav,

      // Meta
      timestamp:         now.toISOString(),
      dayOfWeek:         now.getUTCDay(),
      stale:             false,
      error:             false
    };
  }

  // ============================================================================
  // HELPERS
  // ============================================================================

  _sma(arr, period) {
    if (arr.length < period) return 0;
    const slice = arr.slice(-period);
    return +(slice.reduce((a, b) => a + b, 0) / period).toFixed(4);
  }

  _fetch(url) {
    return new Promise((resolve, reject) => {
      const req = https.get(url, {
        headers: { 'User-Agent': 'CCE-RME/1.0', 'Accept': 'application/json' }
      }, (res) => {
        let body = '';
        res.on('data', chunk => body += chunk);
        res.on('end', () => {
          if (res.statusCode !== 200) return reject(new Error(`Alpha Vantage returned ${res.statusCode}`));
          try { resolve(JSON.parse(body)); } catch (e) { reject(new Error('Parse failed')); }
        });
      });
      req.on('error', reject);
      req.setTimeout(15000, () => { req.destroy(); reject(new Error('Timeout')); });
    });
  }

  _neutralData() {
    return {
      symbol: this.reitSymbol, price: 0, closes: [], dates: [],
      sma20: 0, sma50: 0, aboveSma20: false, aboveSma50: false, momentum4w: 0,
      fedRate: 0, fedCutting: false, fedEasing: false, fedHolding: true,
      fedHiking: false, fedTrend6m: 0, daysSinceDecision: 999,
      treasuryYield: 0, treasuryFalling: false, treasuryRising: false, yieldChange30d: 0,
      yieldSpread: 0, spreadFavourable: false,
      timestamp: new Date().toISOString(), dayOfWeek: new Date().getUTCDay(),
      stale: true, error: true
    };
  }

  _delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
}

module.exports = RMEDataFeed;

// src/como-data-feed.js
// CCE Commodities Engine (COMO) — Multi-Commodity Cascade Data Feed
// Yahoo Finance: WTI Crude, Gold, Copper, DXY
// Alpha Vantage: WTI historical, economic indicators

'use strict';

const https = require('https');

class COMODataFeed {
  constructor(config = {}) {
    this.apiKey  = process.env.ALPHA_VANTAGE_API_KEY || 'demo';
    this._cache  = null;
    this._cacheTime = 0;
    this._cacheTTL  = 4 * 60 * 60 * 1000; // 4 hours
  }

  async getMarketData() {
    if (this._cache && (Date.now() - this._cacheTime) < this._cacheTTL) {
      return this._cache;
    }

    try {
      // Sequential fetches — avoid rate limiting
      console.log('[COMO] Fetching WTI crude...');
      const oilData    = await this._fetchYahoo('CL=F', '3mo', '1d');
      await this._delay(12000);

      console.log('[COMO] Fetching gold...');
      const goldData   = await this._fetchYahoo('GC=F', '3mo', '1d');
      await this._delay(12000);

      console.log('[COMO] Fetching copper...');
      const copperData = await this._fetchYahoo('HG=F', '3mo', '1d');
      await this._delay(12000);

      console.log('[COMO] Fetching DXY...');
      const dxyData    = await this._fetchYahoo('DX-Y.NYB', '3mo', '1d');

      const data = this._buildContext(oilData, goldData, copperData, dxyData);
      this._cache     = data;
      this._cacheTime = Date.now();
      return data;

    } catch (err) {
      console.error('[COMO] Data feed error:', err.message);
      if (this._cache) {
        console.warn('[COMO] Using stale cache');
        return { ...this._cache, stale: true };
      }
      return this._neutralData();
    }
  }

  // ============================================================================
  // YAHOO FINANCE FETCHER
  // ============================================================================

  _fetchYahoo(symbol, range = '3mo', interval = '1d') {
    return new Promise((resolve, reject) => {
      const encoded = encodeURIComponent(symbol);
      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encoded}?range=${range}&interval=${interval}&includePrePost=false`;
      const req = https.get(url, {
        headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' }
      }, (res) => {
        let body = '';
        res.on('data', chunk => body += chunk);
        res.on('end', () => {
          if (res.statusCode !== 200) return reject(new Error(`Yahoo ${symbol} returned ${res.statusCode}`));
          try { resolve(JSON.parse(body)); } catch (e) { reject(new Error(`Parse failed for ${symbol}`)); }
        });
      });
      req.on('error', reject);
      req.setTimeout(15000, () => { req.destroy(); reject(new Error(`Timeout: ${symbol}`)); });
    });
  }

  // ============================================================================
  // CONTEXT BUILDER
  // ============================================================================

  _buildContext(oilRaw, goldRaw, copperRaw, dxyRaw) {
    const oil    = this._parseYahoo(oilRaw,    'WTI');
    const gold   = this._parseYahoo(goldRaw,   'GOLD');
    const copper = this._parseYahoo(copperRaw, 'COPPER');
    const dxy    = this._parseYahoo(dxyRaw,    'DXY');

    if (!oil.valid) throw new Error('No WTI oil data');

    // Momentum calculations (5-day and 20-day)
    const oilMom5d  = this._momentum(oil.closes,    5);
    const oilMom20d = this._momentum(oil.closes,   20);
    const goldMom5d = this._momentum(gold.closes,   5);
    const copMom5d  = this._momentum(copper.closes, 5);
    const dxyMom5d  = this._momentum(dxy.closes,    5);

    // Volatility (ATR proxy — 5-day range average)
    const oilAtr  = this._atr(oil.closes,    5);
    const goldAtr = this._atr(gold.closes,   5);

    // Correlation signals
    // Oil/Gold correlation — normally positive during inflation
    const oilGoldCorr = this._correlation(oil.closes.slice(-20), gold.closes.slice(-20));

    // DXY inverse relationship — dollar strength suppresses commodities
    const dxyStrong    = dxyMom5d > 0.5;  // DXY rising > 0.5% in 5d
    const dxyWeakening = dxyMom5d < -0.5; // DXY falling > 0.5% in 5d

    // Oil signal strength
    const oilBullish = oilMom5d > 3.0;   // Oil up >3% in 5 days
    const oilBearish = oilMom5d < -3.0;  // Oil down >3% in 5 days
    const oilTrending = Math.abs(oilMom5d) > 3.0;

    // Gold lag signal — gold following oil with delay
    const goldFollowing = oilMom20d > 2.0 && goldMom5d > 0;

    // Copper lag signal — copper following oil with delay
    const copperFollowing = oilMom20d > 2.0 && copMom5d > 0;

    // SMA calculations
    const oilSma20  = this._sma(oil.closes,    20);
    const goldSma20 = this._sma(gold.closes,   20);
    const copSma20  = this._sma(copper.closes, 20);

    const now = new Date();

    return {
      // Oil (primary signal)
      oilPrice:         oil.price,
      oilCloses:        oil.closes,
      oilMom5d,
      oilMom20d,
      oilAtr,
      oilSma20,
      oilAboveSma20:    oil.price > oilSma20,
      oilBullish,
      oilBearish,
      oilTrending,

      // Gold (lag 1)
      goldPrice:        gold.price,
      goldCloses:       gold.closes,
      goldMom5d,
      goldAtr,
      goldSma20,
      goldAboveSma20:   gold.valid && gold.price > goldSma20,
      goldFollowing,

      // Copper (lag 2)
      copperPrice:      copper.price,
      copperCloses:     copper.closes,
      copMom5d,
      copSma20,
      copperAboveSma20: copper.valid && copper.price > copSma20,
      copperFollowing,

      // DXY
      dxyPrice:         dxy.price,
      dxyMom5d,
      dxyStrong,
      dxyWeakening,

      // Correlation
      oilGoldCorr,

      // Meta
      timestamp:        now.toISOString(),
      dayOfWeek:        now.getUTCDay(),
      stale:            false,
      error:            false
    };
  }

  _parseYahoo(raw, name) {
    try {
      const result = raw?.chart?.result?.[0];
      if (!result) return { valid: false, price: 0, closes: [] };

      const closes = (result.indicators?.quote?.[0]?.close || [])
        .filter(c => c !== null && !isNaN(c));

      if (!closes.length) return { valid: false, price: 0, closes: [] };

      return {
        valid:  true,
        price:  +closes[closes.length - 1].toFixed(4),
        closes: closes.map(c => +c.toFixed(4))
      };
    } catch (e) {
      console.warn(`[COMO] Parse warning for ${name}:`, e.message);
      return { valid: false, price: 0, closes: [] };
    }
  }

  // ============================================================================
  // HELPERS
  // ============================================================================

  _sma(arr, period) {
    if (arr.length < period) return arr.length ? +(arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(4) : 0;
    return +(arr.slice(-period).reduce((a, b) => a + b, 0) / period).toFixed(4);
  }

  _momentum(arr, period) {
    if (arr.length < period + 1) return 0;
    const current = arr[arr.length - 1];
    const past    = arr[arr.length - 1 - period];
    if (!past) return 0;
    return +((current - past) / past * 100).toFixed(2);
  }

  _atr(closes, period) {
    if (closes.length < period + 1) return 0;
    let sum = 0;
    for (let i = closes.length - period; i < closes.length; i++) {
      sum += Math.abs(closes[i] - closes[i - 1]);
    }
    return +(sum / period).toFixed(4);
  }

  _correlation(a, b) {
    const n = Math.min(a.length, b.length);
    if (n < 5) return 0;
    const ax = a.slice(-n), bx = b.slice(-n);
    const ma = ax.reduce((s, v) => s + v, 0) / n;
    const mb = bx.reduce((s, v) => s + v, 0) / n;
    let num = 0, da = 0, db = 0;
    for (let i = 0; i < n; i++) {
      num += (ax[i] - ma) * (bx[i] - mb);
      da  += (ax[i] - ma) ** 2;
      db  += (bx[i] - mb) ** 2;
    }
    return da && db ? +(num / Math.sqrt(da * db)).toFixed(3) : 0;
  }

  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  _neutralData() {
    return {
      oilPrice: 0, oilCloses: [], oilMom5d: 0, oilMom20d: 0,
      oilAtr: 0, oilSma20: 0, oilAboveSma20: false,
      oilBullish: false, oilBearish: false, oilTrending: false,
      goldPrice: 0, goldCloses: [], goldMom5d: 0, goldAtr: 0,
      goldSma20: 0, goldAboveSma20: false, goldFollowing: false,
      copperPrice: 0, copperCloses: [], copMom5d: 0,
      copSma20: 0, copperAboveSma20: false, copperFollowing: false,
      dxyPrice: 0, dxyMom5d: 0, dxyStrong: false, dxyWeakening: false,
      oilGoldCorr: 0,
      timestamp: new Date().toISOString(), dayOfWeek: new Date().getUTCDay(),
      stale: true, error: true
    };
  }
}

module.exports = COMODataFeed;

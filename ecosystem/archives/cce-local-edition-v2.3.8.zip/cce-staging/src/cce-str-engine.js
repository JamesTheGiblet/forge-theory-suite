// src/cce-str-engine.js
// O.E Strategist — Platform Intelligence and Recommendation Engine
//
// Runs on two modes:
// 1. AUTOMATIC — hourly analysis, proactive Telegram insights
// 2. ON-DEMAND — Telegram commands, responds to queries
//
// PASSIVE ONLY — never affects engine behaviour.
// Reads Observer database. Generates recommendations. Never acts.

'use strict';

const STRPatternEngine  = require('./str-strategy');
const STRStorageManager = require('./str-storage');
const OBSStorageManager = require('./obs-storage');

// Telegram commands
const COMMANDS = {
  '/briefing': 'Full platform intelligence briefing',
  '/predict':  'State transition predictions for all engines',
  '/patterns': 'Latest pattern insights from Observer data',
  '/regime':   'Current market regime analysis',
  '/allocate': 'Capital allocation recommendations',
  '/anomalies':'Recent anomalies detected',
  '/status':   'Quick platform status summary',
  '/help':     'List available commands'
};

class CCESTREngine {
  constructor(config, notifier) {
    this.config    = config;
    this.notifier  = notifier;
    this.engine    = new STRPatternEngine();
    this.storage   = new STRStorageManager(config.database?.path);
    this.obsStorage = new OBSStorageManager(config.database?.path);
    this.isRunning  = false;
    this.runCount   = 0;
    this.totalCapital = config.str?.totalCapital || 516;

    // Telegram polling state
    this.lastUpdateId = 0;
    this.telegramToken = config.telegram?.botToken || process.env.TELEGRAM_BOT_TOKEN;
    this.chatId        = config.telegram?.chatId   || process.env.TELEGRAM_CHAT_ID;
  }

  async start(intervalMinutes = 60) {
    this.isRunning = true;
    const intervalMs = intervalMinutes * 60 * 1000;

    await this.storage.init();
    await this.obsStorage.init();

    console.log('\n[STR] 🧠 Starting O.E Strategist');
    console.log(`[STR] ⏱️  Auto-analysis: every ${intervalMinutes}min`);
    console.log(`[STR] 💬 Telegram commands: active`);
    console.log(`[STR] 💰 Capital tracked: $${this.totalCapital}\n`);

    await this.notifier.send([
      `<b>[STR] 🧠 Strategist Started</b>`,
      `Auto-analysis: every ${intervalMinutes}min`,
      `Commands active: /briefing /predict /regime /allocate /anomalies /status /help`,
      `Capital tracked: $${this.totalCapital}`,
      ``,
      `<i>Type /help for available commands.</i>`
    ].join('\n'), 'info');

    // Start Telegram command polling
    this._startCommandPolling();

    // Run first analysis immediately
    await this._runAnalysis('startup');

    while (this.isRunning) {
      await this._sleep(intervalMs);
      if (!this.isRunning) break;
      await this._runAnalysis('scheduled');
    }

    console.log('[STR] 🛑 Strategist stopped.');
  }

  stop() {
    console.log('[STR] 🛑 Stopping Strategist...');
    this.isRunning = false;
    if (this._pollTimer) clearInterval(this._pollTimer);
    this.storage.close();
    this.obsStorage.close();
  }

  // ============================================================================
  // AUTOMATIC ANALYSIS
  // ============================================================================

  async _runAnalysis(trigger) {
    try {
      this.runCount++;
      console.log(`\n[STR] 🧠 Analysis #${this.runCount} (${trigger})`);

      const observations = await this.obsStorage.getObservations(2000);
      const transitions  = await this.obsStorage.getTransitions(100);

      if (observations.length < 5) {
        console.log('[STR] ⚠️  Insufficient data — need 5+ observations');
        return;
      }

      // Run all analyses
      const regime      = this.engine.analyseCurrentRegime(observations);
      const predictions = this.engine.predictTransitions(observations, transitions);
      const allocRec    = this.engine.recommendAllocations(observations, transitions, this.totalCapital);
      const anomalies   = this.engine.detectAnomalies(observations);

      console.log(`[STR]    Regime: ${regime?.regime}`);
      console.log(`[STR]    Anomalies: ${anomalies.length}`);
      console.log(`[STR]    Data: ${observations.length} obs, ${transitions.length} transitions`);

      // Store results
      if (allocRec) await this.storage.logAllocationRec(allocRec);
      await this.storage.logPredictions(predictions);
      for (const anomaly of anomalies) {
        await this.storage.logAnomaly(anomaly);
      }

      // Send proactive alerts for high-severity anomalies
      const highSeverity = anomalies.filter(a => a.severity === 'HIGH');
      if (highSeverity.length) {
        await this.notifier.send([
          `<b>[STR] ⚠️ High Severity Anomaly Detected</b>`,
          ``,
          ...highSeverity.map(a => `🔴 ${a.description}`)
        ].join('\n'), 'error');
      }

      // Hourly scheduled — send regime summary if changed
      if (trigger === 'scheduled') {
        const prevBriefing = await this.storage.getLatestBriefing();
        if (!prevBriefing || prevBriefing.regime !== regime?.regime) {
          await this._sendRegimeAlert(regime);
        }
      }

      // Store briefing
      const briefingText = this.engine.generateBriefing(observations, transitions, this.totalCapital);
      await this.storage.logBriefing(trigger, regime?.regime, observations.length, briefingText);

    } catch (err) {
      console.error('[STR] ❌ Analysis error:', err.message);
    }
  }

  // ============================================================================
  // TELEGRAM COMMAND INTERFACE
  // ============================================================================

  _startCommandPolling() {
    if (!this.telegramToken) {
      console.log('[STR] ⚠️  No Telegram token — command polling disabled');
      return;
    }

    // Poll every 5 seconds for new messages
    this._pollTimer = setInterval(() => this._pollTelegram(), 5000);
    console.log('[STR] 💬 Telegram command polling active');
  }

  async _pollTelegram() {
    try {
      const https = require('https');
      const url   = `https://api.telegram.org/bot${this.telegramToken}/getUpdates?offset=${this.lastUpdateId + 1}&timeout=1`;

      const body = await new Promise((resolve, reject) => {
        https.get(url, res => {
          let data = '';
          res.on('data', c => data += c);
          res.on('end', () => resolve(data));
        }).on('error', reject);
      });

      const data = JSON.parse(body);
      if (!data.ok || !data.result?.length) return;

      for (const update of data.result) {
        this.lastUpdateId = update.update_id;
        const msg = update.message?.text;
        const chatId = update.message?.chat?.id?.toString();

        // Only respond to our chat
        if (chatId !== this.chatId?.toString()) continue;
        if (!msg) continue;

        await this._handleCommand(msg.trim());
      }
    } catch (err) {
      // Silently ignore polling errors
    }
  }

  async _handleCommand(msg) {
    const cmd = msg.split(' ')[0].toLowerCase();
    console.log(`[STR] 💬 Command received: ${msg}`);

    const observations = await this.obsStorage.getObservations(2000);
    const transitions  = await this.obsStorage.getTransitions(100);

    switch (cmd) {
      case '/briefing':
        await this._cmdBriefing(observations, transitions);
        break;
      case '/predict':
        await this._cmdPredict(observations, transitions);
        break;
      case '/regime':
        await this._cmdRegime(observations);
        break;
      case '/allocate':
        await this._cmdAllocate(observations, transitions);
        break;
      case '/anomalies':
        await this._cmdAnomalies(observations);
        break;
      case '/patterns':
        await this._cmdPatterns();
        break;
      case '/status':
        await this._cmdStatus(observations, transitions);
        break;
      case '/help':
        await this._cmdHelp();
        break;
      default:
        if (observations.length < 5) {
          await this.notifier.send('[STR] Not enough data yet. Need 5+ observations.', 'info');
        }
    }

    await this.storage.logQuery(msg, 'handled', 'telegram');
  }

  async _cmdBriefing(observations, transitions) {
    if (observations.length < 5) {
      await this.notifier.send('[STR] 🧠 Not enough data yet for a full briefing. Check back after more observations.', 'info');
      return;
    }
    const briefing = this.engine.generateBriefing(observations, transitions, this.totalCapital);
    await this.notifier.send(`<b>[STR] 🧠 Platform Briefing</b>\n\n<pre>${briefing}</pre>`, 'info');
  }

  async _cmdPredict(observations, transitions) {
    if (observations.length < 5) {
      await this.notifier.send('[STR] Not enough data for predictions yet.', 'info');
      return;
    }
    const predictions = this.engine.predictTransitions(observations, transitions);
    const lines = ['<b>[STR] 🔮 Transition Predictions</b>', ''];
    Object.entries(predictions).forEach(([engine, pred]) => {
      lines.push(`<b>${engine.toUpperCase()}</b>`);
      lines.push(`State: ${pred.currentState} (${pred.daysInState}d)`);
      lines.push(`${pred.prediction}`);
      lines.push(`Confidence: ${pred.confidence}%`);
      lines.push('');
    });
    await this.notifier.send(lines.join('\n'), 'info');
  }

  async _cmdRegime(observations) {
    if (observations.length < 5) {
      await this.notifier.send('[STR] Not enough data for regime analysis yet.', 'info');
      return;
    }
    const regime = this.engine.analyseCurrentRegime(observations);
    await this.notifier.send([
      `<b>[STR] 🌡️ Market Regime</b>`,
      ``,
      `Regime: <b>${regime.regime}</b>`,
      `${regime.description}`,
      `Outlook: ${regime.outlook}`,
      ``,
      `F&G: ${regime.currentFG} (${regime.fgTrend})`,
      `VIX: ${regime.currentVIX} (${regime.vixTrend})`,
      `BTC: $${Math.round(regime.btcPrice).toLocaleString()} (${regime.btcTrend})`,
      ``,
      `Based on ${regime.obsCount} observations`
    ].join('\n'), 'info');
  }

  async _cmdAllocate(observations, transitions) {
    if (observations.length < 5) {
      await this.notifier.send('[STR] Not enough data for allocation recommendations yet.', 'info');
      return;
    }
    const rec = this.engine.recommendAllocations(observations, transitions, this.totalCapital);
    await this.notifier.send([
      `<b>[STR] 💰 Allocation Recommendations</b>`,
      `Regime: ${rec.regime}`,
      `Total: $${rec.totalCapital}`,
      ``,
      ...Object.entries(rec.allocations).map(([e, a]) =>
        `${e.toUpperCase()}: $${a} (score: ${rec.scores[e]})`
      ),
      ``,
      `<i>Recommendations only — no automatic action taken.</i>`
    ].join('\n'), 'info');
  }

  async _cmdAnomalies(observations) {
    const anomalies = this.engine.detectAnomalies(observations);
    if (!anomalies.length) {
      await this.notifier.send('[STR] ✅ No anomalies detected.', 'info');
      return;
    }
    await this.notifier.send([
      `<b>[STR] ⚠️ Anomalies</b>`,
      ``,
      ...anomalies.map(a => `[${a.severity}] ${a.description}`)
    ].join('\n'), 'info');
  }

  async _cmdPatterns() {
    const patterns = await this.obsStorage.getLatestPatterns(5);
    if (!patterns.length) {
      await this.notifier.send('[STR] No patterns generated yet. Check back after 96 observations.', 'info');
      return;
    }
    await this.notifier.send([
      `<b>[STR] 🧬 Latest Patterns</b>`,
      ``,
      ...patterns.map(p => `• ${p.description} (${p.obs_count} obs)`)
    ].join('\n'), 'info');
  }

  async _cmdStatus(observations, transitions) {
    const latest = observations[observations.length - 1];
    await this.notifier.send([
      `<b>[STR] 📊 Quick Status</b>`,
      ``,
      `Observations: ${observations.length}`,
      `Transitions: ${transitions.length}`,
      `Strategist runs: ${this.runCount}`,
      ``,
      latest ? [
        `BTC: $${Math.round(latest.btc_price).toLocaleString()}`,
        `F&G: ${latest.fear_greed}`,
        `VIX: ${latest.vix}`,
        `Last obs: ${new Date(latest.timestamp).toLocaleTimeString()}`
      ].join('\n') : 'No data yet'
    ].join('\n'), 'info');
  }

  async _cmdHelp() {
    const lines = ['<b>[STR] 🧠 Available Commands</b>', ''];
    Object.entries(COMMANDS).forEach(([cmd, desc]) => {
      lines.push(`${cmd} — ${desc}`);
    });
    await this.notifier.send(lines.join('\n'), 'info');
  }

  async _sendRegimeAlert(regime) {
    await this.notifier.send([
      `<b>[STR] 🌡️ Market Regime Update</b>`,
      ``,
      `<b>${regime.regime}</b>`,
      `${regime.description}`,
      `Outlook: ${regime.outlook}`,
      ``,
      `F&G: ${regime.currentFG} (${regime.fgTrend})`,
      `VIX: ${regime.currentVIX}`
    ].join('\n'), 'info');
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = CCESTREngine;

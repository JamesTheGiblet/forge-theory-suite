// src/cce-engine.js
// PRODUCTION CCE Engine - Integrates all components

'use strict';

const fs = require('fs');
const path = require('path');
const {
  CCEStateMachine,
  CCERebalancer,
  TechnicalSignals,
  SentimentSignals,
  ZombieScanner
} = require('../src/strategy');
const ExchangeConnector = require('../src/exchange-connector');
const MarketDataFeed = require('../src/data-feed');
const StorageManager = require('../src/storage');
const NotificationService = require('../src/notification');

// Log directory at project root (not src/logs)
const isPkg = typeof process.pkg !== 'undefined';
const basePath = isPkg ? path.dirname(process.execPath) : path.join(__dirname, '..');
const LOG_DIR = path.join(basePath, 'logs');

class CCEEngine {
  constructor(config) {
    this.config = config;

    this.stateMachine  = new CCEStateMachine(config.states || {});
    this.rebalancer    = new CCERebalancer(config);
    this.zombieScanner = new ZombieScanner(config);
    this.exchange      = new ExchangeConnector(config);
    this.dataFeed      = new MarketDataFeed(config);
    this.storage       = new StorageManager(config.database?.path);
    this.notifier      = new NotificationService(config);
    this.signals = {
      technical: new TechnicalSignals(config),
      sentiment: new SentimentSignals(config)
    };

    this.isRunning       = false;
    this.runCount        = 0;
    this.dryRun          = config.execution?.dryRun !== false; // Safe default: dry run
    this.lastReportValue = config.trading?.startingCapital || 300;
    this.dominanceHistory = []; // Rolling dominance history for signal calculation

    this._resetDailyStats(config.trading?.startingCapital || 300, 0);
  }

  // ============================================================================
  // MAIN LOOP
  // ============================================================================

  async start(intervalHours = 4) {
    this.isRunning = true;
    const intervalMs = intervalHours * 60 * 60 * 1000;

    console.log('\n🚀 Starting CCE Engine');
    console.log(`⏱️  Check Interval: ${intervalHours} hours`);
    console.log(`💰 Starting Capital: $${this.config.trading?.startingCapital || 300}`);
    console.log(`🔧 Dry Run Mode: ${this.dryRun ? 'YES (Safe)' : 'NO - LIVE TRADING ⚠️'}`);
    console.log(`📍 Initial State: ${this.stateMachine.currentState}\n`);

    // Note: index.js already handles the live trading countdown warning
    // No additional delay added here to avoid double-warning

    while (this.isRunning) {
      await this.runCycle();

      if (!this.isRunning) break; // Circuit breaker may have fired during cycle

      const nextRun = new Date(Date.now() + intervalMs);
      console.log(`⏳ Next run: ${nextRun.toLocaleString()}`);
      await this._sleep(intervalMs);
    }

    console.log('🛑 CCE Engine loop exited.');
  }

  stop() {
    console.log('\n🛑 Stopping CCE Engine...');
    this.isRunning = false;
    this.notifier.send('<b>CCE Engine Stopping...</b>', 'warning');
  }

  // ============================================================================
  // CYCLE
  // ============================================================================

  async runCycle() {
    try {
      this.runCount++;
      console.log(`\n${'='.repeat(70)}`);
      console.log(`🔄 CCE RUN #${this.runCount} - ${new Date().toISOString()}`);
      console.log(`   State: ${this.stateMachine.currentState}`);
      console.log(`   Strategy: ${this._getStateSummary(this.stateMachine.currentState)} (Conservative v2.1)`);
      console.log(`   Mode: ${this.dryRun ? 'DRY RUN' : '⚠️  LIVE TRADING'}`);
      console.log(`${'='.repeat(70)}`);

      // 1. Fetch market data
      const marketData = await this.dataFeed.getMarketData();
      console.log(`💰 BTC Price: $${marketData.btc_price?.toFixed(2) || 'N/A'}`);
      this.lastBtcPrice  = marketData.btc_price || 0;
      this.lastDominance = marketData.btc_dominance || 0;
      if (this.dominanceHistory.length >= 30) this.dominanceHistory.shift();
      this.dominanceHistory.push(marketData.btc_dominance || 0);
      console.log(`😰 Fear & Greed: ${marketData.fear_greed_index?.value || 'N/A'}`);
      console.log(`📊 BTC Dominance: ${marketData.btc_dominance?.toFixed(1) || 'N/A'}%`);

      if (this.dailyStats.btcStartPrice === 0) {
        this.dailyStats.btcStartPrice = marketData.btc_price;
      }

      // 2. Get portfolio and value
      const portfolio = await this.exchange.getPortfolioBalances();
      const portfolioValue = this._calculatePortfolioValue(portfolio, marketData);
      console.log(`💼 Portfolio Value: $${portfolioValue.toFixed(2)}`);

      // 🛡️ CIRCUIT BREAKER
      const startCap = this.config.trading?.startingCapital || 300;
      const totalReturnPct = ((portfolioValue - startCap) / startCap) * 100;
      const circuitBreakerThreshold = this.config.trading?.circuitBreakerPct || -20;

      if (totalReturnPct <= circuitBreakerThreshold) {
        const msg = `🚨 CIRCUIT BREAKER TRIGGERED! Drawdown: ${totalReturnPct.toFixed(2)}% (Limit: ${circuitBreakerThreshold}%).`;
        console.error(`\n${msg}`);
        console.error('   🛑 Stopping engine immediately to protect remaining capital.');

        await this.notifier.send(
          `<b>🚨 CIRCUIT BREAKER TRIGGERED</b>\nDrawdown: ${totalReturnPct.toFixed(2)}%\nValue: $${portfolioValue.toFixed(2)}\nAction: EMERGENCY STOP`,
          'error'
        );

        this.stop(); // Sets isRunning = false; loop exits after cycle returns
        return;
      }

      // 3. Calculate signals and scan
      const signals        = this._calculateSignals(marketData);
      const zombies        = this.zombieScanner.scan(marketData);
      const sentimentScore = this.signals.sentiment.getSentimentScore(marketData);

      // Update daily tracking
      this.dailyStats.fearGreedSum += sentimentScore;
      this.dailyStats.fearGreedCount++;
      if (portfolioValue < this.dailyStats.minPortfolioValue) {
        this.dailyStats.minPortfolioValue = portfolioValue;
      }
      if (
        this.stateMachine.currentState !== 'DORMANT' &&
        this.stateMachine.currentState !== 'EXTRACTION'
      ) {
        this.dailyStats.marketTimeCount++;
      }

      // 4. Build context and evaluate transition
      const context = {
        currentState:     this.stateMachine.currentState,
        currentTimestamp: new Date(),
        btcPrice:         marketData.btc_price,
        btcDominance:     marketData.btc_dominance,
        fearGreedIndex:   sentimentScore,
        etfFlows7d:       marketData.etf_flows_7d || 0,
        portfolioValue,
        signals
      };

      const progress   = this.stateMachine.getTransitionProgress(context);
      const transition = this.stateMachine.evaluateTransition(context);

      if (transition.transitioned) {
        console.log(`\n📝 STATE CHANGE: ${transition.from} → ${transition.to}`);
        console.log(`   Reason: ${transition.reason}`);
        this.dailyStats.stateChanges++;

        await this.storage.logStateChange({
          from:      transition.from,
          to:        transition.to,
          reason:    transition.reason,
          timestamp: transition.timestamp
        });

        await this.notifier.send(
          `<b>State Change Detected</b>\n${transition.from} ➡️ ${transition.to}\nReason: ${transition.reason}`,
          'state'
        );

        // 5. Execute rebalancing
        const prices = {
          BTC:  marketData.btc_price,
          ETH:  marketData.eth_price  || 0,
          SOL:  marketData.sol_price  || 0,
          USDC: 1.00,
          RNDR: marketData.rndr_price || 0,
          FET:  marketData.fet_price  || 0
        };

        const { actions } = this.rebalancer.rebalanceForState(
          portfolio,
          transition.to,
          prices,
          zombies
        );

        console.log(`\n🔄 Rebalancing: ${actions.length} actions`);

        for (const action of actions) {
          console.log(`   ${action.action.toUpperCase()} ${action.amount.toFixed(6)} ${action.symbol} @ $${action.price.toFixed(2)}`);
          console.log(`      Value: $${action.value.toFixed(2)} - ${action.reason}`);

          try {
            const trade = await this.exchange.executeTrade(action);

            await this.storage.logTrade({
              symbol:  action.symbol,
              side:    action.action,
              amount:  action.amount,
              price:   action.price,
              value:   action.value,
              reason:  (this.dryRun ? '[DRY RUN] ' : '') + action.reason,
              orderId: trade.orderId
            });

            this.dailyStats.tradesExecuted++;
            const logPrefix = this.dryRun ? '[DRY RUN] Simulated' : '✅';
            console.log(`      ${logPrefix} Trade executed: Order ID ${trade.orderId}`);

            await this.notifier.send(
              `<b>${this.dryRun ? '[DRY RUN] ' : ''}Trade Executed</b>\n${action.action.toUpperCase()} ${action.amount.toFixed(6)} ${action.symbol} @ $${action.price.toFixed(2)}\nValue: $${action.value.toFixed(2)}`,
              'trade'
            );
          } catch (error) {
            console.error(`      ❌ Trade failed for ${action.symbol}:`, error.message);
            await this._handleTradeError(action, error);
          }
        }
      } else {
        console.log(`\n✅ State: ${this.stateMachine.currentState} (no change)`);
        console.log(`   Days in state: ${this._getDaysInCurrentState().toFixed(1)}`);
      }

      // 6. Save snapshot and log cycle
      await this.storage.savePortfolioSnapshot(portfolio, this.stateMachine.currentState);

      const totalReturn = ((portfolioValue - startCap) / startCap) * 100;
      const dailyReturn = this.lastReportValue > 0
        ? ((portfolioValue - this.lastReportValue) / this.lastReportValue) * 100
        : 0;

      await this.storage.logCycle({
        cycle_number:         this.runCount,
        btc_price:            marketData.btc_price,
        fear_greed:           marketData.fear_greed_index?.value || 50,
        btc_dominance:        marketData.btc_dominance,
        etf_flows_7d:         marketData.etf_flows_7d,
        current_state:        this.stateMachine.currentState,
        previous_state:       this.stateMachine.previousState || 'N/A',
        days_in_state:        this._getDaysInCurrentState(),
        portfolio_value:      portfolioValue,
        btc_holdings:         portfolio.BTC  || 0,
        usdc_holdings:        (portfolio.USDC || 0) + (portfolio.USD || 0),
        daily_return:         dailyReturn,
        total_return:         totalReturn,
        btc_above_20_sma:     signals.btc_above_20_sma,
        sma_20_above_50:      signals.sma_20_above_50,
        btc_was_strong_3d_ago: signals.btc_was_strong_3d_ago,
        btc_was_strong_7d_ago: signals.btc_was_strong_7d_ago,
        transition_progress:  progress.percent,
        transition_message:   progress.label
        // max_drawdown and sharpe_ratio omitted — not yet implemented
      });

      // 7. Periodic report (every 6 cycles ≈ 24 hours at 4h interval)
      if (this.runCount > 0 && this.runCount % 6 === 0) {
        await this._generateDailyReport(portfolioValue, marketData.btc_price);
      }

      console.log(`\n${'='.repeat(70)}\n`);

    } catch (error) {
      console.error('\n❌ ERROR in CCE cycle:', error);
      await this._handleError(error);
    }
  }

  // ============================================================================
  // REPORTING
  // ============================================================================

  async _generateDailyReport(currentValue, currentBtcPrice) {
    const change    = currentValue - this.lastReportValue;
    const changePct = this.lastReportValue > 0
      ? (change / this.lastReportValue) * 100
      : 0;

    const btcReturn = this.dailyStats.btcStartPrice > 0
      ? ((currentBtcPrice - this.dailyStats.btcStartPrice) / this.dailyStats.btcStartPrice) * 100
      : 0;
    const alpha           = changePct - btcReturn;
    const avgFearGreed    = this.dailyStats.fearGreedCount > 0
      ? this.dailyStats.fearGreedSum / this.dailyStats.fearGreedCount
      : 0;
    const maxDrawdown24h  = this.lastReportValue > 0
      ? ((this.dailyStats.minPortfolioValue - this.lastReportValue) / this.lastReportValue) * 100
      : 0;
    const timeInMarketPct = (this.dailyStats.marketTimeCount / 6) * 100;

    console.log(`\n📈 PERIODIC REPORT (Run ${this.runCount})`);
    console.log(`   Current Value:  $${currentValue.toFixed(2)}`);
    console.log(`   Change (Since last report): ${change >= 0 ? '+' : ''}$${change.toFixed(2)} (${changePct.toFixed(2)}%)`);
    console.log(`   Alpha vs BTC: ${alpha >= 0 ? '+' : ''}${alpha.toFixed(2)}%`);

    const reportData = {
      report_date:  new Date().toISOString().split('T')[0],
      cycles_completed: this.runCount,
      performance: {
        start_value:  this.lastReportValue,
        end_value:    currentValue,
        daily_return: `${changePct.toFixed(2)}%`,
        btc_return:   `${btcReturn.toFixed(2)}%`,
        alpha:        `${alpha.toFixed(2)}%`
      },
      activity: {
        state_changes:   this.dailyStats.stateChanges,
        trades_executed: this.dailyStats.tradesExecuted,
        avg_fear_greed:  avgFearGreed.toFixed(1)
      },
      risk: {
        max_drawdown_24h: `${maxDrawdown24h.toFixed(2)}%`,
        time_in_market:   `${timeInMarketPct.toFixed(1)}%`
      }
    };

    // 1. Save to database
    try {
      await this.storage.saveDailyReport({
        report_date:       reportData.report_date,
        cycles_completed:  this.runCount,
        start_value:       this.lastReportValue,
        end_value:         currentValue,
        daily_return:      changePct,
        btc_return:        btcReturn,
        alpha,
        state_changes:     this.dailyStats.stateChanges,
        trades_executed:   this.dailyStats.tradesExecuted,
        avg_fear_greed:    avgFearGreed,
        max_drawdown_24h:  maxDrawdown24h,
        time_in_market_pct: timeInMarketPct,
        report_json:       reportData
      });
    } catch (e) {
      console.error('Error saving report to DB:', e.message);
    }

    // 2. Append to project-root log file
    try {
      if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
      const logLine = `[${new Date().toISOString()}] Run #${this.runCount} | Value: $${currentValue.toFixed(2)} | Daily: ${changePct.toFixed(2)}% | Alpha: ${alpha.toFixed(2)}%\n`;
      fs.appendFileSync(path.join(LOG_DIR, 'reports.log'), logLine);
    } catch (e) {
      console.error('Error writing report log:', e.message);
    }

    // 3. Send notification
    await this.notifier.send(
      `<b>Daily Report</b>\nValue: $${currentValue.toFixed(2)}\nChange: ${changePct.toFixed(2)}%\nAlpha: ${alpha.toFixed(2)}%`,
      'report'
    );

    this.lastReportValue = currentValue;
    this._resetDailyStats(currentValue, currentBtcPrice);
  }

  // ============================================================================
  // HELPERS
  // ============================================================================

  _resetDailyStats(baseValue, btcPrice) {
    this.dailyStats = {
      btcStartPrice:    btcPrice,
      stateChanges:     0,
      tradesExecuted:   0,
      fearGreedSum:     0,
      fearGreedCount:   0,
      minPortfolioValue: baseValue,
      marketTimeCount:  0
    };
  }

  _getDaysInCurrentState() {
    const msInState = Date.now() - this.stateMachine.stateEnteredAt.getTime();
    return msInState / (1000 * 60 * 60 * 24);
  }

  _calculatePortfolioValue(portfolio, marketData) {
    const baseCurrency = this.config.trading?.baseCurrency || 'USD';
    const baseValue = (baseCurrency !== 'USD' && baseCurrency !== 'USDC')
      ? (portfolio[baseCurrency] || 0)
      : 0;

    return (
      baseValue +
      (portfolio.USD  || 0) +
      (portfolio.BTC  || 0) * (marketData.btc_price  || 0) +
      (portfolio.ETH  || 0) * (marketData.eth_price  || 0) +
      (portfolio.SOL  || 0) * (marketData.sol_price  || 0) +
      (portfolio.USDC || 0) * 1.00 +
      (portfolio.RNDR || 0) * (marketData.rndr_price || 0) +
      (portfolio.FET  || 0) * (marketData.fet_price  || 0)
    );
  }

  _calculateSignals(marketData) {
    return this.signals.technical.getAllSignals(
      marketData.btc_price,
      marketData.btc_dominance,
      marketData.historical_prices || [],
      this.dominanceHistory
    );
  }

  async _handleError(error) {
    console.error('💥 System Error:', error);
    await this.notifier.send(`<b>System Error</b>\n${error.message}`, 'error');
  }

  async _handleTradeError(action, error) {
    console.error(`Trade execution failed for ${action.symbol}:`, error.message);
    await this.notifier.send(
      `<b>⚠️ Trade Failed</b>\n${action.action.toUpperCase()} ${action.symbol}\nReason: ${error.message}\n<i>Portfolio may be in partial state — review required.</i>`,
      'error'
    );
    // TODO: Implement retry logic and partial fill detection
  }

  _getStateSummary(state) {
    const summaries = {
      DORMANT:      'Defensive (100% Cash) - Waiting for uptrend',
      ACCUMULATION: 'Entry (25% BTC) - Testing waters',
      ANCHOR:       'Conservative (50% BTC) - Reducing risk',
      IGNITION:     'Aggressive (100% BTC) - Riding trend',
      CASCADE_1:    'Rotation (Alts) - Capturing alpha',
      CASCADE_2:    'High Velocity - Max risk/reward',
      SPILLWAY:     'Profit Taking - Exiting alts',
      EXTRACTION:   'Exit - Market crash protection'
    };
    return summaries[state] || 'Unknown';
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = CCEEngine;
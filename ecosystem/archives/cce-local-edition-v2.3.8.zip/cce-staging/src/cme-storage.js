// src/cme-storage.js
// CCE Stocks Engine (CME) — sql.js persistence layer

'use strict';

const path = require('path');
const fs   = require('fs');

class CMEStorageManager {
  constructor(dbPath) {
    const basePath = path.join(__dirname, '..');
    this.dbPath = dbPath
      ? dbPath.replace('cce-production.db', 'cme-production.db')
      : path.join(basePath, 'data', 'cme-production.db');
    this.db = null;
  }

  async init() {
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const initSqlJs = require('sql.js');
    const SQL = await initSqlJs();

    if (fs.existsSync(this.dbPath)) {
      const buf = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(buf);
    } else {
      this.db = new SQL.Database();
    }

    this._createTables();
    this._saveTimer = setInterval(() => this._persist(), 60000);
    console.log('[CME] Storage initialised (sql.js)');
  }

  _createTables() {
    this.db.run(`CREATE TABLE IF NOT EXISTS cme_cycles (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp        DATETIME,
      cycle_number     INTEGER,
      state            TEXT,
      previous_state   TEXT,
      price            REAL,
      sma50            REAL,
      sma200           REAL,
      rsi              REAL,
      vix              REAL,
      breadth_score    REAL,
      momentum_4w      REAL,
      volume           REAL,
      avg_volume       REAL,
      days_in_state    REAL,
      portfolio_value  REAL,
      daily_return     REAL,
      total_return     REAL,
      above_sma50      INTEGER,
      above_sma200     INTEGER,
      golden_cross     INTEGER,
      volume_confirming INTEGER
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS cme_trades (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp        DATETIME,
      action           TEXT,
      symbol           TEXT,
      price            REAL,
      portfolio_value  REAL,
      rsi              REAL,
      vix              REAL,
      sma50            REAL,
      sma200           REAL,
      breadth_score    REAL,
      days_held        REAL,
      return_pct       REAL,
      reason           TEXT,
      outcome          TEXT
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS cme_snapshots (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp        DATETIME,
      state            TEXT,
      portfolio_value  REAL,
      price            REAL,
      total_return     REAL
    )`);
  }

  _persist() {
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (err) {
      console.error('[CME] Persist error:', err.message);
    }
  }

  async logCycle(data) {
    this.db.run(
      `INSERT INTO cme_cycles (
        timestamp, cycle_number, state, previous_state, price,
        sma50, sma200, rsi, vix, breadth_score, momentum_4w,
        volume, avg_volume, days_in_state, portfolio_value,
        daily_return, total_return,
        above_sma50, above_sma200, golden_cross, volume_confirming
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.cycle_number, data.state, data.previous_state,
        data.price, data.sma50, data.sma200, data.rsi, data.vix,
        data.breadth_score, data.momentum_4w, data.volume, data.avg_volume,
        data.days_in_state, data.portfolio_value, data.daily_return, data.total_return,
        data.above_sma50 ? 1 : 0, data.above_sma200 ? 1 : 0,
        data.golden_cross ? 1 : 0, data.volume_confirming ? 1 : 0
      ]
    );
    this._persist();
  }

  async logTrade(data) {
    this.db.run(
      `INSERT INTO cme_trades (
        timestamp, action, symbol, price, portfolio_value,
        rsi, vix, sma50, sma200, breadth_score,
        days_held, return_pct, reason, outcome
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.action, data.symbol, data.price,
        data.portfolio_value, data.rsi, data.vix, data.sma50, data.sma200,
        data.breadth_score, data.days_held || 0, data.return_pct || 0,
        data.reason, data.outcome || ''
      ]
    );
    this._persist();
  }

  async saveSnapshot(portfolioValue, state, price, totalReturn) {
    this.db.run(
      `INSERT INTO cme_snapshots (timestamp, state, portfolio_value, price, total_return)
       VALUES (?, ?, ?, ?, ?)`,
      [new Date().toISOString(), state, portfolioValue, price, totalReturn]
    );
    this._persist();
  }

  async getLatestCycle() {
    const result = this.db.exec('SELECT * FROM cme_cycles ORDER BY timestamp DESC LIMIT 1');
    if (!result.length) return null;
    const { columns, values } = result[0];
    const obj = {};
    columns.forEach((col, i) => obj[col] = values[0][i]);
    return obj;
  }

  async getTradeHistory(limit = 20) {
    const result = this.db.exec(
      `SELECT * FROM cme_trades ORDER BY timestamp DESC LIMIT ${limit}`
    );
    if (!result.length) return [];
    const { columns, values } = result[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  }

  close() {
    if (this._saveTimer) clearInterval(this._saveTimer);
    this._persist();
    this.db.close();
    console.log('[CME] Storage closed.');
  }
}

module.exports = CMEStorageManager;

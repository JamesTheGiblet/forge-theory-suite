// src/egp-storage.js
// S.E EGP — sql.js persistence layer

'use strict';

const path = require('path');
const fs   = require('fs');

class EGPStorageManager {
  constructor(dbPath) {
    const basePath = path.join(__dirname, '..');
    this.dbPath = dbPath
      ? dbPath.replace('cce-production.db', 'egp-production.db')
      : path.join(basePath, 'data', 'egp-production.db');
    this.db = null;
  }

  async init() {
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const initSqlJs = require('sql.js');
    const SQL = await initSqlJs();

    if (fs.existsSync(this.dbPath)) {
      const buf = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(buf);
    } else {
      this.db = new SQL.Database();
    }

    this._createTables();
    this._saveTimer = setInterval(() => this._persist(), 30000);
    console.log('[EGP] Storage initialised (sql.js)');
  }

  _createTables() {
    this.db.run(`CREATE TABLE IF NOT EXISTS egp_cycles (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp         DATETIME,
      run_number        INTEGER,
      state             TEXT,
      prev_state        TEXT,
      composite_score   INTEGER,
      divergence_flag   INTEGER,
      cbe_rate          REAL,
      cbe_rate_delta    REAL,
      inflation         REAL,
      inflation_delta   REAL,
      reserves          REAL,
      reserves_delta    REAL,
      brent_level       REAL,
      cds_delta         REAL,
      usd_egp_rate      REAL,
      reason            TEXT,
      next_cbe_meeting  TEXT
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS egp_transitions (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp         DATETIME,
      from_state        TEXT,
      to_state          TEXT,
      composite_score   INTEGER,
      divergence_flag   INTEGER,
      trigger_signal    TEXT,
      usd_egp_rate      REAL
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS egp_manual_inputs (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp         DATETIME,
      input_type        TEXT,
      value             REAL,
      notes             TEXT
    )`);
  }

  _persist() {
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (err) {
      console.error('[EGP] Persist error:', err.message);
    }
  }

  async logCycle(data) {
    this.db.run(
      `INSERT INTO egp_cycles (
        timestamp, run_number, state, prev_state, composite_score,
        divergence_flag, cbe_rate, cbe_rate_delta, inflation,
        inflation_delta, reserves, reserves_delta, brent_level,
        cds_delta, usd_egp_rate, reason, next_cbe_meeting
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.run_number, data.state,
        data.prev_state, data.composite_score,
        data.divergence_flag ? 1 : 0, data.cbe_rate, data.cbe_rate_delta,
        data.inflation, data.inflation_delta, data.reserves,
        data.reserves_delta, data.brent_level, data.cds_delta,
        data.usd_egp_rate, data.reason, data.next_cbe_meeting
      ]
    );
    this._persist();
  }

  async logTransition(data) {
    this.db.run(
      `INSERT INTO egp_transitions (
        timestamp, from_state, to_state, composite_score,
        divergence_flag, trigger_signal, usd_egp_rate
      ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.from_state, data.to_state,
        data.composite_score, data.divergence_flag ? 1 : 0,
        data.trigger_signal, data.usd_egp_rate
      ]
    );
    this._persist();
  }

  async logManualInput(type, value, notes) {
    this.db.run(
      `INSERT INTO egp_manual_inputs (timestamp, input_type, value, notes)
       VALUES (?, ?, ?, ?)`,
      [new Date().toISOString(), type, value, notes || '']
    );
    this._persist();
  }

  async getLatestCycle() {
    const r = this.db.exec(
      `SELECT * FROM egp_cycles ORDER BY timestamp DESC LIMIT 1`
    );
    if (!r.length) return null;
    const { columns, values } = r[0];
    const obj = {};
    columns.forEach((c, i) => obj[c] = values[0][i]);
    return obj;
  }

  async getHistory(limit = 20) {
    const r = this.db.exec(
      `SELECT * FROM egp_cycles ORDER BY timestamp DESC LIMIT ${limit}`
    );
    if (!r.length) return [];
    const { columns, values } = r[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((c, i) => obj[c] = row[i]);
      return obj;
    });
  }

  async getTransitions() {
    const r = this.db.exec(
      `SELECT * FROM egp_transitions ORDER BY timestamp DESC LIMIT 20`
    );
    if (!r.length) return [];
    const { columns, values } = r[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((c, i) => obj[c] = row[i]);
      return obj;
    });
  }

  close() {
    if (this._saveTimer) clearInterval(this._saveTimer);
    this._persist();
    this.db.close();
    console.log('[EGP] Storage closed.');
  }
}

module.exports = EGPStorageManager;

// src/exchange-connector.js
// Handles all exchange interactions — live trading and dry run simulation

'use strict';

const ccxt = require('ccxt');

// Kraken symbol remaps — update here if exchange renames assets
// Note: This list requires manual maintenance when exchanges deprecate tickers
const SYMBOL_MAP = {
  RNDR: 'RENDER' // Kraken migrated RNDR → RENDER
};

class ExchangeConnector {
  constructor(config) {
    this.config       = config;
    this.exchangeName = config.exchange?.name || 'kraken';
    this.apiKey       = config.exchange?.apiKey;
    this.apiSecret    = config.exchange?.apiSecret;
    this.isDryRun     = config.execution?.dryRun !== false; // Safe default: dry run
    this.baseCurrency = config.trading?.baseCurrency || 'USD';
    this.minTradeValue = config.trading?.minTradeValue || 10;
    this.mockPortfolio = null; // Initialised on first getPortfolioBalances() call

    const exchangeClass = ccxt[this.exchangeName] || ccxt.kraken;
    this.exchange = new exchangeClass({
      apiKey:          this.apiKey,
      secret:          this.apiSecret,
      timeout:         30000,
      enableRateLimit: true
    });
  }

  // ============================================================================
  // PORTFOLIO
  // ============================================================================

  async getPortfolioBalances() {
    // Dry run: always use in-memory mock portfolio
    if (this.isDryRun) {
      if (!this.mockPortfolio) {
        this.mockPortfolio = {
          [this.baseCurrency]: this.config.trading?.startingCapital || 300,
          BTC:  0,
          ETH:  0,
          SOL:  0,
          RNDR: 0,
          FET:  0
        };
        console.log(`   ℹ️  Dry Run: Mock portfolio initialised with $${this.mockPortfolio[this.baseCurrency]} ${this.baseCurrency}`);
      }
      return { ...this.mockPortfolio };
    }

    // Live mode: require credentials (should have been caught by config.js validation)
    if (!this.apiKey || !this.apiSecret) {
      console.error('❌ Cannot fetch balances: Missing API credentials');
      return { [this.baseCurrency]: 0 };
    }

    try {
      const balance   = await this.exchange.fetchBalance();
      const portfolio = {};

      if (balance.total) {
        for (const [asset, amount] of Object.entries(balance.total)) {
          if (amount > 0) {
            // CCXT normalises XBT → BTC and ZUSD → USD automatically
            portfolio[asset] = amount;
          }
        }
      }

      return portfolio;
    } catch (error) {
      console.error('❌ Failed to fetch live balances:', error.message);
      throw error;
    }
  }

  // ============================================================================
  // TRADE EXECUTION
  // ============================================================================

  async executeTrade(action) {
    // action: { action: 'buy'|'sell', symbol: 'BTC', amount: number, price: number, value: number }

    // Enforce minimum trade value for both dry run and live
    if (action.value < this.minTradeValue) {
      console.warn(`   ⚠️  Trade skipped: value $${action.value.toFixed(2)} is below minimum $${this.minTradeValue} (${action.action} ${action.symbol})`);
      return {
        orderId: `skipped-below-minimum-${Date.now()}`,
        status:  'skipped',
        filled:  0,
        price:   action.price
      };
    }

    if (this.isDryRun) {
      return this._executeMockTrade(action);
    }

    if (!this.apiKey || !this.apiSecret) {
      throw new Error('Cannot execute live trade: Missing API credentials');
    }

    return this._executeLiveTrade(action);
  }

  _executeMockTrade(action) {
    if (!this.mockPortfolio) {
      // Defensive: initialise if called before getPortfolioBalances()
      this.mockPortfolio = {
        [this.baseCurrency]: this.config.trading?.startingCapital || 300,
        BTC: 0, ETH: 0, SOL: 0, RNDR: 0, FET: 0
      };
      console.warn('   ⚠️  Dry Run: Mock portfolio was uninitialised at trade time — initialised with defaults');
    }

    const asset = action.symbol;
    const cost  = action.amount * action.price;

    if (action.action === 'buy') {
      if (this.mockPortfolio[this.baseCurrency] >= cost) {
        this.mockPortfolio[this.baseCurrency]  -= cost;
        this.mockPortfolio[asset] = (this.mockPortfolio[asset] || 0) + action.amount;
      } else {
        console.warn(`   ⚠️  Dry Run: Insufficient ${this.baseCurrency} for BUY ${action.symbol} — skipping mock trade`);
      }
    } else if (action.action === 'sell') {
      const held = this.mockPortfolio[asset] || 0;
      if (held >= action.amount) {
        this.mockPortfolio[asset]               -= action.amount;
        this.mockPortfolio[this.baseCurrency]   += cost;
      } else {
        console.warn(`   ⚠️  Dry Run: Insufficient ${asset} for SELL — held ${held.toFixed(6)}, needed ${action.amount.toFixed(6)} — skipping mock trade`);
      }
    }

    return {
      orderId: `mock-${Date.now()}`,
      status:  'closed',
      filled:  action.amount,
      price:   action.price
    };
  }

  async _executeLiveTrade(action) {
    const mappedSymbol = SYMBOL_MAP[action.symbol] || action.symbol;
    const symbol       = `${mappedSymbol}/${this.baseCurrency}`;

    try {
      const order = await this.exchange.createOrder(
        symbol,
        'market',
        action.action,
        action.amount
      );

      return {
        orderId: order.id,
        status:  order.status,
        filled:  order.filled,
        price:   order.price || action.price
      };
    } catch (error) {
      throw new Error(`Exchange order failed for ${symbol} (${action.action} ${action.amount}): ${error.message}`);
    }
  }
}

module.exports = ExchangeConnector;
// src/como-strategy.js
// CCE Commodities Engine (COMO) — 6-State FSM
// Thesis: Oil leads commodity rotation. Gold follows with 1-2 week lag.
//         Copper follows with 2-3 week lag. We ride each stage of the cascade.
//
// States:
//   DORMANT    → No clear trend. Dollar strong. 100% cash.
//   WATCHING   → Oil making significant directional move (>3% in 5d).
//   ROTATING   → Oil confirmed. Gold lag window open. Signal gold entry.
//   CASCADING  → Gold confirmed. Copper lag window open. Signal copper entry.
//   HOLDING    → Full position across rotation. Trailing stops active.
//   EXITING    → Rotation complete or reversal. Exit signals sent.

'use strict';

class COMOStateMachine {
  constructor(config = {}) {
    this.currentState   = 'DORMANT';
    this.previousState  = 'DORMANT';
    this.stateEnteredAt = Date.now();

    // Configurable thresholds
    this.oilTriggerPct    = config.oilTriggerPct    || 3.0;  // Oil move to trigger WATCHING
    this.oilConfirmDays   = config.oilConfirmDays   || 3;    // Days in WATCHING before ROTATING
    this.goldLagMaxDays   = config.goldLagMaxDays   || 14;   // Max days to wait for gold lag
    this.copperLagMaxDays = config.copperLagMaxDays || 21;   // Max days to wait for copper lag
    this.minHoldDays      = config.minHoldDays      || 7;    // Min hold before exit scan
    this.maxHoldDays      = config.maxHoldDays      || 60;   // Force exit after 60 days
    this.exitMomThreshold = config.exitMomThreshold || -4.0; // Exit if oil drops >4% from peak
    this.dxyBlock         = config.dxyBlock         !== false; // Block entry if DXY surging
  }

  getDaysInState() {
    return (Date.now() - this.stateEnteredAt) / 86400000;
  }

  getStateSummary() {
    const summaries = {
      DORMANT:   'No commodity trend — holding cash',
      WATCHING:  'Oil moving — monitoring for cascade confirmation',
      ROTATING:  'Oil confirmed — gold lag window open',
      CASCADING: 'Gold confirmed — copper lag window open',
      HOLDING:   'Full rotation position — trailing stops active',
      EXITING:   'Rotation complete — rotating back to cash'
    };
    return summaries[this.currentState] || this.currentState;
  }

  evaluateTransition(context) {
    const from = this.currentState;
    let to     = null;
    let reason = '';

    switch (this.currentState) {

      case 'DORMANT':
        // Wake up when oil makes a significant move
        // Block if DXY surging (dollar strength kills commodity rally)
        if (context.oilTrending && !(this.dxyBlock && context.dxyStrong)) {
          to     = 'WATCHING';
          reason = `Oil ${context.oilBullish ? 'surging' : 'falling'} ${context.oilMom5d.toFixed(1)}% over 5d — cascade may be starting`;
        }
        break;

      case 'WATCHING': {
        const daysWatching = this.getDaysInState();

        // Oil reversed — abort
        if (!context.oilTrending) {
          to     = 'DORMANT';
          reason = `Oil move faded (momentum: ${context.oilMom5d.toFixed(1)}%) — returning to dormant`;
          break;
        }

        // DXY surged — commodities will struggle
        if (this.dxyBlock && context.dxyStrong) {
          to     = 'DORMANT';
          reason = `Dollar surging (DXY +${context.dxyMom5d.toFixed(1)}% 5d) — blocking commodity entry`;
          break;
        }

        // Confirmed oil move — open gold lag window
        if (daysWatching >= this.oilConfirmDays && context.oilAboveSma20) {
          to     = 'ROTATING';
          reason = `Oil confirmed above SMA20 after ${Math.round(daysWatching)} days — opening gold lag window`;
        }
        break;
      }

      case 'ROTATING': {
        const daysRotating = this.getDaysInState();

        // Timeout — gold didn't follow
        if (daysRotating > this.goldLagMaxDays) {
          to     = 'DORMANT';
          reason = `Gold lag window expired (${Math.round(daysRotating)} days) — no rotation confirmed`;
          break;
        }

        // Oil reversed hard
        if (context.oilBearish) {
          to     = 'DORMANT';
          reason = `Oil reversed bearish (${context.oilMom5d.toFixed(1)}%) — aborting rotation`;
          break;
        }

        // Gold following oil — cascade confirmed, open copper window
        if (context.goldFollowing && context.goldAboveSma20) {
          to     = 'CASCADING';
          reason = `Gold confirming rotation — +${context.goldMom5d.toFixed(1)}% above SMA20 — copper window open`;
        }
        break;
      }

      case 'CASCADING': {
        const daysCascading = this.getDaysInState();

        // Timeout — move to HOLDING with what we have
        if (daysCascading > this.copperLagMaxDays) {
          to     = 'HOLDING';
          reason = `Copper window expired — holding oil + gold position`;
          break;
        }

        // Oil reversed
        if (context.oilBearish) {
          to     = 'EXITING';
          reason = `Oil reversed during cascade (${context.oilMom5d.toFixed(1)}%) — exiting`;
          break;
        }

        // Full cascade confirmed
        if (context.copperFollowing && context.copperAboveSma20) {
          to     = 'HOLDING';
          reason = `Full cascade confirmed — oil, gold, copper all rotating — entering full hold`;
        }
        break;
      }

      case 'HOLDING': {
        const daysHeld = this.getDaysInState();

        // Force exit
        if (daysHeld > this.maxHoldDays) {
          to     = 'EXITING';
          reason = `Max hold period (${Math.round(daysHeld)} days) — rotation complete`;
          break;
        }

        if (daysHeld < this.minHoldDays) break;

        // Oil momentum failure — primary exit signal
        if (context.oilMom5d < this.exitMomThreshold) {
          to     = 'EXITING';
          reason = `Oil momentum failed (${context.oilMom5d.toFixed(1)}% 5d) — rotation ending`;
          break;
        }

        // DXY reversal — dollar strength kills commodity rally
        if (context.dxyStrong) {
          to     = 'EXITING';
          reason = `DXY surging (${context.dxyMom5d.toFixed(1)}%) — dollar strength ending commodity rally`;
          break;
        }

        // Oil broke below SMA20
        if (!context.oilAboveSma20) {
          to     = 'EXITING';
          reason = `Oil broke below SMA20 ($${context.oilSma20}) — structural breakdown`;
        }
        break;
      }

      case 'EXITING':
        // Re-evaluate after exit
        if (context.oilTrending && !context.dxyStrong) {
          to     = 'WATCHING';
          reason = 'New oil move detected — re-entering watch';
        } else {
          to     = 'DORMANT';
          reason = 'Rotation complete — returning to cash';
        }
        break;
    }

    if (to && to !== from) {
      this.previousState  = from;
      this.currentState   = to;
      this.stateEnteredAt = Date.now();
      return { transitioned: true, from, to, reason };
    }

    return { transitioned: false, from, to: from, reason: '' };
  }
}

class COMOSignals {
  getAllSignals(market) {
    // Validate inputs — return safe defaults on missing data
    const oilMom5d   = typeof market.oilMom5d  === "number" ? market.oilMom5d  : 0;
    const goldMom5d  = typeof market.goldMom5d === "number" ? market.goldMom5d : 0;
    const copMom5d   = typeof market.copMom5d  === "number" ? market.copMom5d  : 0;
    const dxyMom5d   = typeof market.dxyMom5d  === "number" ? market.dxyMom5d  : 0;
    const oilGoldCorr = typeof market.oilGoldCorr === "number" ? market.oilGoldCorr : 0;

    // Correlation sanity check — only confirm gold following if correlation is positive
    // Negative correlation means gold is moving independently, not following oil
    const corrConfirmed = oilGoldCorr > 0.3;

    // Explicit oilBearish signal — hidden dependency in original, now computed here
    const oilBearish = oilMom5d < -3.0;

    return {
      oilMom5d,
      oilMom20d:        market.oilMom20d   || 0,
      goldMom5d,
      copMom5d,
      dxyMom5d,
      oilAboveSma20:    market.oilAboveSma20    || false,
      goldAboveSma20:   market.goldAboveSma20   || false,
      copperAboveSma20: market.copperAboveSma20 || false,
      oilBullish:       market.oilBullish       || false,
      oilBearish,
      oilTrending:      market.oilTrending      || false,
      goldFollowing:    market.goldFollowing     && corrConfirmed,
      copperFollowing:  market.copperFollowing   || false,
      dxyStrong:        market.dxyStrong         || false,
      dxyWeakening:     market.dxyWeakening      || false,
      oilGoldCorr,
      corrConfirmed
    };
  }
}

module.exports = { COMOStateMachine, COMOSignals };

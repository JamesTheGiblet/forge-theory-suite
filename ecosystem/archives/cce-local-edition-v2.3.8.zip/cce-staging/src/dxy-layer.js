// src/dxy-layer.js
// DXY Shared Macro Layer — Cross-Engine Dollar Strength Modifier
// Fetches DXY every 4H and writes dxy_state.json
// Read by all engines at cycle start to adjust signal thresholds

'use strict';

const fs   = require('fs');
const path = require('path');

const STATE_PATH = path.join(__dirname, '..', 'data', 'dxy_state.json');

const DXY_STRONG  = 100;
const DXY_WEAK    = 95;

class DXYLayer {
  constructor(config, notifier) {
    this.config   = config;
    this.notifier = notifier;
    this.lastState = null;
    this.lastLevel = null;
  }

  // ============================================================================
  // FETCH AND WRITE STATE
  // ============================================================================

  async update(dxyLevel) {
    if (!dxyLevel || isNaN(dxyLevel)) return null;

    const regime = dxyLevel > DXY_STRONG ? 'STRONG'
                 : dxyLevel < DXY_WEAK   ? 'WEAK'
                 : 'NEUTRAL';

    const modifier = regime === 'STRONG' ? -1
                   : regime === 'WEAK'   ?  1
                   : 0;

    const fgThreshold = regime === 'STRONG' ? 70
                      : regime === 'WEAK'   ? 50
                      : 60;

    const trend5d = this._calcTrend(dxyLevel);

    const state = {
      level:        +dxyLevel.toFixed(2),
      regime,
      trend_5d:     trend5d,
      modifier,
      fg_threshold: fgThreshold,
      last_updated: new Date().toISOString(),
      notes:        this._generateNotes(dxyLevel, regime, trend5d)
    };

    // Detect regime change
    const prevState = this._readState();
    const regimeChanged = prevState && prevState.regime !== regime;

    // Write state file
    this._writeState(state);
    this.lastState = state;
    this.lastLevel = dxyLevel;

    // Log
    const icon = regime === 'STRONG' ? '🔴' : regime === 'WEAK' ? '🟢' : '🟡';
    console.log(`[DXY] ${icon} ${regime} | Level: ${dxyLevel.toFixed(2)} | Modifier: ${modifier > 0 ? '+' : ''}${modifier} | F&G threshold: ${fgThreshold}`);

    // Notify on regime change
    if (regimeChanged) {
      await this.notifier.send([
        `<b>[DXY] 🔄 Regime Change</b>`,
        ``,
        `${prevState.regime} → ${regime}`,
        `Level: ${dxyLevel.toFixed(2)}`,
        `Modifier: ${modifier > 0 ? '+' : ''}${modifier}`,
        `F&G threshold now: ${fgThreshold}`,
        ``,
        `Impact:`,
        regime === 'STRONG' ? '⚠️ Risk-off. BTC needs F&G ≥ 70 to enter.' :
        regime === 'WEAK'   ? '✅ Risk-on. BTC threshold relaxed to F&G ≥ 50.' :
                              '➡️ Neutral. Standard thresholds restored.'
      ].join('\n'), 'info');
    }

    return state;
  }

  // ============================================================================
  // STATE FILE
  // ============================================================================

  _writeState(state) {
    try {
      const dir = path.dirname(STATE_PATH);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2));
    } catch (err) {
      console.error('[DXY] ❌ Failed to write state:', err.message);
    }
  }

  _readState() {
    try {
      if (!fs.existsSync(STATE_PATH)) return null;
      return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
    } catch (err) {
      return null;
    }
  }

  // ============================================================================
  // STATIC READ — called by other engines
  // ============================================================================

  static readState() {
    try {
      if (!fs.existsSync(STATE_PATH)) return DXYLayer.defaultState();
      const s = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
      // If stale (>8 hours), return neutral
      const age = Date.now() - new Date(s.last_updated).getTime();
      if (age > 8 * 60 * 60 * 1000) {
        console.log('[DXY] ⚠️  State stale — using neutral defaults');
        return DXYLayer.defaultState();
      }
      return s;
    } catch (err) {
      return DXYLayer.defaultState();
    }
  }

  static defaultState() {
    return {
      level:        99.0,
      regime:       'NEUTRAL',
      trend_5d:     'UNKNOWN',
      modifier:     0,
      fg_threshold: 60,
      last_updated: null,
      notes:        'Default state — DXY not yet fetched'
    };
  }

  // ============================================================================
  // HELPERS
  // ============================================================================

  _calcTrend(current) {
    if (!this.lastLevel) return 'UNKNOWN';
    const delta = current - this.lastLevel;
    if (delta > 0.3) return 'RISING';
    if (delta < -0.3) return 'FALLING';
    return 'FLAT';
  }

  _generateNotes(level, regime, trend) {
    if (regime === 'STRONG') {
      return `DXY above 100 — risk-off globally. BTC F&G threshold raised to 70. COMO entry blocked.`;
    } else if (regime === 'WEAK') {
      return `DXY below 95 — risk-on globally. BTC F&G threshold relaxed to 50. Tailwind for risk assets.`;
    } else {
      return `DXY in neutral band (95-100). Standard thresholds apply. Trend: ${trend}.`;
    }
  }

  getStatus() {
    return this._readState() || DXYLayer.defaultState();
  }
}

module.exports = DXYLayer;

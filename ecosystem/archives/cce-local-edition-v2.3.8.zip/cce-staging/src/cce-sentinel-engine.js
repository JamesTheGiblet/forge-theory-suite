// src/cce-sentinel-engine.js
// O.E Sentinel — Anomaly Detection Engine
// Watches all 11 engines for unusual conditions, correlation breakdowns
// and flash signals. Fires Telegram alerts on WARN and ALERT severity.
// Runs every 15 minutes alongside O.E Observer.

'use strict';

const path = require('path');
const fs   = require('fs');

// ============================================================================
// STORAGE (sql.js — Android compatible)
// ============================================================================

class SentinelStorage {
  constructor(dbPath) {
    this.dbPath = dbPath;
    this.db     = null;
  }

  async init() {
    const initSqlJs = require('sql.js');
    const SQL = await initSqlJs();

    if (fs.existsSync(this.dbPath)) {
      const buf = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(buf);
    } else {
      this.db = new SQL.Database();
    }

    this.db.run(`
      CREATE TABLE IF NOT EXISTS sentinel_anomalies (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp    TEXT NOT NULL,
        rule_id      TEXT NOT NULL,
        severity     TEXT NOT NULL,
        category     TEXT NOT NULL,
        title        TEXT NOT NULL,
        detail       TEXT,
        engine       TEXT,
        value        REAL,
        threshold    REAL,
        resolved     INTEGER DEFAULT 0,
        resolved_at  TEXT
      );
    `);

    this.db.run(`
      CREATE TABLE IF NOT EXISTS sentinel_cycles (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp    TEXT NOT NULL,
        anomaly_count INTEGER DEFAULT 0,
        warn_count   INTEGER DEFAULT 0,
        alert_count  INTEGER DEFAULT 0,
        engines_snapshot TEXT,
        market_snapshot  TEXT
      );
    `);

    this._persist();
  }

  _persist() {
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (e) {
      console.error('[SEN] Persist error:', e.message);
    }
  }

  insertAnomaly(a) {
    this.db.run(
      `INSERT INTO sentinel_anomalies
       (timestamp, rule_id, severity, category, title, detail, engine, value, threshold)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [a.timestamp, a.rule_id, a.severity, a.category, a.title, a.detail||null,
       a.engine||null, a.value||null, a.threshold||null]
    );
    this._persist();
    return this.db.exec('SELECT last_insert_rowid() as id')[0].values[0][0];
  }

  resolveAnomaly(ruleId) {
    this.db.run(
      `UPDATE sentinel_anomalies SET resolved=1, resolved_at=?
       WHERE rule_id=? AND resolved=0`,
      [new Date().toISOString(), ruleId]
    );
    this._persist();
  }

  getActiveAnomalies() {
    const r = this.db.exec(
      `SELECT * FROM sentinel_anomalies WHERE resolved=0 ORDER BY timestamp DESC`
    );
    if (!r.length) return [];
    const { columns, values } = r[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  }

  getRecentAnomalies(limit = 20) {
    const r = this.db.exec(
      `SELECT * FROM sentinel_anomalies ORDER BY timestamp DESC LIMIT ?`, [limit]
    );
    if (!r.length) return [];
    const { columns, values } = r[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  }

  isActiveAnomaly(ruleId) {
    const r = this.db.exec(
      `SELECT COUNT(*) as c FROM sentinel_anomalies WHERE rule_id=? AND resolved=0`,
      [ruleId]
    );
    return r.length && r[0].values[0][0] > 0;
  }

  logCycle(data) {
    this.db.run(
      `INSERT INTO sentinel_cycles
       (timestamp, anomaly_count, warn_count, alert_count, engines_snapshot, market_snapshot)
       VALUES (?,?,?,?,?,?)`,
      [data.timestamp, data.anomaly_count, data.warn_count, data.alert_count,
       JSON.stringify(data.engines_snapshot), JSON.stringify(data.market_snapshot)]
    );
    this._persist();
  }

  getStats() {
    const total = this.db.exec(
      `SELECT COUNT(*) as c FROM sentinel_anomalies`
    );
    const active = this.db.exec(
      `SELECT COUNT(*) as c FROM sentinel_anomalies WHERE resolved=0`
    );
    const bySeverity = this.db.exec(
      `SELECT severity, COUNT(*) as c FROM sentinel_anomalies GROUP BY severity`
    );
    const cycles = this.db.exec(
      `SELECT COUNT(*) as c FROM sentinel_cycles`
    );

    const sevMap = {};
    if (bySeverity.length) {
      bySeverity[0].values.forEach(([sev, cnt]) => { sevMap[sev] = cnt; });
    }

    return {
      total_anomalies:  total[0]?.values[0][0] || 0,
      active_anomalies: active[0]?.values[0][0] || 0,
      total_cycles:     cycles[0]?.values[0][0] || 0,
      by_severity:      sevMap
    };
  }

  close() {
    this._persist();
    console.log('[SEN] Storage closed.');
  }
}

// ============================================================================
// SENTINEL ENGINE
// ============================================================================

class CCSentinelEngine {
  constructor(config, notifier) {
    this.config   = config;
    this.notifier = notifier;
    this.storage  = null;
    this.running  = false;
    this.cycleNum = 0;

    // Track previous cycle values for delta detection
    this._prev = {
      fg:           null,
      btcPrice:     null,
      btcDominance: null,
      gridRecentres:null,
    };
  }

  // ── INIT ──────────────────────────────────────────────────────────────────

  async start() {
    const dbPath = path.join(__dirname, '..', 'data', 'sentinel-production.db');
    this.storage = new SentinelStorage(dbPath);
    await this.storage.init();

    console.log('[SEN] 🛡️  Starting O.E Sentinel');
    console.log(`[SEN] ⏱️  Interval: ${this.config.intervalMinutes}min`);
    console.log('[SEN] 👁️  Watching 11 engines for anomalies');
    console.log('');

    this.running = true;
    await this._run();

    while (this.running) {
      await this._sleep(this.config.intervalMinutes * 60 * 1000);
      if (this.running) await this._run();
    }
  }

  stop() {
    this.running = false;
    if (this.storage) this.storage.close();
    console.log('[SEN] 🛑 Stopping Sentinel...');
  }

  // ── MAIN CYCLE ────────────────────────────────────────────────────────────

  async _run() {
    this.cycleNum++;
    const ts = new Date().toISOString();
    console.log('[SEN] ─────────────────────────────────────────────────');
    console.log(`[SEN] 🛡️  #${this.cycleNum} | ${new Date().toLocaleTimeString()}`);

    // Gather current state from all engines
    const snapshot = await this._gatherSnapshot();
    if (!snapshot) {
      console.log('[SEN] ⚠️  Snapshot unavailable — skipping cycle');
      return;
    }

    // Run all detection rules
    const newAnomalies  = [];
    const resolved      = [];

    const results = await this._runAllRules(snapshot);

    for (const result of results) {
      const wasActive = this.storage.isActiveAnomaly(result.rule_id);

      if (result.triggered && !wasActive) {
        // New anomaly
        const id = this.storage.insertAnomaly({ timestamp: ts, ...result });
        newAnomalies.push(result);
        console.log(`[SEN] 🚨 ${result.severity} — ${result.title}`);
      } else if (!result.triggered && wasActive) {
        // Resolved
        this.storage.resolveAnomaly(result.rule_id);
        resolved.push(result);
        console.log(`[SEN] ✅ RESOLVED — ${result.title}`);
      }
    }

    // Log cycle
    const active = this.storage.getActiveAnomalies();
    const warns  = active.filter(a => a.severity === 'WARN').length;
    const alerts = active.filter(a => a.severity === 'ALERT').length;

    this.storage.logCycle({
      timestamp:       ts,
      anomaly_count:   active.length,
      warn_count:      warns,
      alert_count:     alerts,
      engines_snapshot: snapshot.engines,
      market_snapshot:  snapshot.market
    });

    console.log(`[SEN]    Active: ${active.length} | New: ${newAnomalies.length} | Resolved: ${resolved.length}`);
    console.log(`[SEN] ⏳ Next check: ${new Date(Date.now() + this.config.intervalMinutes * 60000).toLocaleTimeString()}`);

    // Fire Telegram for new WARN/ALERT anomalies
    for (const a of newAnomalies) {
      if (a.severity === 'WARN' || a.severity === 'ALERT') {
        await this._notify(a);
      }
    }

    // Notify resolutions for ALERT level
    for (const r of resolved) {
      if (r.severity === 'ALERT') {
        await this._notifyResolved(r);
      }
    }

    // Update prev values
    this._prev.fg           = snapshot.market.fear_greed;
    this._prev.btcPrice     = snapshot.market.btc_price;
    this._prev.btcDominance = snapshot.market.btc_dominance;
    if (snapshot.engines.grid) {
      this._prev.gridRecentres = snapshot.engines.grid.recentres || 0;
    }
  }

  // ── SNAPSHOT ──────────────────────────────────────────────────────────────

  async _gatherSnapshot() {
    try {
      const dataDir = path.join(__dirname, '..', 'data');

      const snapshot = { engines: {}, market: {} };

      // Load each engine DB
      const loadDB = async (file) => {
        const p = path.join(dataDir, file);
        if (!fs.existsSync(p)) return null;
        const initSqlJs = require('sql.js');
        const SQL = await initSqlJs();
        const buf = fs.readFileSync(p);
        return new SQL.Database(buf);
      };

      const q = (db, sql) => {
        if (!db) return null;
        try {
          const r = db.exec(sql);
          if (!r.length) return null;
          const { columns, values } = r[0];
          if (!values.length) return null;
          const obj = {};
          columns.forEach((col, i) => obj[col] = values[0][i]);
          return obj;
        } catch(e) { return null; }
      };

      // S.E Crypto
      const cryptoDB = await loadDB('cce-production.db');
      const crypto   = q(cryptoDB, 'SELECT * FROM cce_cycles ORDER BY timestamp DESC LIMIT 1');
      if (crypto) {
        snapshot.engines.crypto = {
          state:         crypto.current_state,
          btc_price:     crypto.btc_price,
          fear_greed:    crypto.fear_greed,
          btc_dominance: crypto.btc_dominance,
          portfolio:     crypto.portfolio_value
        };
        snapshot.market.btc_price     = crypto.btc_price;
        snapshot.market.fear_greed    = crypto.fear_greed;
        snapshot.market.btc_dominance = crypto.btc_dominance;
      }

      // S.E Forex
      const forexDB = await loadDB('forex-production.db');
      const forex   = q(forexDB, 'SELECT * FROM forex_cycles ORDER BY timestamp DESC LIMIT 1');
      if (forex) snapshot.engines.forex = { state: forex.state, rate: forex.rate, z_score: forex.z_score };

      // S.E REIT
      const rmeDB = await loadDB('rme-production.db');
      const rme   = q(rmeDB, 'SELECT * FROM rme_cycles ORDER BY timestamp DESC LIMIT 1');
      if (rme) snapshot.engines.reit = { state: rme.state, fed_rate: rme.fed_rate, treasury_yield: rme.treasury_yield, spread: rme.yield_spread, fed_cutting: rme.fed_cutting };

      // S.E Stocks
      const cmeDB = await loadDB('cme-production.db');
      const cme   = q(cmeDB, 'SELECT * FROM cme_cycles ORDER BY timestamp DESC LIMIT 1');
      if (cme) snapshot.engines.stocks = { state: cme.state, vix: cme.vix, rsi: cme.rsi, price: cme.price };

      // S.E Commodities
      const comoDB = await loadDB('como-production.db');
      const como   = q(comoDB, 'SELECT * FROM como_cycles ORDER BY timestamp DESC LIMIT 1');
      if (como) snapshot.engines.como = { state: como.state, oil: como.oil_price, gold: como.gold_price, copper: como.copper_price, dxy: como.dxy_price, dxy_strong: como.dxy_strong, oil_gold_corr: como.oil_gold_corr };

      // S.E EGP
      const egpDB = await loadDB('egp-production.db');
      const egp   = q(egpDB, 'SELECT * FROM egp_cycles ORDER BY timestamp DESC LIMIT 1');
      if (egp) snapshot.engines.egp = { state: egp.state, divergence: egp.divergence_flag, cbe_rate: egp.cbe_rate, inflation: egp.inflation, score: egp.composite_score };

      // T.E Grid
      const gridDB  = await loadDB('grid-production.db');
      const grid    = q(gridDB, 'SELECT * FROM grid_cycles ORDER BY timestamp DESC LIMIT 1');
      const gridEvt = gridDB ? (() => {
        const r = gridDB.exec(`SELECT COUNT(*) as c FROM grid_events WHERE event_type='RECENTRE'`);
        return r.length ? r[0].values[0][0] : 0;
      })() : 0;
      if (grid) snapshot.engines.grid = { state: grid.grid_state, centre: grid.centre_price, btc: grid.btc_price, profit: grid.total_profit, open_buys: grid.open_buys, open_sells: grid.open_sells, recentres: gridEvt };

      // T.E Momentum
      const momDB = await loadDB('mom-production.db');
      const mom   = q(momDB, 'SELECT * FROM mom_cycles ORDER BY timestamp DESC LIMIT 1');
      if (mom) snapshot.engines.mom = { open_positions: mom.open_positions, portfolio: mom.portfolio_value };

      // T.E Breakout
      const brkDB  = await loadDB('brk-production.db');
      const brk    = q(brkDB, 'SELECT * FROM brk_cycles ORDER BY timestamp DESC LIMIT 1');
      const brkSqz = brkDB ? (() => {
        const r = brkDB.exec(`SELECT COUNT(*) as c FROM brk_squeezes WHERE timestamp > datetime('now','-1 hour')`);
        return r.length ? r[0].values[0][0] : 0;
      })() : 0;
      if (brk) snapshot.engines.brk = { open_positions: brk.open_positions, active_squeezes: brkSqz };

      // O.E Observer
      const obsDB = await loadDB('obs-production.db');
      const obs   = q(obsDB, 'SELECT * FROM obs_cycles ORDER BY timestamp DESC LIMIT 1');
      if (obs) snapshot.engines.obs = { total_observations: obs.total_observations };

      // DXY state file
      const dxyPath = path.join(dataDir, 'dxy_state.json');
      if (fs.existsSync(dxyPath)) {
        try {
          const dxy = JSON.parse(fs.readFileSync(dxyPath, 'utf8'));
          snapshot.market.dxy        = dxy.level;
          snapshot.market.dxy_regime = dxy.regime;
        } catch(e) {}
      }

      return snapshot;
    } catch(e) {
      console.error('[SEN] Snapshot error:', e.message);
      return null;
    }
  }

  // ── DETECTION RULES ───────────────────────────────────────────────────────

  async _runAllRules(snap) {
    const results = [];
    const e = snap.engines;
    const m = snap.market;

    // ── CATEGORY: STATE COMBINATIONS ──────────────────────────────────────

    // Rule SC-01: Crypto IGNITION while Grid STOPPED
    results.push(this._rule({
      rule_id:   'SC-01',
      category:  'STATE_COMBINATION',
      severity:  'WARN',
      title:     'Crypto IGNITION — Grid should be paused',
      detail:    'S.E Crypto is in IGNITION while T.E Grid is active. Grid may interfere with directional BTC position.',
      engine:    'crypto+grid',
      triggered: e.crypto?.state === 'IGNITION' && e.grid?.state === 'ACTIVE'
    }));

    // Rule SC-02: REIT HOLDING while Stocks DORMANT — contradiction
    results.push(this._rule({
      rule_id:   'SC-02',
      category:  'STATE_COMBINATION',
      severity:  'INFO',
      title:     'REIT HOLDING but Stocks DORMANT — rate environment conflict',
      detail:    'REIT is in position but Stocks engine sees bear market. Rate environment signal may be contradictory.',
      engine:    'reit+stocks',
      triggered: e.reit?.state === 'HOLDING' && e.stocks?.state === 'DORMANT'
    }));

    // Rule SC-03: Multiple S.E engines transitioning same cycle
    const seStates = [e.crypto?.state, e.reit?.state, e.stocks?.state, e.como?.state].filter(Boolean);
    const activeStates = seStates.filter(s => !['DORMANT','WATCHING'].includes(s));
    results.push(this._rule({
      rule_id:   'SC-03',
      category:  'STATE_COMBINATION',
      severity:  'INFO',
      title:     `${activeStates.length} S.E engines simultaneously active`,
      detail:    `Engines active: ${activeStates.join(', ')}. Unusual co-movement across strategic layer.`,
      engine:    'se-layer',
      value:     activeStates.length,
      threshold: 3,
      triggered: activeStates.length >= 3
    }));

    // Rule SC-04: EGP FADE while COMO CASCADING
    results.push(this._rule({
      rule_id:   'SC-04',
      category:  'STATE_COMBINATION',
      severity:  'ALERT',
      title:     'EGP FADE + Commodities CASCADING — currency/commodity conflict',
      detail:    'EGP engine signalling currency fade while Commodity cascade is active. Cross-asset risk elevated.',
      engine:    'egp+como',
      triggered: e.egp?.state === 'FADE' && e.como?.state === 'CASCADING'
    }));

    // Rule SC-05: EGP divergence sustained
    results.push(this._rule({
      rule_id:   'SC-05',
      category:  'STATE_COMBINATION',
      severity:  'INFO',
      title:     'EGP policy divergence active',
      detail:    `CBE cutting while inflation rising. Score: ${e.egp?.score}. Exit all EGP positions.`,
      engine:    'egp',
      triggered: !!e.egp?.divergence
    }));

    // ── CATEGORY: MARKET CONDITIONS ────────────────────────────────────────

    // Rule MC-01: Flash fear — F&G drops 15+ points
    if (this._prev.fg !== null && m.fear_greed !== null) {
      const fgDrop = this._prev.fg - m.fear_greed;
      results.push(this._rule({
        rule_id:   'MC-01',
        category:  'MARKET_CONDITION',
        severity:  'ALERT',
        title:     `Flash fear — F&G dropped ${fgDrop.toFixed(0)} points this cycle`,
        detail:    `Fear & Greed fell from ${this._prev.fg} → ${m.fear_greed}. Sudden sentiment collapse detected.`,
        engine:    'market',
        value:     fgDrop,
        threshold: 15,
        triggered: fgDrop >= 15
      }));
    }

    // Rule MC-02: Extreme fear — F&G below 10
    results.push(this._rule({
      rule_id:   'MC-02',
      category:  'MARKET_CONDITION',
      severity:  'ALERT',
      title:     `Extreme fear — F&G at ${m.fear_greed}`,
      detail:    'Fear & Greed below 10. Historical capitulation zone. Monitor for accumulation signal.',
      engine:    'market',
      value:     m.fear_greed,
      threshold: 10,
      triggered: m.fear_greed !== null && m.fear_greed < 10
    }));

    // Rule MC-03: BTC dominance spike above 62%
    results.push(this._rule({
      rule_id:   'MC-03',
      category:  'MARKET_CONDITION',
      severity:  'WARN',
      title:     `BTC dominance elevated — ${m.btc_dominance?.toFixed(1)}%`,
      detail:    'BTC dominance above 62%. Altcoin bleed active. Cascade risk for T.E Momentum positions.',
      engine:    'market',
      value:     m.btc_dominance,
      threshold: 62,
      triggered: m.btc_dominance !== null && m.btc_dominance > 62
    }));

    // Rule MC-04: BTC price move > 4% since last cycle
    if (this._prev.btcPrice && m.btc_price) {
      const btcMove = Math.abs((m.btc_price - this._prev.btcPrice) / this._prev.btcPrice * 100);
      results.push(this._rule({
        rule_id:   'MC-04',
        category:  'MARKET_CONDITION',
        severity:  'WARN',
        title:     `BTC flash move — ${btcMove.toFixed(1)}% in one cycle`,
        detail:    `BTC moved from $${this._prev.btcPrice?.toFixed(0)} → $${m.btc_price?.toFixed(0)} (${btcMove.toFixed(1)}%). Grid recentre likely.`,
        engine:    'market',
        value:     btcMove,
        threshold: 4,
        triggered: btcMove >= 4
      }));
    }

    // Rule MC-05: DXY regime changed without COMO response
    if (snap.market.dxy_regime === 'STRONG' && e.como?.state === 'CASCADING') {
      results.push(this._rule({
        rule_id:   'MC-05',
        category:  'MARKET_CONDITION',
        severity:  'WARN',
        title:     'DXY STRONG but COMO is CASCADING — regime conflict',
        detail:    'Strong dollar should block commodity cascade. COMO engine may not have updated to new DXY regime yet.',
        engine:    'como+dxy',
        triggered: true
      }));
    } else {
      results.push(this._rule({ rule_id: 'MC-05', category: 'MARKET_CONDITION', severity: 'WARN', title: '', triggered: false }));
    }

    // Rule MC-06: VIX extreme — above 35
    results.push(this._rule({
      rule_id:   'MC-06',
      category:  'MARKET_CONDITION',
      severity:  'ALERT',
      title:     `VIX extreme — ${e.stocks?.vix?.toFixed(1)}`,
      detail:    `VIX above 35. Equity market in crisis mode. All leveraged engines should be defensive.`,
      engine:    'stocks',
      value:     e.stocks?.vix,
      threshold: 35,
      triggered: e.stocks?.vix !== null && e.stocks?.vix > 35
    }));

    // ── CATEGORY: SIGNAL ANOMALIES ─────────────────────────────────────────

    // Rule SA-01: All 3 pairs squeezing simultaneously on T.E Breakout
    results.push(this._rule({
      rule_id:   'SA-01',
      category:  'SIGNAL_ANOMALY',
      severity:  'WARN',
      title:     'T.E Breakout — all pairs squeezing simultaneously',
      detail:    'BTC, ETH and SOL all showing Bollinger Band squeeze. High-volatility breakout imminent across crypto.',
      engine:    'brk',
      value:     e.brk?.active_squeezes,
      threshold: 3,
      triggered: e.brk?.active_squeezes >= 3
    }));

    // Rule SA-02: Grid recentre threshold exceeded (5+ recentres)
    results.push(this._rule({
      rule_id:   'SA-02',
      category:  'SIGNAL_ANOMALY',
      severity:  'WARN',
      title:     `T.E Grid recentred ${e.grid?.recentres} times — high volatility`,
      detail:    'Grid is recentring frequently. Market moving faster than grid spacing. Consider widening grid or pausing.',
      engine:    'grid',
      value:     e.grid?.recentres,
      threshold: 5,
      triggered: e.grid?.recentres !== null && e.grid?.recentres >= 5
    }));

    // Rule SA-03: Momentum open positions > 0 during EXTREME FEAR
    results.push(this._rule({
      rule_id:   'SA-03',
      category:  'SIGNAL_ANOMALY',
      severity:  'WARN',
      title:     'T.E Momentum has open positions during extreme fear',
      detail:    `F&G is ${m.fear_greed} (extreme fear) but Momentum has ${e.mom?.open_positions} open position(s). Elevated drawdown risk.`,
      engine:    'mom',
      triggered: m.fear_greed !== null && m.fear_greed <= 20 && e.mom?.open_positions > 0
    }));

    // Rule SA-04: Crypto stuck in same state for 7+ days
    // (Checked via the days_in_state field from crypto engine — read from DB directly)
    // We pass this via snapshot enrichment below

    // ── CATEGORY: CORRELATION BREAKDOWNS ──────────────────────────────────

    // Rule CB-01: Gold falling while Oil rising
    if (e.como?.oil !== null && e.como?.gold !== null) {
      // Use oil_gold_corr from COMO engine if available
      const corr = e.como?.oil_gold_corr;
      results.push(this._rule({
        rule_id:   'CB-01',
        category:  'CORRELATION_BREAKDOWN',
        severity:  'INFO',
        title:     `Oil/Gold correlation breakdown — corr: ${corr?.toFixed(3)}`,
        detail:    'Oil and Gold are decoupling. COMO cascade reliability is reduced. Consider holding at current stage.',
        engine:    'como',
        value:     corr,
        threshold: -0.3,
        triggered: corr !== null && corr < -0.3
      }));
    }

    // Rule CB-02: BTC price rising while F&G falling (price/sentiment divergence)
    if (this._prev.btcPrice && this._prev.fg !== null && m.btc_price && m.fear_greed !== null) {
      const btcUp  = m.btc_price > this._prev.btcPrice * 1.01; // +1%
      const fgDown = m.fear_greed < this._prev.fg - 5;         // -5 points
      results.push(this._rule({
        rule_id:   'CB-02',
        category:  'CORRELATION_BREAKDOWN',
        severity:  'INFO',
        title:     'BTC rising while sentiment falling — price/fear divergence',
        detail:    `BTC up to $${m.btc_price?.toFixed(0)} but F&G dropped to ${m.fear_greed}. Divergence can precede sharp correction.`,
        engine:    'market',
        triggered: btcUp && fgDown
      }));
    }

    // Rule CB-03: REIT HOLDING while Fed rate rising
    results.push(this._rule({
      rule_id:   'CB-03',
      category:  'CORRELATION_BREAKDOWN',
      severity:  'WARN',
      title:     'REIT HOLDING while Fed appears to be hiking',
      detail:    'REIT engine is in position but Fed cutting flag is false. Rate environment may have shifted against REIT thesis.',
      engine:    'reit',
      triggered: e.reit?.state === 'HOLDING' && !e.reit?.fed_cutting
    }));

    return results;
  }

  // ── RULE HELPER ───────────────────────────────────────────────────────────

  _rule(opts) {
    return {
      rule_id:   opts.rule_id,
      severity:  opts.severity  || 'INFO',
      category:  opts.category  || 'GENERAL',
      title:     opts.title     || '',
      detail:    opts.detail    || null,
      engine:    opts.engine    || null,
      value:     opts.value     || null,
      threshold: opts.threshold || null,
      triggered: !!opts.triggered
    };
  }

  // ── NOTIFICATIONS ─────────────────────────────────────────────────────────

  async _notify(anomaly) {
    const icon = anomaly.severity === 'ALERT' ? '🚨' : '⚠️';
    const lines = [
      `<b>${icon} [SENTINEL] ${anomaly.severity}</b>`,
      '',
      `<b>${anomaly.title}</b>`,
      '',
      anomaly.detail || '',
      '',
      `Category: ${anomaly.category.replace(/_/g,' ')}`,
      `Engine: ${anomaly.engine || 'platform'}`,
      anomaly.value !== null ? `Value: ${anomaly.value} (threshold: ${anomaly.threshold})` : '',
    ].filter(Boolean);

    try {
      await this.notifier.send(lines.join('\n'), anomaly.severity === 'ALERT' ? 'alert' : 'warn');
    } catch(e) {
      console.error('[SEN] Telegram error:', e.message);
    }
  }

  async _notifyResolved(anomaly) {
    try {
      await this.notifier.send(
        `<b>✅ [SENTINEL] RESOLVED</b>\n\n${anomaly.title}\n\nCondition no longer active.`,
        'info'
      );
    } catch(e) {}
  }

  // ── STATUS (for API / dashboard) ─────────────────────────────────────────

  getStatus() {
    if (!this.storage) return null;
    const active = this.storage.getActiveAnomalies();
    const stats  = this.storage.getStats();
    const recent = this.storage.getRecentAnomalies(10);

    return {
      cycle_number:    this.cycleNum,
      active_anomalies: active.length,
      alert_count:     active.filter(a => a.severity === 'ALERT').length,
      warn_count:      active.filter(a => a.severity === 'WARN').length,
      info_count:      active.filter(a => a.severity === 'INFO').length,
      total_cycles:    stats.total_cycles,
      total_anomalies: stats.total_anomalies,
      active:          active,
      recent:          recent,
      last_run:        new Date().toISOString()
    };
  }

  // ── UTILITY ───────────────────────────────────────────────────────────────

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = CCSentinelEngine;

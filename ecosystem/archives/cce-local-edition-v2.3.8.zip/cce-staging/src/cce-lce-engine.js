// src/cce-lce-engine.js — T.E Liquidation Cascade Engine
// Rides liquidation cascades on 5-minute cycles
// Pattern: matches CCE platform engine architecture (config + sharedNotifier)

'use strict';

const axios = require('axios');
const { LCEDataFeed, LCEStrategy } = require('./lce-strategy');
class CCELCEEngine {
  constructor(config, sharedNotifier) {
    this.config   = config;
    this.notifier = sharedNotifier;
    this.lceConfig = config.lce || {};

    this.dataFeed  = new LCEDataFeed();
    this.strategy  = new LCEStrategy(this.lceConfig);
    this.isRunning = false;
    this.cycleCount = 0;
    this.dryRun    = this.lceConfig.dryRun !== false;

    this.watchlist = this.lceConfig.watchlist || ['BTC/USDT', 'ETH/USDT', 'SOL/USDT'];
  }

  async start(intervalMinutes = 5) {
    this.isRunning = true;
    const intervalMs = intervalMinutes * 60 * 1000;

    console.log('\n⚡ Starting T.E LCE — Liquidation Cascade Engine');
    console.log(`⏱️  Cycle: ${intervalMinutes} minutes`);
    console.log(`🔧 Mode: ${this.dryRun ? 'DRY RUN' : '⚠️  LIVE'}`);
    console.log(`👀 Watching: ${this.watchlist.join(', ')}\n`);

    while (this.isRunning) {
      await this.runCycle();
      if (!this.isRunning) break;
      console.log(`[LCE] ⏳ Next run: ${new Date(Date.now() + intervalMs).toLocaleTimeString()}`);
      await this._sleep(intervalMs);
    }
  }

  async runCycle() {
    this.cycleCount++;
    const start = Date.now();
    console.log(`\n[LCE] ─── Cycle #${this.cycleCount} @ ${new Date().toLocaleTimeString()} ───`);

    try {
      const snapshots = await Promise.all(
        this.watchlist.map(s => this.dataFeed.getSignalSnapshot(s))
      );

      for (const s of snapshots) {
        if (s.liq5m?.totalLiqUsd > 1_000_000) {
          console.log(`[LCE] 💧 ${s.symbol}: $${(s.liq5m.totalLiqUsd/1e6).toFixed(1)}M | OI drop: ${(s.oi?.dropPct||0).toFixed(2)}% | RSI: ${(s.price?.rsi||0).toFixed(0)}`);
        }
      }

      const decision = this.strategy.evaluate(snapshots);
      console.log(`[LCE] 📊 ${decision.state} | ${decision.action}`);

      await this._executeDecision(decision, snapshots);

      const status = this.strategy.getStatus();
      console.log(`[LCE] ✅ ${Date.now()-start}ms | Daily PnL: ${status.dailyPnlPct.toFixed(2)}% | Trades: ${status.dailyTrades}`);

    } catch (err) {
      console.error(`[LCE] ❌ Cycle error: ${err.message}`);
    }
  }

  async _executeDecision(decision, snapshots) {
    switch (decision.action) {
      case 'STALKING':
        this.notifier?.send(`⚡ <b>LCE: CASCADE DETECTED</b>\n${decision.signal?.symbol} — $${((decision.signal?.liq5m?.totalLiqUsd||0)/1e6).toFixed(1)}M liquidated\nStalking for confirmation...`, 'info');
        break;

      case 'ENTER': {
        const snap = snapshots.find(s => s.symbol === decision.symbol);
        const price = snap?.price?.price;
        if (!price) break;

        const capital   = this.lceConfig.capitalUSDC || 100;
        const slPct     = (this.lceConfig.stopLossPct || 0.8) / 100;
        const tpPct     = (this.lceConfig.takeProfitPct || 1.6) / 100;
        const stopLoss  = decision.side === 'BUY' ? price * (1 - slPct) : price * (1 + slPct);
        const takeProfit = decision.side === 'BUY' ? price * (1 + tpPct) : price * (1 - tpPct);

        const feeRate    = this.lceConfig.feeRate    || 0.0016;
        const slippage   = this.lceConfig.slippageRate || 0.001;
        const costRate   = feeRate + slippage;
        const entryAdj   = decision.side === 'BUY'
          ? price * (1 + costRate)  // BUY: pay spread + fee
          : price * (1 - costRate); // SELL: receive less

        const position = {
          symbol: decision.symbol, side: decision.side,
          entryPrice: entryAdj, qty: capital / entryAdj,
          sizeUsd: capital, stopLoss, takeProfit,
          openedAt: Date.now(),
        };

        this.strategy.setPosition(position);
        console.log(`[LCE] 🎯 ${this.dryRun ? 'PAPER' : 'LIVE'} ${decision.side} ${decision.symbol} @ $${price.toFixed(2)} | SL: $${stopLoss.toFixed(2)} | TP: $${takeProfit.toFixed(2)}`);
        this.notifier?.send(`⚡ <b>LCE: CASCADE TRIGGERED</b>\n${decision.side} ${decision.symbol}\nEntry: $${price.toFixed(2)}\nSL: $${stopLoss.toFixed(2)} | TP: $${takeProfit.toFixed(2)}`, 'trade');
        break;
      }

      case 'EXIT': {
        const snap = snapshots.find(s => s.symbol === decision.symbol);
        const exitPrice = snap?.price?.price || this.strategy.activePosition?.entryPrice;
        const pos = this.strategy.activePosition;
        if (!pos) break;

        const emoji = decision.pnlPct > 0 ? '✅' : '❌';
        console.log(`[LCE] ${emoji} EXIT ${decision.symbol} | ${decision.reason} | PnL: ${decision.pnlPct.toFixed(2)}%`);
        this.notifier?.send(`${emoji} <b>LCE: TRADE CLOSED</b>\n${decision.symbol} | ${decision.reason}\nPnL: ${decision.pnlPct>0?'+':''}${decision.pnlPct.toFixed(2)}%`, 'trade');
        this.strategy.clearPosition();
        break;
      }

      case 'CIRCUIT_BREAKER':
        this.notifier?.send(`⛔ <b>LCE: CIRCUIT BREAKER</b>\nDaily loss limit hit — engine halted`, 'warning');
        break;
    }
  }

  stop() {
    console.log('\n[LCE] 🛑 Stopping LCE Engine...');
    this.isRunning = false;
  }

  getStatus() {
    return { engine: 'LCE', ...this.strategy.getStatus(), cycleCount: this.cycleCount, dryRun: this.dryRun };
  }

  _sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
}

module.exports = CCELCEEngine;

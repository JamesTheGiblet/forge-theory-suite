// src/obs-storage.js
// O.E Observer — sql.js persistence layer
// Stores all observations, patterns, and insights.
// PASSIVE ONLY — read-only access to engine states.

'use strict';

const path = require('path');
const fs   = require('fs');

class OBSStorageManager {
  constructor(dbPath) {
    const basePath = path.join(__dirname, '..');
    this.dbPath = dbPath
      ? dbPath.replace('cce-production.db', 'obs-production.db')
      : path.join(basePath, 'data', 'obs-production.db');
    this.db = null;
  }

  async init() {
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const initSqlJs = require('sql.js');
    const SQL = await initSqlJs();

    if (fs.existsSync(this.dbPath)) {
      const buf = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(buf);
    } else {
      this.db = new SQL.Database();
    }

    this._createTables();
    this._saveTimer = setInterval(() => this._persist(), 60000);
    console.log('[OBS] Storage initialised (sql.js)');
  }

  _createTables() {
    // Core observation snapshot — taken every 15 minutes
    this.db.run(`CREATE TABLE IF NOT EXISTS observations (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp         DATETIME,
      obs_number        INTEGER,

      -- Engine states
      crypto_state      TEXT,
      forex_state       TEXT,
      reit_state        TEXT,
      stocks_state      TEXT,
      como_state        TEXT,
      grid_state        TEXT,

      -- Active engine count
      active_engines    INTEGER,
      dormant_engines   INTEGER,

      -- Crypto market data
      btc_price         REAL,
      btc_dominance     REAL,
      fear_greed        INTEGER,
      crypto_portfolio  REAL,

      -- Forex data
      eur_usd           REAL,
      forex_zscore      REAL,
      forex_rsi         REAL,

      -- REIT / rate environment
      fed_rate          REAL,
      treasury_yield    REAL,
      yield_spread      REAL,
      reit_price        REAL,

      -- Stocks data
      spy_price         REAL,
      vix               REAL,
      spy_rsi           REAL,
      spy_sma50         REAL,
      spy_sma200        REAL,

      -- Commodities data
      oil_price         REAL,
      gold_price        REAL,
      copper_price      REAL,
      dxy_price         REAL,

      -- Grid data
      grid_centre       REAL,
      grid_profit       REAL,
      grid_cycles       INTEGER,
      grid_open_buys    INTEGER,
      grid_open_sells   INTEGER
    )`);

    // State transitions — recorded when any engine changes state
    this.db.run(`CREATE TABLE IF NOT EXISTS state_transitions (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp       DATETIME,
      engine          TEXT,
      from_state      TEXT,
      to_state        TEXT,

      -- Market conditions at transition
      btc_price       REAL,
      fear_greed      INTEGER,
      vix             REAL,
      fed_rate        REAL,
      treasury_yield  REAL,
      oil_price       REAL,
      dxy_price       REAL,
      eur_usd         REAL
    )`);

    // Pattern snapshots — generated periodically from accumulated data
    this.db.run(`CREATE TABLE IF NOT EXISTS patterns (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp       DATETIME,
      pattern_type    TEXT,
      engine          TEXT,
      description     TEXT,
      data_json       TEXT,
      obs_count       INTEGER
    )`);

    // Daily summaries
    this.db.run(`CREATE TABLE IF NOT EXISTS daily_summaries (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      date            TEXT,
      obs_count       INTEGER,
      transitions     INTEGER,
      avg_fear_greed  REAL,
      avg_btc_price   REAL,
      avg_vix         REAL,
      active_pct      REAL,
      dormant_pct     REAL,
      summary_json    TEXT
    )`);
  }

  _persist() {
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (err) {
      console.error('[OBS] Persist error:', err.message);
    }
  }

  async logObservation(data) {
    this.db.run(
      `INSERT INTO observations (
        timestamp, obs_number,
        crypto_state, forex_state, reit_state, stocks_state, como_state, grid_state,
        active_engines, dormant_engines,
        btc_price, btc_dominance, fear_greed, crypto_portfolio,
        eur_usd, forex_zscore, forex_rsi,
        fed_rate, treasury_yield, yield_spread, reit_price,
        spy_price, vix, spy_rsi, spy_sma50, spy_sma200,
        oil_price, gold_price, copper_price, dxy_price,
        grid_centre, grid_profit, grid_cycles, grid_open_buys, grid_open_sells
      ) VALUES (
        ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
      )`,
      [
        new Date().toISOString(), data.obs_number,
        data.crypto_state, data.forex_state, data.reit_state,
        data.stocks_state, data.como_state, data.grid_state,
        data.active_engines, data.dormant_engines,
        data.btc_price, data.btc_dominance, data.fear_greed, data.crypto_portfolio,
        data.eur_usd, data.forex_zscore, data.forex_rsi,
        data.fed_rate, data.treasury_yield, data.yield_spread, data.reit_price,
        data.spy_price, data.vix, data.spy_rsi, data.spy_sma50, data.spy_sma200,
        data.oil_price, data.gold_price, data.copper_price, data.dxy_price,
        data.grid_centre, data.grid_profit, data.grid_cycles,
        data.grid_open_buys, data.grid_open_sells
      ]
    );
    this._persist();
  }

  async logTransition(data) {
    this.db.run(
      `INSERT INTO state_transitions (
        timestamp, engine, from_state, to_state,
        btc_price, fear_greed, vix, fed_rate,
        treasury_yield, oil_price, dxy_price, eur_usd
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.engine, data.from_state, data.to_state,
        data.btc_price, data.fear_greed, data.vix, data.fed_rate,
        data.treasury_yield, data.oil_price, data.dxy_price, data.eur_usd
      ]
    );
    this._persist();
  }

  async logPattern(type, engine, description, dataObj, obsCount) {
    this.db.run(
      `INSERT INTO patterns (timestamp, pattern_type, engine, description, data_json, obs_count)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), type, engine,
        description, JSON.stringify(dataObj), obsCount
      ]
    );
    this._persist();
  }

  async logDailySummary(data) {
    this.db.run(
      `INSERT OR REPLACE INTO daily_summaries (
        date, obs_count, transitions, avg_fear_greed,
        avg_btc_price, avg_vix, active_pct, dormant_pct, summary_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        data.date, data.obs_count, data.transitions,
        data.avg_fear_greed, data.avg_btc_price, data.avg_vix,
        data.active_pct, data.dormant_pct, JSON.stringify(data.summary)
      ]
    );
    this._persist();
  }

  async getObservations(limit = 1000) {
    const result = this.db.exec(
      `SELECT * FROM observations ORDER BY timestamp ASC LIMIT ${limit}`
    );
    if (!result.length) return [];
    const { columns, values } = result[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  }

  async getObservationCount() {
    const result = this.db.exec('SELECT COUNT(*) as count FROM observations');
    return result[0]?.values[0][0] || 0;
  }

  async getTransitions(limit = 50) {
    const result = this.db.exec(
      `SELECT * FROM state_transitions ORDER BY timestamp DESC LIMIT ${limit}`
    );
    if (!result.length) return [];
    const { columns, values } = result[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  }

  async getLatestPatterns(limit = 20) {
    const result = this.db.exec(
      `SELECT * FROM patterns ORDER BY timestamp DESC LIMIT ${limit}`
    );
    if (!result.length) return [];
    const { columns, values } = result[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  }

  async getDailySummaries(limit = 30) {
    const result = this.db.exec(
      `SELECT * FROM daily_summaries ORDER BY date DESC LIMIT ${limit}`
    );
    if (!result.length) return [];
    const { columns, values } = result[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  }

  async getLatestObservation() {
    const result = this.db.exec(
      'SELECT * FROM observations ORDER BY timestamp DESC LIMIT 1'
    );
    if (!result.length) return null;
    const { columns, values } = result[0];
    const obj = {};
    columns.forEach((col, i) => obj[col] = values[0][i]);
    return obj;
  }

  close() {
    if (this._saveTimer) clearInterval(this._saveTimer);
    this._persist();
    this.db.close();
    console.log('[OBS] Storage closed.');
  }
}

module.exports = OBSStorageManager;

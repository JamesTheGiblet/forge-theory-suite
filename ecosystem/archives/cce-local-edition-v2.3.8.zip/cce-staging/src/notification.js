// src/notification.js
// Telegram notification service for engine events

'use strict';

const axios = require('axios');

const ICONS = {
  info:    'ℹ️',
  success: '✅',
  warning: '⚠️',
  error:   '🚨',
  trade:   '💸',
  state:   '🔄',
  report:  '📈'
};

const MAX_MESSAGE_LENGTH = 4000; // Telegram hard limit is 4096 — leave buffer for icon/prefix
const TELEGRAM_TIMEOUT_MS = 5000;

class NotificationService {
  constructor(config) {
    this.enabled = config.notifications?.telegram?.enabled || false;
    this.token   = config.notifications?.telegram?.botToken;
    this.chatId  = config.notifications?.telegram?.chatId;

    // Only build baseUrl if token is present — avoids 'botundefined' URL
    this.baseUrl = this.token
      ? `https://api.telegram.org/bot${this.token}`
      : null;

    if (this.enabled && (!this.token || !this.chatId)) {
      console.warn('⚠️  Telegram notifications enabled but botToken or chatId is missing — notifications will be skipped.');
    }
  }

  async send(message, type = 'info') {
    if (!this.enabled || !this.token || !this.chatId || !this.baseUrl) return;

    const icon        = ICONS[type] || ICONS.info;
    const fullMessage = `${icon} ${message}`;

    // Truncate if over Telegram's character limit
    const safeMessage = fullMessage.length > MAX_MESSAGE_LENGTH
      ? fullMessage.slice(0, MAX_MESSAGE_LENGTH) + '\n<i>[Message truncated]</i>'
      : fullMessage;

    try {
      await axios.post(
        `${this.baseUrl}/sendMessage`,
        {
          chat_id:    this.chatId,
          text:       safeMessage,
          parse_mode: 'HTML'
        },
        { timeout: TELEGRAM_TIMEOUT_MS }
      );
    } catch (error) {
      // Non-fatal — log and continue. Never throw from notification service.
      console.error('⚠️  Telegram notification failed:', error.message);
    }
  }
}

module.exports = NotificationService;
// src/cce-lce-engine.js — T.E Liquidation Cascade Engine
// Rides liquidation cascades on 5-minute cycles
// Pattern: matches CCE platform engine architecture (config + sharedNotifier)

'use strict';

const axios = require('axios');

// ─── LCE Data Feed (self-contained, no external dependency) ─────────────────

class LCEDataFeed {
  constructor() {
    this.cache = {};
    this.cacheMs = 60_000;
  }

  async getLiquidations(symbol = 'BTC', windowMin = 15) {
    const key = `liq_${symbol}_${windowMin}`;
    if (this._isCached(key)) return this.cache[key].data;
    try {
      const binanceSymbol = symbol + 'USDT';
      const response = await axios.get(
        'https://fapi.binance.com/fapi/v1/allForceOrders',
        { params: { symbol: binanceSymbol, limit: 500 }, timeout: 8000 }
      );
      const orders = response.data || [];
      const cutoff = Date.now() - windowMin * 60 * 1000;
      const recent = orders.filter(o => o.time > cutoff);
      let longLiqUsd = 0, shortLiqUsd = 0;
      for (const o of recent) {
        const usd = parseFloat(o.origQty) * parseFloat(o.price);
        if (o.side === 'BUY') shortLiqUsd += usd;
        else longLiqUsd += usd;
      }
      const result = {
        symbol, longLiqUsd, shortLiqUsd,
        totalLiqUsd: longLiqUsd + shortLiqUsd,
        dominantSide: longLiqUsd > shortLiqUsd ? 'LONG' : 'SHORT',
        windowMin, ts: Date.now(),
      };
      this._setCache(key, result);
      return result;
    } catch (err) {
      return { symbol, totalLiqUsd: 0, longLiqUsd: 0, shortLiqUsd: 0, dominantSide: 'UNKNOWN', windowMin, ts: Date.now() };
    }
  }

  async getOpenInterest(symbol = 'BTC') {
    const key = `oi_${symbol}`;
    if (this._isCached(key)) return this.cache[key].data;
    try {
      const binanceSymbol = symbol + 'USDT';
      const [currentOI, histOI] = await Promise.all([
        axios.get('https://fapi.binance.com/fapi/v1/openInterest', { params: { symbol: binanceSymbol }, timeout: 6000 }),
        axios.get('https://fapi.binance.com/futures/data/openInterestHist', { params: { symbol: binanceSymbol, period: '5m', limit: 6 }, timeout: 6000 }),
      ]);
      const current = parseFloat(currentOI.data.openInterest);
      const hist = histOI.data || [];
      const prev = hist.length > 1 ? parseFloat(hist[hist.length - 2].sumOpenInterest) : current;
      const dropPct = Math.max(0, ((prev - current) / prev) * 100);
      const result = { symbol, currentOI: current, prevOI: prev, dropPct, ts: Date.now() };
      this._setCache(key, result);
      return result;
    } catch {
      return { symbol, currentOI: 0, prevOI: 0, dropPct: 0, ts: Date.now() };
    }
  }

  async getPriceData(krakenPair = 'XBTUSD') {
    const key = `price_${krakenPair}`;
    if (this._isCached(key)) return this.cache[key].data;
    try {
      const response = await axios.get('https://api.kraken.com/0/public/OHLC', {
        params: { pair: krakenPair, interval: 5 }, timeout: 8000,
      });
      const pairKey = Object.keys(response.data.result).find(k => k !== 'last');
      const candles = response.data.result[pairKey];
      if (!candles || candles.length < 20) throw new Error('Insufficient candles');
      const closes = candles.map(c => parseFloat(c[4]));
      const latest = closes[closes.length - 1];
      const prev5  = closes[closes.length - 6];
      const rsi    = this._calcRSI(closes, 14);
      const momentumPct = ((latest - prev5) / prev5) * 100;
      const result = { pair: krakenPair, price: latest, rsi, momentumPct, ts: Date.now() };
      this._setCache(key, result);
      return result;
    } catch {
      return null;
    }
  }

  async getSignalSnapshot(symbol) {
    const krakenMap = { 'BTC/USDT': 'XBTUSD', 'ETH/USDT': 'ETHUSD', 'SOL/USDT': 'SOLUSD' };
    const baseSymbol = symbol.split('/')[0];
    const krakenPair = krakenMap[symbol] || 'XBTUSD';
    const [liq5m, liq15m, oi, price] = await Promise.all([
      this.getLiquidations(baseSymbol, 5),
      this.getLiquidations(baseSymbol, 15),
      this.getOpenInterest(baseSymbol),
      this.getPriceData(krakenPair),
    ]);
    return { symbol, liq5m, liq15m, oi, price, ts: Date.now() };
  }

  _calcRSI(closes, period = 14) {
    if (closes.length < period + 1) return 50;
    let gains = 0, losses = 0;
    for (let i = closes.length - period; i < closes.length; i++) {
      const diff = closes[i] - closes[i - 1];
      if (diff > 0) gains += diff; else losses += Math.abs(diff);
    }
    const rs = gains / (losses || 0.001);
    return 100 - 100 / (1 + rs);
  }

  _isCached(key) { return this.cache[key] && (Date.now() - this.cache[key].ts < this.cacheMs); }
  _setCache(key, data) { this.cache[key] = { data, ts: Date.now() }; }
}

// ─── LCE Strategy FSM ────────────────────────────────────────────────────────

class LCEStrategy {
  constructor(lceConfig) {
    this.cfg = lceConfig;
    this.state = 'DORMANT';
    this.stateEnteredAt = Date.now();
    this.activePosition = null;
    this.stalkedSymbol  = null;
    this.stalkedSide    = null;
    this.dailyPnlPct    = 0;
    this.dailyTrades    = 0;
    this.dailyResetAt   = this._todayMidnight();
  }

  evaluate(snapshots) {
    this._checkDailyReset();
    if (this.dailyPnlPct <= -(this.cfg.maxDailyLossPct || 3)) {
      if (this.state !== 'DORMANT') this._transition('DORMANT');
      return { state: this.state, action: 'CIRCUIT_BREAKER', signal: null };
    }
    switch (this.state) {
      case 'DORMANT':   return this._evalDormant(snapshots);
      case 'STALKING':  return this._evalStalking(snapshots);
      case 'TRIGGERED': return this._evalTriggered(snapshots);
      case 'RIDING':    return this._evalRiding(snapshots);
      case 'EXITING':   return this._evalExiting(snapshots);
      default:          return { state: this.state, action: 'HOLD', signal: null };
    }
  }

  _evalDormant(snapshots) {
    const best = snapshots
      .filter(s => s.liq5m?.totalLiqUsd >= (this.cfg.minLiqUsd5m || 5_000_000))
      .sort((a, b) => b.liq5m.totalLiqUsd - a.liq5m.totalLiqUsd)[0];
    if (best) {
      this._transition('STALKING');
      this.stalkedSymbol = best.symbol;
      this.stalkedSide   = best.liq5m.dominantSide === 'LONG' ? 'SELL' : 'BUY';
      return { state: this.state, action: 'STALKING', signal: best };
    }
    return { state: this.state, action: 'DORMANT', signal: null };
  }

  _evalStalking(snapshots) {
    if (this._timeInState() > 15 * 60 * 1000) {
      this._transition('DORMANT');
      return { state: this.state, action: 'TIMEOUT', signal: null };
    }
    const snap = snapshots.find(s => s.symbol === this.stalkedSymbol);
    if (!snap) return { state: this.state, action: 'HOLD', signal: null };
    if (this._cascadeConfirmed(snap)) {
      this._transition('TRIGGERED');
      return { state: this.state, action: 'ENTER', signal: snap, side: this.stalkedSide, symbol: this.stalkedSymbol };
    }
    return { state: this.state, action: 'STALKING', signal: snap };
  }

  _evalTriggered(snapshots) {
    if (this.activePosition) { this._transition('RIDING'); return { state: this.state, action: 'RIDING', signal: null }; }
    if (this._timeInState() > 12 * 60 * 1000) { this._transition('DORMANT'); return { state: this.state, action: 'ABORT', signal: null }; }
    return { state: this.state, action: 'AWAITING_FILL', signal: null };
  }

  _evalRiding(snapshots) {
    if (!this.activePosition) { this._transition('DORMANT'); return { state: this.state, action: 'NO_POSITION', signal: null }; }
    const snap = snapshots.find(s => s.symbol === this.activePosition.symbol);
    const currentPrice = snap?.price?.price;
    if (!currentPrice) return { state: this.state, action: 'HOLD', signal: null };
    const { entryPrice, side, takeProfit } = this.activePosition;
    const pricePct = side === 'BUY'
      ? ((currentPrice - entryPrice) / entryPrice) * 100
      : ((entryPrice - currentPrice) / entryPrice) * 100;
    // Trailing stop update
    if (pricePct > 0.5) {
      const trail = (this.cfg.trailingStopPct || 0.5) / 100;
      const newStop = side === 'BUY' ? currentPrice * (1 - trail) : currentPrice * (1 + trail);
      if (side === 'BUY' && newStop > this.activePosition.stopLoss) this.activePosition.stopLoss = newStop;
      if (side === 'SELL' && newStop < this.activePosition.stopLoss) this.activePosition.stopLoss = newStop;
    }
    const stopHit = side === 'BUY' ? currentPrice <= this.activePosition.stopLoss : currentPrice >= this.activePosition.stopLoss;
    const tpHit   = side === 'BUY' ? currentPrice >= takeProfit : currentPrice <= takeProfit;
    const timeOut = this._timeInState() > (this.cfg.tradeWindowMs || 30 * 60 * 1000);
    if (stopHit || tpHit || timeOut) {
      const reason = stopHit ? 'STOP_LOSS' : tpHit ? 'TAKE_PROFIT' : 'TIMEOUT';
      this.dailyPnlPct += pricePct;
      this.dailyTrades++;
      this._transition('EXITING');
      return { state: this.state, action: 'EXIT', reason, symbol: this.activePosition.symbol, side: side === 'BUY' ? 'SELL' : 'BUY', pnlPct: pricePct };
    }
    return { state: this.state, action: 'HOLD', signal: null, pnlPct: pricePct };
  }

  _evalExiting(snapshots) {
    this.activePosition = null;
    if (this._timeInState() > 10 * 60 * 1000) this._transition('DORMANT');
    return { state: this.state, action: 'COOLING_DOWN', signal: null };
  }

  _cascadeConfirmed(snap) {
    // Returns boolean — confidence calculated separately
    return this._cascadeConfidence(snap) >= 0.6;
  }

  _cascadeConfidence(snap) {
    const scores = [];
    const liq15m = snap.liq15m?.totalLiqUsd || 0;
    const oi     = snap.oi?.dropPct || 0;
    const mom    = Math.abs(snap.price?.momentumPct || 0);
    const rsi    = snap.price?.rsi || 50;
    if (liq15m >= (this.cfg.minLiqUsd15m || 20_000_000)) scores.push(1);
    else if (liq15m >= 10_000_000) scores.push(0.5);
    else scores.push(0);
    if (oi >= (this.cfg.minOiDropPct || 1.5)) scores.push(1);
    else if (oi >= 0.75) scores.push(0.5);
    else scores.push(0);
    if (mom >= (this.cfg.minMomentumPct || 0.3)) scores.push(1);
    else scores.push(0);
    if (rsi >= 35 && rsi <= 65) scores.push(1);
    else if (rsi >= 25 && rsi <= 75) scores.push(0.7);
    else scores.push(0.3);
    return scores.reduce((a,b) => a+b, 0) / scores.length;
  }


  setPosition(pos)  { this.activePosition = pos; }
  clearPosition()   { this.activePosition = null; }

  _transition(s) { this.state = s; this.stateEnteredAt = Date.now(); }
  _timeInState()  { return Date.now() - this.stateEnteredAt; }
  _todayMidnight() { const d = new Date(); d.setHours(0,0,0,0); return d.getTime(); }
  _checkDailyReset() {
    if (Date.now() > this.dailyResetAt + 86_400_000) {
      this.dailyPnlPct = 0; this.dailyTrades = 0; this.dailyResetAt = this._todayMidnight();
    }
  }

  getStatus() {
    return { state: this.state, activePosition: this.activePosition, dailyPnlPct: this.dailyPnlPct, dailyTrades: this.dailyTrades };
  }
}

// ─── LCE Engine (platform-compatible) ───────────────────────────────────────


module.exports = { LCEDataFeed, LCEStrategy };

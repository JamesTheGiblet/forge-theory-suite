// src/cce-cme-engine.js
// CCE Stocks Engine (CME) — SPY Momentum Lag
// Runs as a fourth engine inside the same process.
// Completely independent capital, state machine, and data feed.
// Shares only the NotificationService (prefixed [CME]).
//
// Thesis: Exploit the lag between institutional breakout confirmation
//         and retail participation in SPY momentum moves.

'use strict';

const { CMEStateMachine, CMESignals } = require('./cme-strategy');
const CMEDataFeed                      = require('./cme-data-feed');
const CMEStorageManager                = require('./cme-storage');

class CCECMEEngine {
  constructor(config, notifier) {
    this.config   = config;
    this.notifier = notifier;

    this.fsm      = new CMEStateMachine(config.cme?.fsm || {});
    this.signals  = new CMESignals();
    this.dataFeed = new CMEDataFeed(config);
    this.storage  = new CMEStorageManager(config.database?.path);

    this.isRunning       = false;
    this.runCount        = 0;
    this.dryRun          = config.cme?.dryRun !== false; // Default: dry run
    this.startingCapital = config.cme?.startingCapital || 300;
    this.portfolioValue  = this.startingCapital;
    this.lastReportValue = this.startingCapital;
    this.inPosition      = false;
    this.entryPrice      = null;
    this.entryDate       = null;
  }

  async start(intervalHours = 24) {
    this.isRunning = true;
    const intervalMs = intervalHours * 60 * 60 * 1000;

    await this.storage.init();

    console.log('\n[CME] 📈 Starting CCE Stocks Engine (CME)');
    console.log(`[CME] ⏱️  Check Interval: ${intervalHours}h`);
    console.log(`[CME] 💰 Starting Capital: £${this.startingCapital}`);
    console.log(`[CME] 🔧 Mode: ${this.dryRun ? 'DRY RUN' : 'LIVE ⚠️'}`);
    console.log(`[CME] 📍 Symbol: ${this.config.cme?.symbol || 'SPY'} | Strategy: Momentum Lag\n`);

    await this.notifier.send(
      `<b>[CME] 📈 CCE Stocks Engine Started</b>\nCapital: £${this.startingCapital}\nSymbol: ${this.config.cme?.symbol || 'SPY'}\nMode: ${this.dryRun ? 'DRY RUN' : '⚠️ LIVE'}`,
      'info'
    );

    while (this.isRunning) {
      await this.runCycle();
      if (!this.isRunning) break;

      const nextRun = new Date(Date.now() + intervalMs);
      console.log(`[CME] ⏳ Next run: ${nextRun.toLocaleString()}`);
      await this._sleep(intervalMs);
    }

    console.log('[CME] 🛑 CME engine loop exited.');
  }

  stop() {
    console.log('[CME] 🛑 Stopping CCE Stocks Engine...');
    this.isRunning = false;
    this.storage.close();
  }

  async runCycle() {
    try {
      this.runCount++;
      console.log(`\n[CME] ${'─'.repeat(60)}`);
      console.log(`[CME] 🔄 RUN #${this.runCount} — ${new Date().toISOString()}`);
      console.log(`[CME]    State: ${this.fsm.currentState} — ${this.fsm.getStateSummary()}`);
      console.log(`[CME] ${'─'.repeat(60)}`);

      // 1. Fetch market data
      const market = await this.dataFeed.getMarketData();

      if (market.error) {
        console.warn('[CME] ⚠️  Data feed error — skipping cycle');
        return;
      }

      // 2. Calculate signals
      const sig = this.signals.getAllSignals(market);

      console.log(`[CME] 📈 ${market.symbol}: $${market.price}`);
      console.log(`[CME] 📊 SMA50: $${market.sma50} | SMA200: $${market.sma200} | ${market.goldenCross ? '✅ Golden Cross' : '❌ Death Cross'}`);
      console.log(`[CME] 📉 RSI: ${market.rsi} | VIX: ${market.vix} | Breadth: ${market.breadthScore.toFixed(0)}%`);
      console.log(`[CME] 📦 Volume: ${market.volumeConfirming ? '✅ Confirming' : '⚠️ Below avg'} | Momentum 4w: ${market.momentum4w}%`);

      // 3. Build FSM context
      const context = {
        price:            market.price,
        sma50:            market.sma50,
        sma200:           market.sma200,
        aboveSma20:       market.aboveSma20,
        aboveSma50:       market.aboveSma50,
        aboveSma200:      market.aboveSma200,
        rsi:              market.rsi,
        momentum4w:       market.momentum4w,
        vix:              market.vix,
        vixRising:        market.vixRising,
        vixLow:           market.vixLow,
        vixElevated:      market.vixElevated,
        vixHigh:          market.vixHigh,
        breadthScore:     market.breadthScore,
        breadthHealthy:   market.breadthHealthy,
        volumeConfirming: market.volumeConfirming,
        goldenCross:      market.goldenCross,
        deathCross:       market.deathCross,
        signals:          sig
      };

      // 4. Evaluate FSM transition
      const transition = this.fsm.evaluateTransition(context);

      if (transition.transitioned) {
        console.log(`\n[CME] 📝 STATE: ${transition.from} → ${transition.to}`);
        console.log(`[CME]    Reason: ${transition.reason}`);
        await this._handleTransition(transition, market, sig);
      } else {
        console.log(`[CME] ✅ State: ${this.fsm.currentState} (no change)`);
        if (this.inPosition) {
          const unrealised = this.entryPrice
            ? (((market.price - this.entryPrice) / this.entryPrice) * 100).toFixed(2)
            : '0.00';
          console.log(`[CME]    Position: LONG ${market.symbol} @ $${this.entryPrice?.toFixed(2)} | Unrealised: ${unrealised}%`);
        }
      }

      // 5. Log cycle
      const daysInState = this.fsm.getDaysInState();
      const totalReturn = ((this.portfolioValue - this.startingCapital) / this.startingCapital) * 100;
      const dailyReturn = ((this.portfolioValue - this.lastReportValue) / this.lastReportValue) * 100;

      await this.storage.logCycle({
        cycle_number:     this.runCount,
        state:            this.fsm.currentState,
        previous_state:   this.fsm.previousState,
        price:            market.price,
        sma50:            market.sma50,
        sma200:           market.sma200,
        rsi:              market.rsi,
        vix:              market.vix,
        breadth_score:    market.breadthScore,
        momentum_4w:      market.momentum4w,
        volume:           market.volume,
        avg_volume:       market.avgVolume20,
        days_in_state:    daysInState,
        portfolio_value:  this.portfolioValue,
        daily_return:     dailyReturn,
        total_return:     totalReturn,
        above_sma50:      market.aboveSma50,
        above_sma200:     market.aboveSma200,
        golden_cross:     market.goldenCross,
        volume_confirming: market.volumeConfirming
      });

      // 6. Weekly report every 7 cycles
      if (this.runCount > 0 && this.runCount % 7 === 0) {
        await this._weeklyReport(market);
      }

      console.log(`[CME] ${'─'.repeat(60)}\n`);

    } catch (err) {
      console.error('[CME] ❌ Cycle error:', err.message);
      await this.notifier.send(
        `<b>[CME] ⚠️ Cycle Error</b>\n${err.message}`,
        'error'
      );
    }
  }

  // ============================================================================
  // TRANSITION HANDLERS
  // ============================================================================

  async _handleTransition(transition, market, sig) {
    const { from, to, reason } = transition;

    switch (to) {

      case 'WATCHING': {
        if (from === 'DORMANT') {
          await this.notifier.send(
            `<b>[CME] 👀 WATCHING — Market Structure Healthy</b>\n\nSPY: $${market.price}\nSMA200: $${market.sma200}\nVIX: ${market.vix}\n\nScanning for momentum setup.\nReason: ${reason}`,
            'info'
          );
        }
        break;
      }

      case 'PRIMED': {
        await this.notifier.send(
          `<b>[CME] 🎯 PRIMED — Breakout Conditions Forming</b>\n\nSPY: $${market.price}\nSMA50: $${market.sma50} ✅\nRSI: ${market.rsi}\nVIX: ${market.vix} ✅\n${market.goldenCross ? 'Golden Cross ✅' : ''}\n\nWaiting for full confirmation.\nReason: ${reason}`,
          'info'
        );
        break;
      }

      case 'ENTERING': {
        this.inPosition = true;
        this.entryPrice = market.price;
        this.entryDate  = new Date();

        const msg = [
          `<b>[CME] 📈 ENTERING — Deploy into SPY</b>`,
          ``,
          `<b>Action:</b> BUY ${market.symbol}`,
          `<b>Entry:</b>  $${market.price}`,
          `<b>Capital:</b> £${this.portfolioValue.toFixed(2)}`,
          ``,
          `<b>RSI:</b> ${market.rsi}`,
          `<b>VIX:</b> ${market.vix}`,
          `<b>SMA50:</b> $${market.sma50}`,
          `<b>SMA200:</b> $${market.sma200}`,
          `<b>Breadth:</b> ${market.breadthScore.toFixed(0)}%`,
          `<b>Volume:</b> ${market.volumeConfirming ? 'Confirming ✅' : 'Weak ⚠️'}`,
          ``,
          `<b>Dynamic stop:</b> Close below SMA50 ($${market.sma50})`,
          ``,
          `${this.dryRun ? '🔵 DRY RUN — No action needed' : `⚠️ BUY ${market.symbol} on your broker NOW`}`
        ].join('\n');

        await this.notifier.send(msg, 'trade');

        await this.storage.logTrade({
          action:        'BUY',
          symbol:        market.symbol,
          price:         market.price,
          portfolio_value: this.portfolioValue,
          rsi:           market.rsi,
          vix:           market.vix,
          sma50:         market.sma50,
          sma200:        market.sma200,
          breadth_score: market.breadthScore,
          reason
        });
        break;
      }

      case 'HOLDING':
        console.log(`[CME] ✅ Position active — monitoring`);
        break;

      case 'EXITING': {
        const holdDays = this.entryDate
          ? Math.round((Date.now() - this.entryDate.getTime()) / 86400000)
          : 0;

        const returnPct = this.entryPrice
          ? (((market.price - this.entryPrice) / this.entryPrice) * 100)
          : 0;

        const outcome = returnPct > 0 ? 'WIN' : returnPct < 0 ? 'LOSS' : 'BREAK EVEN';
        const emoji   = returnPct > 0 ? '✅' : returnPct < 0 ? '❌' : '➖';

        // Update portfolio
        this.portfolioValue = this.portfolioValue * (1 + returnPct / 100);
        const totalReturn   = ((this.portfolioValue - this.startingCapital) / this.startingCapital) * 100;

        const msg = [
          `<b>[CME] ${emoji} EXIT — ${outcome}</b>`,
          ``,
          `Entry:  $${this.entryPrice?.toFixed(2)}`,
          `Exit:   $${market.price}`,
          `Return: ${returnPct >= 0 ? '+' : ''}${returnPct.toFixed(2)}%`,
          `Hold:   ${holdDays} days`,
          ``,
          `Portfolio: £${this.portfolioValue.toFixed(2)}`,
          `Total Return: ${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(2)}%`,
          ``,
          `${this.dryRun ? '🔵 DRY RUN' : `⚠️ SELL ${market.symbol} on your broker NOW`}`,
          `Reason: ${reason}`
        ].join('\n');

        await this.notifier.send(msg, returnPct > 0 ? 'trade' : 'warning');

        await this.storage.logTrade({
          action:        'SELL',
          symbol:        market.symbol,
          price:         market.price,
          portfolio_value: this.portfolioValue,
          rsi:           market.rsi,
          vix:           market.vix,
          sma50:         market.sma50,
          sma200:        market.sma200,
          breadth_score: market.breadthScore,
          days_held:     holdDays,
          return_pct:    returnPct,
          reason,
          outcome:       outcome.toLowerCase()
        });

        this.inPosition = false;
        this.entryPrice = null;
        this.entryDate  = null;
        break;
      }

      case 'DORMANT': {
        if (from !== 'DORMANT') {
          await this.notifier.send(
            `<b>[CME] 😴 Returning to DORMANT</b>\nReason: ${reason}\nVIX: ${market.vix}\nSPY: $${market.price}`,
            'info'
          );
        }
        break;
      }
    }
  }

  // ============================================================================
  // REPORTING
  // ============================================================================

  async _weeklyReport(market) {
    const totalReturn  = ((this.portfolioValue - this.startingCapital) / this.startingCapital) * 100;
    const periodReturn = ((this.portfolioValue - this.lastReportValue) / this.lastReportValue) * 100;

    const msg = [
      `<b>[CME] 📊 Weekly Report</b>`,
      ``,
      `Portfolio: £${this.portfolioValue.toFixed(2)}`,
      `Week: ${periodReturn >= 0 ? '+' : ''}${periodReturn.toFixed(2)}%`,
      `Total: ${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(2)}%`,
      ``,
      `${market.symbol}: $${market.price}`,
      `RSI: ${market.rsi} | VIX: ${market.vix}`,
      `SMA50: $${market.sma50} | SMA200: $${market.sma200}`,
      `${market.goldenCross ? '✅ Golden Cross' : '❌ No Golden Cross'}`,
      `State: ${this.fsm.currentState}`,
      `Cycles: ${this.runCount}`
    ].join('\n');

    await this.notifier.send(msg, 'report');
    this.lastReportValue = this.portfolioValue;

    await this.storage.saveSnapshot(
      this.portfolioValue,
      this.fsm.currentState,
      market.price,
      totalReturn
    );
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = CCECMEEngine;

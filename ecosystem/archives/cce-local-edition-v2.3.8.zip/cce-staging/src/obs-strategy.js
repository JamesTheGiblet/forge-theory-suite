// src/obs-strategy.js
// O.E Observer — Pattern Recognition and Data Models
// Analyses accumulated observation data to identify patterns
// across engine states and market conditions.
// PASSIVE ONLY — never makes decisions, never affects engines.

'use strict';

class OBSAnalytics {

  // ============================================================================
  // PATTERN ANALYSIS
  // ============================================================================

  // How long does each engine spend in each state on average?
  analyseStateDurations(observations) {
    const durations = {}; // { engine: { state: [durations] } }

    const engineKeys = ['crypto_state', 'forex_state', 'reit_state', 'stocks_state', 'como_state', 'grid_state'];
    const engineNames = ['crypto', 'forex', 'reit', 'stocks', 'como', 'grid'];

    engineNames.forEach(engine => { durations[engine] = {}; });

    // Track state entry times
    let prevStates = {};
    let stateEntryTime = {};

    observations.forEach((obs, i) => {
      engineNames.forEach((engine, ei) => {
        const state = obs[engineKeys[ei]];
        if (!state) return;

        if (prevStates[engine] !== state) {
          // State changed — record duration of previous state
          if (prevStates[engine] && stateEntryTime[engine]) {
            const duration = (new Date(obs.timestamp) - new Date(stateEntryTime[engine])) / 3600000; // hours
            if (!durations[engine][prevStates[engine]]) durations[engine][prevStates[engine]] = [];
            durations[engine][prevStates[engine]].push(duration);
          }
          prevStates[engine]    = state;
          stateEntryTime[engine] = obs.timestamp;
        }
      });
    });

    // Calculate averages
    const summary = {};
    engineNames.forEach(engine => {
      summary[engine] = {};
      Object.entries(durations[engine]).forEach(([state, durs]) => {
        summary[engine][state] = {
          count:   durs.length,
          avgHours: +(durs.reduce((a, b) => a + b, 0) / durs.length).toFixed(1),
          minHours: +Math.min(...durs).toFixed(1),
          maxHours: +Math.max(...durs).toFixed(1)
        };
      });
    });

    return summary;
  }

  // What market conditions preceded each state transition?
  analyseTransitionConditions(observations) {
    const conditions = {}; // { 'engine:from->to': [market conditions] }

    const engineKeys  = ['crypto_state', 'forex_state', 'reit_state', 'stocks_state', 'como_state', 'grid_state'];
    const engineNames = ['crypto', 'forex', 'reit', 'stocks', 'como', 'grid'];

    let prevStates = {};

    observations.forEach((obs, i) => {
      if (i === 0) {
        engineNames.forEach((e, ei) => prevStates[e] = obs[engineKeys[ei]]);
        return;
      }

      engineNames.forEach((engine, ei) => {
        const state = obs[engineKeys[ei]];
        if (!state) return;

        if (prevStates[engine] && prevStates[engine] !== state) {
          const key = `${engine}:${prevStates[engine]}->${state}`;
          if (!conditions[key]) conditions[key] = [];

          // Record market conditions at transition
          conditions[key].push({
            timestamp:   obs.timestamp,
            btc_price:   obs.btc_price,
            fear_greed:  obs.fear_greed,
            btc_dominance: obs.btc_dominance,
            vix:         obs.vix,
            fed_rate:    obs.fed_rate,
            treasury:    obs.treasury_yield,
            oil_price:   obs.oil_price,
            dxy:         obs.dxy_price
          });
        }

        prevStates[engine] = state;
      });
    });

    return conditions;
  }

  // Which engines are active simultaneously? (correlation matrix)
  analyseEngineCorrelation(observations) {
    const engineNames = ['crypto', 'forex', 'reit', 'stocks', 'como', 'grid'];
    const activeStates = [
      'ACCUMULATION', 'ANCHOR', 'IGNITION', 'CASCADE_1', 'CASCADE_2', 'SPILLWAY',
      'EXECUTE', 'EXTRACT', 'WATCHING', 'ENTERING', 'HOLDING',
      'PRIMED', 'ROTATING', 'CASCADING', 'ACTIVE', 'OBSERVE'
    ];

    const engineKeys = ['crypto_state', 'forex_state', 'reit_state', 'stocks_state', 'como_state', 'grid_state'];

    const isActive = (state) => activeStates.includes(state);

    // Build co-activity matrix
    const matrix = {};
    engineNames.forEach(e1 => {
      matrix[e1] = {};
      engineNames.forEach(e2 => { matrix[e1][e2] = 0; });
    });

    let totalObs = observations.length;

    observations.forEach(obs => {
      engineNames.forEach((e1, i1) => {
        if (isActive(obs[engineKeys[i1]])) {
          engineNames.forEach((e2, i2) => {
            if (isActive(obs[engineKeys[i2]])) {
              matrix[e1][e2]++;
            }
          });
        }
      });
    });

    // Convert to percentages
    const pctMatrix = {};
    engineNames.forEach(e1 => {
      pctMatrix[e1] = {};
      engineNames.forEach(e2 => {
        pctMatrix[e1][e2] = totalObs > 0
          ? +(matrix[e1][e2] / totalObs * 100).toFixed(1)
          : 0;
      });
    });

    return pctMatrix;
  }

  // Market regime analysis — what does the market look like when engines are active?
  analyseMarketRegimes(observations) {
    const regimes = {
      extreme_fear:  { count: 0, activeEngines: [] },
      fear:          { count: 0, activeEngines: [] },
      neutral:       { count: 0, activeEngines: [] },
      greed:         { count: 0, activeEngines: [] },
      extreme_greed: { count: 0, activeEngines: [] }
    };

    observations.forEach(obs => {
      const fg = obs.fear_greed || 50;
      let regime;
      if      (fg <= 20) regime = 'extreme_fear';
      else if (fg <= 40) regime = 'fear';
      else if (fg <= 60) regime = 'neutral';
      else if (fg <= 80) regime = 'greed';
      else               regime = 'extreme_greed';

      regimes[regime].count++;

      // Record which engines were active in this regime
      const engineKeys = ['crypto_state','forex_state','reit_state','stocks_state','como_state','grid_state'];
      const engineNames = ['crypto','forex','reit','stocks','como','grid'];
      const activeStates = ['ACCUMULATION','ANCHOR','IGNITION','CASCADE_1','CASCADE_2','SPILLWAY','EXECUTE','WATCHING','ENTERING','HOLDING','ACTIVE','OBSERVE','STALKING','TRIGGERED','RIDING','SCANNING','STANDBY'];
      engineNames.forEach((eng, i) => {
        if (activeStates.includes(obs[engineKeys[i]])) {
          if (!regimes[regime].activeEngines.includes(eng)) {
            regimes[regime].activeEngines.push(eng);
          }
        }
      });
    });

    return regimes;
  }

  // Generate a human-readable insight summary
  generateInsights(stateDurations, transitionConditions, correlation) {
    const insights = [];

    // State duration insights
    Object.entries(stateDurations).forEach(([engine, states]) => {
      Object.entries(states).forEach(([state, data]) => {
        if (data.count >= 2) {
          insights.push({
            type:    'duration',
            engine,
            insight: `${engine.toUpperCase()} spends avg ${data.avgHours}h in ${state} (${data.count} occurrences)`
          });
        }
      });
    });

    // Transition insights
    Object.entries(transitionConditions).forEach(([key, conditions]) => {
      if (conditions.length >= 2) {
        const avgFG  = conditions.reduce((s, c) => s + (c.fear_greed || 0), 0) / conditions.length;
        const avgBTC = conditions.reduce((s, c) => s + (c.btc_price || 0), 0) / conditions.length;
        insights.push({
          type:    'transition',
          key,
          insight: `${key} triggered ${conditions.length}x — avg F&G: ${avgFG.toFixed(0)}, avg BTC: $${Math.round(avgBTC)}`
        });
      }
    });


    // Correlation insights — engines that are frequently active together
    if (correlation) {
      const engineNames = ['crypto', 'forex', 'reit', 'stocks', 'como', 'grid'];
      engineNames.forEach(e1 => {
        engineNames.forEach(e2 => {
          if (e1 >= e2) return; // avoid duplicates
          const pct = correlation[e1]?.[e2] || 0;
          if (pct >= 20) {
            insights.push({
              type:    'correlation',
              insight: `${e1.toUpperCase()} and ${e2.toUpperCase()} are active simultaneously ${pct}% of the time`
            });
          }
        });
      });
    }
    return insights;
  }
}

module.exports = OBSAnalytics;

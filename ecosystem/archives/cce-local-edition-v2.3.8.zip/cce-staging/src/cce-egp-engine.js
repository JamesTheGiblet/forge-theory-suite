// src/cce-egp-engine.js
// S.E EGP — USD/EGP Regime Classification Engine
// Policy-driven managed float — weekly cycle
// Regimes: ACCUMULATE | DORMANT | FADE | CAUTION

'use strict';

const EGPStrategy      = require('./egp-strategy');
const EGPStorageManager = require('./egp-storage');
const https             = require('https');

class CCEEGPEngine {
  constructor(config, notifier) {
    this.config    = config;
    this.notifier  = notifier;
    this.isRunning = false;
    this.runCount  = 0;

    const egpCfg = config.egp || {};

    this.dryRun          = egpCfg.dryRun !== false;
    this.intervalMinutes = egpCfg.intervalMinutes || 10080; // 7 days
    this.storage         = new EGPStorageManager(config.database?.path);

    // Current state
    this.state     = 'DORMANT';
    this.inputs    = null;

    // Known inputs — seeded with latest available data
    // Updated by auto-fetch where possible, manual override via Telegram
    this.knownInputs = {
      cbe_rate:         egpCfg.cbeRate         || 19.0,   // % overnight deposit
      prev_cbe_rate:    egpCfg.prevCbeRate      || 20.0,   // before last cut
      inflation:        egpCfg.inflation        || 13.4,   // Feb 2026 CPI
      prev_inflation:   egpCfg.prevInflation    || 12.0,   // Jan 2026 CPI
      reserves:         egpCfg.reserves         || 52.7,   // $bn end Feb 2026
      prev_reserves:    egpCfg.prevReserves     || 47.1,   // prior month
      cds_delta:        egpCfg.cdsDelta         || 0,      // manual watch
      next_cbe_meeting: egpCfg.nextCbeMeeting   || '2026-04-02'
    };
  }

  async start(intervalMinutes) {
    this.isRunning = true;
    const interval = (intervalMinutes || this.intervalMinutes) * 60 * 1000;

    await this.storage.init();

    console.log('\n[EGP] 🏦 Starting S.E EGP Engine');
    console.log(`[EGP] ⏱️  Interval: Weekly`);
    console.log(`[EGP] 📊 Pair: USD/EGP | Strategy: Regime Classification`);
    console.log(`[EGP] 🔧 Mode: ${this.dryRun ? 'DRY RUN' : '⚠️ LIVE'}`);
    console.log(`[EGP] 📅 Next CBE meeting: ${this.knownInputs.next_cbe_meeting}\n`);

    await this.notifier.send([
      `<b>[EGP] 🏦 S.E EGP Engine Started</b>`,
      ``,
      `Pair: USD/EGP`,
      `Strategy: CBE Regime Classification`,
      `CBE Rate: ${this.knownInputs.cbe_rate}%`,
      `Inflation: ${this.knownInputs.inflation}%`,
      `Reserves: $${this.knownInputs.reserves}bn`,
      `Next CBE meeting: ${this.knownInputs.next_cbe_meeting}`,
      `Mode: ${this.dryRun ? 'DRY RUN' : '⚠️ LIVE'}`
    ].join('\n'), 'info');

    while (this.isRunning) {
      await this._runCycle();
      if (!this.isRunning) break;
      const next = new Date(Date.now() + interval);
      console.log(`[EGP] ⏳ Next cycle: ${next.toLocaleDateString()} ${next.toLocaleTimeString()}`);
      await this._sleep(interval);
    }
  }

  stop() {
    console.log('[EGP] 🛑 Stopping S.E EGP Engine...');
    this.isRunning = false;
    this.storage.close();
  }

  // ============================================================================
  // MAIN CYCLE
  // ============================================================================

  async _runCycle() {
    try {
      this.runCount++;

      console.log(`\n[EGP] ${'─'.repeat(50)}`);
      console.log(`[EGP] 🔄 Run #${this.runCount} | ${new Date().toLocaleString()}`);

      // 1. Fetch live data
      const liveData = await this._fetchLiveData();

      // 2. Build inputs
      const inputs = this._buildInputs(liveData);
      this.inputs  = inputs;

      // 3. Determine regime
      const result = EGPStrategy.determineState(inputs);
      const prevState = this.state;

      console.log(`[EGP] 📊 Composite score: ${result.composite}`);
      console.log(`[EGP] 🚩 Divergence flag: ${result.divergence_flag ? 'YES ⚠️' : 'no'}`);
      console.log(`[EGP] 🏦 CBE Rate: ${inputs.cbe_rate}% (delta: ${inputs.cbe_rate_delta > 0 ? '+' : ''}${inputs.cbe_rate_delta}%)`);
      console.log(`[EGP] 📈 Inflation: ${inputs.inflation}% (delta: ${inputs.inflation_delta > 0 ? '+' : ''}${inputs.inflation_delta}%)`);
      console.log(`[EGP] 💰 Reserves: $${inputs.reserves}bn (delta: ${inputs.reserves_delta > 0 ? '+' : ''}${inputs.reserves_delta})`);
      console.log(`[EGP] 🛢️  Brent: $${inputs.brent_level?.toFixed(2)}`);
      console.log(`[EGP] 💱 USD/EGP: ${liveData.usd_egp || '--'}`);

      // 4. Apply state
      this.state = result.state;

      const stateIcon = result.state === 'ACCUMULATE' ? '🟢'
                      : result.state === 'FADE'       ? '🔴'
                      : result.state === 'CAUTION'    ? '⚠️'
                      : '🟡';

      console.log(`\n[EGP] ${stateIcon} STATE: ${prevState} → ${result.state}`);
      console.log(`[EGP]    ${result.reason}`);

      // 5. Log to database
      await this.storage.logCycle({
        run_number:       this.runCount,
        state:            result.state,
        prev_state:       prevState,
        composite_score:  result.composite,
        divergence_flag:  result.divergence_flag,
        cbe_rate:         inputs.cbe_rate,
        cbe_rate_delta:   inputs.cbe_rate_delta,
        inflation:        inputs.inflation,
        inflation_delta:  inputs.inflation_delta,
        reserves:         inputs.reserves,
        reserves_delta:   inputs.reserves_delta,
        brent_level:      inputs.brent_level,
        cds_delta:        inputs.cds_delta,
        usd_egp_rate:     liveData.usd_egp,
        reason:           result.reason,
        next_cbe_meeting: this.knownInputs.next_cbe_meeting
      });

      // 6. Notify on state change
      if (prevState !== result.state) {
        await this.storage.logTransition({
          from_state:      prevState,
          to_state:        result.state,
          composite_score: result.composite,
          divergence_flag: result.divergence_flag,
          trigger_signal:  result.divergence_flag ? 'DIVERGENCE' : `score_${result.composite}`,
          usd_egp_rate:    liveData.usd_egp
        });

        await this._notifyStateChange(prevState, result, liveData, inputs);
      }

      console.log(`[EGP] ${'─'.repeat(50)}`);

    } catch (err) {
      console.error('[EGP] ❌ Cycle error:', err.message);
    }
  }

  // ============================================================================
  // DATA FEEDS
  // ============================================================================

  async _fetchLiveData() {
    const data = {};

    // Brent crude — reuse Yahoo Finance
    try {
      data.brent = await this._fetchBrent();
      console.log(`[EGP] 🛢️  Brent fetched: $${data.brent?.toFixed(2)}`);
    } catch (e) {
      console.log('[EGP] ⚠️  Brent fetch failed — using last known');
    }

    // USD/EGP spot rate — Yahoo Finance
    try {
      data.usd_egp = await this._fetchUSDEGP();
      console.log(`[EGP] 💱 USD/EGP fetched: ${data.usd_egp?.toFixed(4)}`);
    } catch (e) {
      console.log('[EGP] ⚠️  USD/EGP fetch failed');
    }

    // CBE rate — attempt scrape
    try {
      const cbeRate = await this._scrapeCBERate();
      if (cbeRate && cbeRate !== this.knownInputs.cbe_rate) {
        console.log(`[EGP] 🏦 CBE rate updated: ${this.knownInputs.cbe_rate}% → ${cbeRate}%`);
        this.knownInputs.prev_cbe_rate = this.knownInputs.cbe_rate;
        this.knownInputs.cbe_rate      = cbeRate;

        await this.notifier.send([
          `<b>[EGP] 🏦 CBE Rate Change Detected</b>`,
          `${this.knownInputs.prev_cbe_rate}% → ${cbeRate}%`,
          `Auto-scraped from cbe.org.eg`
        ].join('\n'), 'info');
      }
    } catch (e) {
      console.log('[EGP] ⚠️  CBE scrape failed — using known rate');
    }

    return data;
  }

  async _fetchBrent() {
    return new Promise((resolve, reject) => {
      const url = 'https://query1.finance.yahoo.com/v8/finance/chart/BZ=F?interval=1d&range=1d';
      https.get(url, { headers: { 'User-Agent': 'CCE-EGP/1.0' } }, res => {
        let body = '';
        res.on('data', c => body += c);
        res.on('end', () => {
          try {
            const d = JSON.parse(body);
            const price = d?.chart?.result?.[0]?.meta?.regularMarketPrice;
            resolve(price ? parseFloat(price) : null);
          } catch (e) { reject(e); }
        });
      }).on('error', reject);
    });
  }

  async _fetchUSDEGP() {
    return new Promise((resolve, reject) => {
      const url = 'https://query1.finance.yahoo.com/v8/finance/chart/USDEGP=X?interval=1d&range=1d';
      https.get(url, { headers: { 'User-Agent': 'CCE-EGP/1.0' } }, res => {
        let body = '';
        res.on('data', c => body += c);
        res.on('end', () => {
          try {
            const d = JSON.parse(body);
            const price = d?.chart?.result?.[0]?.meta?.regularMarketPrice;
            resolve(price ? parseFloat(price) : null);
          } catch (e) { reject(e); }
        });
      }).on('error', reject);
    });
  }

  async _scrapeCBERate() {
    // Attempt to fetch CBE overnight deposit rate from public page
    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'www.cbe.org.eg',
        path:     '/en-US/monetary-policy/Pages/MPC-Decisions.aspx',
        method:   'GET',
        headers:  { 'User-Agent': 'CCE-EGP/1.0', 'Accept': 'text/html' },
        timeout:  8000
      };

      https.get(options, res => {
        let body = '';
        res.on('data', c => body += c);
        res.on('end', () => {
          try {
            // Look for overnight deposit rate pattern
            const match = body.match(/overnight deposit[^0-9]*(\d+\.?\d*)\s*%/i)
                       || body.match(/(\d+\.?\d*)\s*%[^0-9]*overnight deposit/i);
            resolve(match ? parseFloat(match[1]) : null);
          } catch (e) { resolve(null); }
        });
      }).on('error', () => resolve(null))
        .on('timeout', () => resolve(null));
    });
  }

  // ============================================================================
  // INPUT BUILDER
  // ============================================================================

  _buildInputs(liveData) {
    return {
      cbe_rate:       this.knownInputs.cbe_rate,
      cbe_rate_delta: +(this.knownInputs.cbe_rate - this.knownInputs.prev_cbe_rate).toFixed(2),
      inflation:      this.knownInputs.inflation,
      inflation_delta:+(this.knownInputs.inflation - this.knownInputs.prev_inflation).toFixed(2),
      reserves:       this.knownInputs.reserves,
      reserves_delta: +(this.knownInputs.reserves - this.knownInputs.prev_reserves).toFixed(2),
      brent_level:    liveData.brent || 102,
      cds_delta:      this.knownInputs.cds_delta || 0
    };
  }

  // ============================================================================
  // NOTIFICATIONS
  // ============================================================================

  async _notifyStateChange(prevState, result, liveData, inputs) {
    const icon = result.state === 'ACCUMULATE' ? '🟢'
               : result.state === 'FADE'       ? '🔴'
               : result.state === 'CAUTION'    ? '⚠️'
               : '🟡';

    await this.notifier.send([
      `<b>[EGP] ${icon} Regime Change</b>`,
      ``,
      `${prevState} → <b>${result.state}</b>`,
      ``,
      `${result.reason}`,
      ``,
      `Composite: ${result.composite} | Divergence: ${result.divergence_flag ? 'YES ⚠️' : 'no'}`,
      `CBE Rate: ${inputs.cbe_rate}% (${inputs.cbe_rate_delta > 0 ? '+' : ''}${inputs.cbe_rate_delta}%)`,
      `Inflation: ${inputs.inflation}% (${inputs.inflation_delta > 0 ? '+' : ''}${inputs.inflation_delta}%)`,
      `Reserves: $${inputs.reserves}bn`,
      `Brent: $${inputs.brent_level?.toFixed(2)}`,
      `USD/EGP: ${liveData.usd_egp?.toFixed(4) || '--'}`,
      ``,
      `Next CBE meeting: ${this.knownInputs.next_cbe_meeting}`,
      `Mode: ${this.dryRun ? 'DRY RUN' : '⚠️ LIVE'}`
    ].join('\n'), result.state === 'CAUTION' ? 'error' : 'trade');
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  getStatus() {
    return {
      state:           this.state,
      runCount:        this.runCount,
      inputs:          this.inputs,
      knownInputs:     this.knownInputs,
      nextCbeMeeting:  this.knownInputs.next_cbe_meeting,
      isRunning:       this.isRunning
    };
  }

  // Manual input update — called via config or future Telegram command
  updateInput(key, value) {
    if (key in this.knownInputs) {
      const old = this.knownInputs[key];
      this.knownInputs[key] = value;
      console.log(`[EGP] ✏️  Manual input: ${key} ${old} → ${value}`);
      this.storage.logManualInput(key, value, `Manual update from ${old}`);
    }
  }
}

module.exports = CCEEGPEngine;

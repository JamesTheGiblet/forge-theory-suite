// src/forex-data-feed.js
'use strict';

const https = require('https');

class ForexDataFeed {
  constructor(config = {}) {
    this.pair      = config.forex?.pair     || 'EURUSD=X';
    this.period    = config.forex?.period   || '5d';
    this.interval  = config.forex?.interval || '1h';
    this._cache     = null;
    this._cacheTime = 0;
    this._cacheTTL  = 55 * 60 * 1000;
  }

  async getMarketData() {
    if (this._cache && (Date.now() - this._cacheTime) < this._cacheTTL) {
      return this._cache;
    }
    try {
      const raw  = await this._fetchYahoo();
      const data = this._parse(raw);
      this._cache     = data;
      this._cacheTime = Date.now();
      return data;
    } catch (err) {
      console.error('[FOREX] Data feed error:', err.message);
      if (this._cache) { console.warn('[FOREX] Using stale cache'); return { ...this._cache, stale: true }; }
      return this._neutralData();
    }
  }

  _fetchYahoo() {
    return new Promise((resolve, reject) => {
      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${this.pair}?range=${this.period}&interval=${this.interval}&includePrePost=false`;
      const req = https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' } }, (res) => {
        let body = '';
        res.on('data', chunk => body += chunk);
        res.on('end', () => {
          if (res.statusCode !== 200) return reject(new Error(`Yahoo returned ${res.statusCode}`));
          try { resolve(JSON.parse(body)); } catch (e) { reject(new Error('Parse failed')); }
        });
      });
      req.on('error', reject);
      req.setTimeout(10000, () => { req.destroy(); reject(new Error('Timeout')); });
    });
  }

  _parse(raw) {
    const result = raw?.chart?.result?.[0];
    if (!result) throw new Error('Unexpected response structure');
    const closes = (result.indicators?.quote?.[0]?.close || []).filter(c => c !== null && !isNaN(c));
    if (closes.length === 0) throw new Error('No valid closes');
    const currentPrice = closes[closes.length - 1];
    const now = new Date();
    return {
      pair:          this.pair,
      price:         +currentPrice.toFixed(5),
      closes:        closes.map(c => +c.toFixed(5)),
      hourUTC:       now.getUTCHours(),
      dayOfWeek:     now.getUTCDay(),
      timestamp:     now.toISOString(),
      barsAvailable: closes.length,
      stale:         false
    };
  }

  _neutralData() {
    const now = new Date();
    return { pair: this.pair, price: 1.0850, closes: [], hourUTC: now.getUTCHours(), dayOfWeek: now.getUTCDay(), timestamp: now.toISOString(), barsAvailable: 0, stale: true, error: true };
  }
}

module.exports = ForexDataFeed;

// src/cme-data-feed.js
// CCE Stocks Engine (CME) — Data Feed
// Yahoo Finance: SPY price, volume
// Alpha Vantage: VIX, market breadth

'use strict';

const https = require('https');

class CMEDataFeed {
  constructor(config = {}) {
    this.symbol     = config.cme?.symbol || 'SPY';
    this.apiKey     = process.env.ALPHA_VANTAGE_API_KEY || 'demo';
    this._cache     = null;
    this._cacheTime = 0;
    this._cacheTTL  = 4 * 60 * 60 * 1000; // 4 hours
  }

  async getMarketData() {
    if (this._cache && (Date.now() - this._cacheTime) < this._cacheTTL) {
      return this._cache;
    }

    try {
      // Fetch SPY from Yahoo Finance (free, no key needed)
      const spyData = await this._fetchYahoo(this.symbol);
      await this._delay(15000);

      // Fetch VIX from Yahoo Finance
      const vixData = await this._fetchYahoo('^VIX');
      await this._delay(15000);

      // Fetch market breadth from Alpha Vantage
      const breadthData = await this._fetchBreadth();

      const data = this._buildContext(spyData, vixData, breadthData);
      this._cache     = data;
      this._cacheTime = Date.now();
      return data;

    } catch (err) {
      console.error('[CME] Data feed error:', err.message);
      if (this._cache) {
        console.warn('[CME] Using stale cache');
        return { ...this._cache, stale: true };
      }
      return this._neutralData();
    }
  }

  // ============================================================================
  // FETCHERS
  // ============================================================================

  _fetchYahoo(symbol) {
    return new Promise((resolve, reject) => {
      const encoded = encodeURIComponent(symbol);
      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encoded}?range=6mo&interval=1d&includePrePost=false`;
      const req = https.get(url, {
        headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' }
      }, (res) => {
        let body = '';
        res.on('data', chunk => body += chunk);
        res.on('end', () => {
          if (res.statusCode !== 200) return reject(new Error(`Yahoo ${symbol} returned ${res.statusCode}`));
          try { resolve(JSON.parse(body)); } catch (e) { reject(new Error('Parse failed')); }
        });
      });
      req.on('error', reject);
      req.setTimeout(15000, () => { req.destroy(); reject(new Error('Timeout')); });
    });
  }

  _fetchBreadth() {
    // Use S&P 500 advance/decline via Alpha Vantage market status
    // Fallback: estimate breadth from SPY vs equal-weight RSP ratio
    const url = `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=RSP&apikey=${this.apiKey}`;
    return new Promise((resolve, reject) => {
      const req = https.get(url, {
        headers: { 'User-Agent': 'CCE-CME/1.0', 'Accept': 'application/json' }
      }, (res) => {
        let body = '';
        res.on('data', chunk => body += chunk);
        res.on('end', () => {
          try {
            const d = JSON.parse(body);
            resolve(d);
          } catch (e) { resolve(null); } // Non-fatal — breadth is supplementary
        });
      });
      req.on('error', () => resolve(null)); // Non-fatal
      req.setTimeout(15000, () => { req.destroy(); resolve(null); });
    });
  }

  // ============================================================================
  // CONTEXT BUILDER
  // ============================================================================

  _buildContext(spyRaw, vixRaw, breadthRaw) {
    // Parse SPY
    const spyResult = spyRaw?.chart?.result?.[0];
    if (!spyResult) throw new Error('No SPY data');

    const spyCloses  = (spyResult.indicators?.quote?.[0]?.close || []).filter(c => c !== null && !isNaN(c));
    const spyVolumes = (spyResult.indicators?.quote?.[0]?.volume || []).filter(v => v !== null && !isNaN(v));

    if (spyCloses.length < 50) throw new Error('Insufficient SPY history');

    const price   = +spyCloses[spyCloses.length - 1].toFixed(2);
    const volume  = spyVolumes[spyVolumes.length - 1] || 0;

    // SMAs
    const sma50  = this._sma(spyCloses, 50);
    const sma200 = this._sma(spyCloses, 200) || this._sma(spyCloses, spyCloses.length);
    const sma20  = this._sma(spyCloses, 20);

    // Volume average (20-day)
    const avgVolume20 = spyVolumes.length >= 20
      ? spyVolumes.slice(-20).reduce((a, b) => a + b, 0) / 20
      : volume;
    const volumeConfirming = volume > avgVolume20 * 1.1;

    // RSI
    const rsi = this._rsi(spyCloses, 14);

    // Momentum
    const price4wAgo  = spyCloses[spyCloses.length - 20] || spyCloses[0];
    const momentum4w  = +((price - price4wAgo) / price4wAgo * 100).toFixed(2);

    // Parse VIX
    const vixResult = vixRaw?.chart?.result?.[0];
    const vixCloses = vixResult
      ? (vixResult.indicators?.quote?.[0]?.close || []).filter(c => c !== null && !isNaN(c))
      : [];
    const vix     = vixCloses.length ? +vixCloses[vixCloses.length - 1].toFixed(2) : 20;
    const vixPrev = vixCloses.length > 1 ? +vixCloses[vixCloses.length - 2].toFixed(2) : vix;
    const vixRising = vix > vixPrev * 1.05;

    // Breadth estimate: SPY vs RSP ratio (cap-weight vs equal-weight)
    // If RSP outperforming, broad market participation (healthy)
    let breadthScore = 65; // Default neutral
    if (breadthRaw?.['Time Series (Daily)']) {
      const rspSeries = breadthRaw['Time Series (Daily)'];
      const rspEntries = Object.entries(rspSeries)
        .sort(([a], [b]) => new Date(a) - new Date(b))
        .slice(-20);
      const rspCloses = rspEntries.map(([, v]) => parseFloat(v['4. close']));
      const rspMom = rspCloses.length >= 20
        ? ((rspCloses[rspCloses.length - 1] - rspCloses[0]) / rspCloses[0]) * 100
        : 0;
      // If equal-weight RSP momentum positive, broad participation
      breadthScore = rspMom > 0 ? Math.min(85, 60 + rspMom * 2) : Math.max(35, 60 + rspMom * 2);
    }

    const now = new Date();

    return {
      symbol:           this.symbol,
      price,
      closes:           spyCloses,
      volume,
      avgVolume20,
      volumeConfirming,

      // Technical
      sma20,
      sma50,
      sma200,
      aboveSma20:       price > sma20,
      aboveSma50:       price > sma50,
      aboveSma200:      price > sma200,
      rsi,
      momentum4w,

      // VIX
      vix,
      vixRising,
      vixLow:           vix < 20,
      vixElevated:      vix >= 20 && vix < 30,
      vixHigh:          vix >= 30,

      // Breadth
      breadthScore,
      breadthHealthy:   breadthScore >= 60,

      // Golden/Death cross
      goldenCross:      sma50 > sma200,
      deathCross:       sma50 < sma200,

      // Meta
      timestamp:        now.toISOString(),
      dayOfWeek:        now.getUTCDay(),
      stale:            false,
      error:            false
    };
  }

  // ============================================================================
  // HELPERS
  // ============================================================================

  _sma(arr, period) {
    if (arr.length < period) return arr.length ? +(arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(2) : 0;
    return +(arr.slice(-period).reduce((a, b) => a + b, 0) / period).toFixed(2);
  }

  _rsi(closes, period = 14) {
    if (closes.length < period + 1) return 50;
    let gains = 0, losses = 0;
    for (let i = closes.length - period; i < closes.length; i++) {
      const diff = closes[i] - closes[i - 1];
      if (diff > 0) gains  += diff;
      else          losses -= diff;
    }
    const avgGain = gains  / period;
    const avgLoss = losses / period;
    if (avgLoss === 0) return 100;
    return +(100 - 100 / (1 + avgGain / avgLoss)).toFixed(2);
  }

  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  _neutralData() {
    return {
      symbol: this.symbol, price: 0, closes: [], volume: 0, avgVolume20: 0,
      volumeConfirming: false, sma20: 0, sma50: 0, sma200: 0,
      aboveSma20: false, aboveSma50: false, aboveSma200: false,
      rsi: 50, momentum4w: 0,
      vix: 20, vixRising: false, vixLow: true, vixElevated: false, vixHigh: false,
      breadthScore: 50, breadthHealthy: false,
      goldenCross: false, deathCross: false,
      timestamp: new Date().toISOString(), dayOfWeek: new Date().getUTCDay(),
      stale: true, error: true
    };
  }
}

module.exports = CMEDataFeed;

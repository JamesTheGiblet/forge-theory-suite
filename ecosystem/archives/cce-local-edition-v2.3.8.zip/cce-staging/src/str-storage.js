// src/str-storage.js
// O.E Strategist — sql.js persistence layer

'use strict';

const path = require('path');
const fs   = require('fs');

class STRStorageManager {
  constructor(dbPath) {
    const basePath = path.join(__dirname, '..');
    this.dbPath = dbPath
      ? dbPath.replace('cce-production.db', 'str-production.db')
      : path.join(basePath, 'data', 'str-production.db');
    this.db = null;
  }

  async init() {
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const initSqlJs = require('sql.js');
    const SQL = await initSqlJs();

    if (fs.existsSync(this.dbPath)) {
      const buf = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(buf);
    } else {
      this.db = new SQL.Database();
    }

    this._createTables();
    this._saveTimer = setInterval(() => this._persist(), 60000);
    console.log('[STR] Storage initialised (sql.js)');
  }

  _createTables() {
    this.db.run(`CREATE TABLE IF NOT EXISTS briefings (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp     DATETIME,
      trigger_type  TEXT,
      regime        TEXT,
      obs_count     INTEGER,
      content       TEXT
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS predictions (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp     DATETIME,
      engine        TEXT,
      current_state TEXT,
      prediction    TEXT,
      timeframe     TEXT,
      confidence    INTEGER,
      data_points   INTEGER
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS allocation_recs (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp       DATETIME,
      regime          TEXT,
      total_capital   REAL,
      alloc_crypto    REAL,
      alloc_forex     REAL,
      alloc_reit      REAL,
      alloc_stocks    REAL,
      alloc_como      REAL,
      alloc_grid      REAL,
      rationale       TEXT
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS anomalies (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp     DATETIME,
      type          TEXT,
      severity      TEXT,
      engine        TEXT,
      description   TEXT,
      value         REAL
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS queries (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp     DATETIME,
      query         TEXT,
      response      TEXT,
      source        TEXT
    )`);
  }

  _persist() {
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (err) {
      console.error('[STR] Persist error:', err.message);
    }
  }

  async logBriefing(triggerType, regime, obsCount, content) {
    this.db.run(
      `INSERT INTO briefings (timestamp, trigger_type, regime, obs_count, content)
       VALUES (?, ?, ?, ?, ?)`,
      [new Date().toISOString(), triggerType, regime, obsCount, content]
    );
    this._persist();
  }

  async logPredictions(predictions) {
    const ts = new Date().toISOString();
    Object.entries(predictions).forEach(([engine, pred]) => {
      this.db.run(
        `INSERT INTO predictions (timestamp, engine, current_state, prediction, timeframe, confidence, data_points)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [ts, engine, pred.currentState, pred.prediction, pred.timeframe, pred.confidence, pred.dataPoints]
      );
    });
    this._persist();
  }

  async logAllocationRec(data) {
    this.db.run(
      `INSERT INTO allocation_recs (
        timestamp, regime, total_capital,
        alloc_crypto, alloc_forex, alloc_reit,
        alloc_stocks, alloc_como, alloc_grid, rationale
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.regime, data.totalCapital,
        data.allocations.crypto, data.allocations.forex, data.allocations.reit,
        data.allocations.stocks, data.allocations.como, data.allocations.grid,
        data.rationale
      ]
    );
    this._persist();
  }

  async logAnomaly(anomaly) {
    this.db.run(
      `INSERT INTO anomalies (timestamp, type, severity, engine, description, value)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), anomaly.type, anomaly.severity,
        anomaly.engine, anomaly.description, anomaly.value
      ]
    );
    this._persist();
  }

  async logQuery(query, response, source) {
    this.db.run(
      `INSERT INTO queries (timestamp, query, response, source)
       VALUES (?, ?, ?, ?)`,
      [new Date().toISOString(), query, response, source]
    );
    this._persist();
  }

  async getLatestBriefing() {
    const r = this.db.exec('SELECT * FROM briefings ORDER BY timestamp DESC LIMIT 1');
    if (!r.length) return null;
    const { columns, values } = r[0];
    const obj = {};
    columns.forEach((c, i) => obj[c] = values[0][i]);
    return obj;
  }

  async getLatestPredictions() {
    const r = this.db.exec(
      `SELECT * FROM predictions WHERE timestamp = (SELECT MAX(timestamp) FROM predictions)`
    );
    if (!r.length) return [];
    const { columns, values } = r[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((c, i) => obj[c] = row[i]);
      return obj;
    });
  }

  async getRecentAnomalies(limit = 10) {
    const r = this.db.exec(
      `SELECT * FROM anomalies ORDER BY timestamp DESC LIMIT ${limit}`
    );
    if (!r.length) return [];
    const { columns, values } = r[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((c, i) => obj[c] = row[i]);
      return obj;
    });
  }

  async getRecentQueries(limit = 10) {
    const r = this.db.exec(
      `SELECT * FROM queries ORDER BY timestamp DESC LIMIT ${limit}`
    );
    if (!r.length) return [];
    const { columns, values } = r[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((c, i) => obj[c] = row[i]);
      return obj;
    });
  }

  async getLatestAllocationRec() {
    const r = this.db.exec('SELECT * FROM allocation_recs ORDER BY timestamp DESC LIMIT 1');
    if (!r.length) return null;
    const { columns, values } = r[0];
    const obj = {};
    columns.forEach((c, i) => obj[c] = values[0][i]);
    return obj;
  }

  close() {
    if (this._saveTimer) clearInterval(this._saveTimer);
    this._persist();
    this.db.close();
    console.log('[STR] Storage closed.');
  }
}

module.exports = STRStorageManager;

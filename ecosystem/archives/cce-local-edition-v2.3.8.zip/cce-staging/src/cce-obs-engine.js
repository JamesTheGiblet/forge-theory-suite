// src/cce-obs-engine.js
// O.E Observer — Passive Platform Intelligence Layer
//
// GOLDEN RULE: The Observer NEVER affects engine behaviour.
//              It ONLY reads state and market data.
//              It NEVER calls engine methods.
//              It NEVER writes to engine databases.
//
// The Observer watches everything, records everything, remembers everything.
// It builds the dataset that will eventually power the Strategist and G.O.

'use strict';

const OBSStorageManager = require('./obs-storage');
const OBSAnalytics      = require('./obs-strategy');

class CCEOBSEngine {
  constructor(config, notifier, engines) {
    this.config    = config;
    this.notifier  = notifier;
    this.engines   = engines; // read-only references
    this.storage   = new OBSStorageManager(config.database?.path);
    this.analytics = new OBSAnalytics();
    this.isRunning = false;
    this.obsCount  = 0;

    // Track previous states for transition detection
    this.prevStates = {
      crypto: null, forex: null, reit: null,
      stocks: null, como: null,  grid: null
    };

    // Pattern analysis interval (every 96 observations = ~24h at 15min)
    this.patternInterval = config.obs?.patternInterval || 96;
  }

  async start(intervalMinutes = 15) {
    this.isRunning = true;
    const intervalMs = intervalMinutes * 60 * 1000;

    await this.storage.init();

    // Load observation count from existing data
    this.obsCount = await this.storage.getObservationCount();

    console.log('\n[OBS] 👁️  Starting O.E Observer');
    console.log(`[OBS] ⏱️  Observation Interval: ${intervalMinutes}min`);
    console.log(`[OBS] 📊 Existing observations: ${this.obsCount}`);
    console.log(`[OBS] 🔍 Pattern analysis: every ${this.patternInterval} observations\n`);

    await this.notifier.send(
      `<b>[OBS] 👁️ Observer Started</b>\nInterval: ${intervalMinutes}min\nExisting observations: ${this.obsCount}\nEngines monitored: ${Object.keys(this.engines).length}\n\n<i>Passive observation only — no engine interference.</i>`,
      'info'
    );

    while (this.isRunning) {
      await this._observe();
      if (!this.isRunning) break;

      const nextRun = new Date(Date.now() + intervalMs);
      console.log(`[OBS] ⏳ Next observation: ${nextRun.toLocaleTimeString()}`);
      await this._sleep(intervalMs);
    }

    console.log('[OBS] 🛑 Observer stopped.');
  }

  stop() {
    console.log('[OBS] 🛑 Stopping Observer...');
    this.isRunning = false;
    this.storage.close();
  }

  // ============================================================================
  // MAIN OBSERVATION CYCLE
  // ============================================================================

  async _observe() {
    try {
      this.obsCount++;

      // 1. Read all engine states (read-only)
      const states    = this._readStates();
      const market    = this._readMarket();
      const gridData  = this._readGrid();
      const forexData = this._readForex();
      const rmeData   = this._readRME();
      const cmeData   = this._readCME();
      const comoData  = this._readCOMO();

      const activeCount  = this._countActive(states);
      const dormantCount = this._countDormant(states);

      console.log(`\n[OBS] 👁️  #${this.obsCount} | ${new Date().toLocaleTimeString()}`);
      console.log(`[OBS]    States: Crypto:${states.crypto} Forex:${states.forex} REIT:${states.reit}`);
      console.log(`[OBS]           Stocks:${states.stocks} COMO:${states.como} Grid:${states.grid}`);
      console.log(`[OBS]    Market: BTC $${market.btcPrice} | F&G ${market.fearGreed} | VIX ${cmeData.vix}`);

      // 2. Detect state transitions
      await this._detectTransitions(states, market, rmeData, cmeData, comoData, forexData);

      // 3. Log observation
      await this.storage.logObservation({
        obs_number:      this.obsCount,
        crypto_state:    states.crypto,
        forex_state:     states.forex,
        reit_state:      states.reit,
        stocks_state:    states.stocks,
        como_state:      states.como,
        grid_state:      states.grid,
        active_engines:  activeCount,
        dormant_engines: dormantCount,
        btc_price:       market.btcPrice,
        btc_dominance:   market.btcDominance,
        fear_greed:      market.fearGreed,
        crypto_portfolio: market.cryptoPortfolio,
        eur_usd:         forexData.eurUsd,
        forex_zscore:    forexData.zScore,
        forex_rsi:       forexData.rsi,
        fed_rate:        rmeData.fedRate,
        treasury_yield:  rmeData.treasuryYield,
        yield_spread:    rmeData.yieldSpread,
        reit_price:      rmeData.reitPrice,
        spy_price:       cmeData.spyPrice,
        vix:             cmeData.vix,
        spy_rsi:         cmeData.rsi,
        spy_sma50:       cmeData.sma50,
        spy_sma200:      cmeData.sma200,
        oil_price:       comoData.oilPrice,
        gold_price:      comoData.goldPrice,
        copper_price:    comoData.copperPrice,
        dxy_price:       comoData.dxyPrice,
        grid_centre:     gridData.centre,
        grid_profit:     gridData.profit,
        grid_cycles:     gridData.completedCycles,
        grid_open_buys:  gridData.openBuys,
        grid_open_sells: gridData.openSells
      });

      // 4. Run pattern analysis every N observations
      if (this.obsCount % this.patternInterval === 0) {
        await this._analysePatterns();
      }

      // 5. Daily summary at midnight
      const hour = new Date().getHours();
      const min  = new Date().getMinutes();
      if (hour === 0 && min < 15) {
        await this._dailySummary();
      }

      // Update previous states
      this.prevStates = { ...states };

    } catch (err) {
      console.error('[OBS] ❌ Observation error:', err.message);
    }
  }

  // ============================================================================
  // STATE READERS (READ ONLY — NEVER CALL ENGINE METHODS)
  // ============================================================================

  _readStates() {
    return {
      crypto: this.engines.crypto?.fsm?.currentState
           || this.engines.crypto?.currentState
           || 'UNKNOWN',
      forex:  this.engines.forex?.fsm?.currentState  || 'UNKNOWN',
      reit:   this.engines.rme?.fsm?.currentState    || 'UNKNOWN',
      stocks: this.engines.cme?.fsm?.currentState    || 'UNKNOWN',
      como:   this.engines.como?.fsm?.currentState   || 'UNKNOWN',
      grid:   this.engines.grid?.gridState            || 'UNKNOWN'
    };
  }

  _readMarket() {
    return {
      btcPrice:        this.engines.crypto?.lastBtcPrice    || 0,
      btcDominance:    this.engines.crypto?.lastDominance   || 0,
      fearGreed:       this.engines.crypto?.lastFearGreed   || 0,
      cryptoPortfolio: this.engines.crypto?.portfolioValue  || 0
    };
  }

  _readGrid() {
    return {
      centre:          this.engines.grid?.centrePrice     || 0,
      profit:          this.engines.grid?.totalProfit     || 0,
      completedCycles: this.engines.grid?.completedCycles || 0,
      openBuys:        this.engines.grid?.grid?.filter(l => l.side === 'buy'  && l.status === 'open').length || 0,
      openSells:       this.engines.grid?.grid?.filter(l => l.side === 'sell' && l.status === 'open').length || 0
    };
  }

  _readForex() {
    return {
      eurUsd: this.engines.forex?.lastEurUsd || 0,
      zScore: this.engines.forex?.lastZScore || 0,
      rsi:    this.engines.forex?.lastRsi    || 0
    };
  }

  _readRME() {
    return {
      fedRate:       this.engines.rme?.lastFedRate      || 0,
      treasuryYield: this.engines.rme?.lastTreasury     || 0,
      yieldSpread:   this.engines.rme?.lastSpread       || 0,
      reitPrice:     this.engines.rme?.lastPrice        || 0
    };
  }

  _readCME() {
    return {
      spyPrice: this.engines.cme?.lastPrice  || 0,
      vix:      this.engines.cme?.lastVix    || 0,
      rsi:      this.engines.cme?.lastRsi    || 0,
      sma50:    this.engines.cme?.lastSma50  || 0,
      sma200:   this.engines.cme?.lastSma200 || 0
    };
  }

  _readCOMO() {
    return {
      oilPrice:    this.engines.como?.lastOilPrice    || 0,
      goldPrice:   this.engines.como?.lastGoldPrice   || 0,
      copperPrice: this.engines.como?.lastCopperPrice || 0,
      dxyPrice:    this.engines.como?.lastDxyPrice    || 0
    };
  }

  _countActive(states) {
    const activeStates = [
      'ACCUMULATION', 'ANCHOR', 'IGNITION', 'CASCADE_1', 'CASCADE_2', 'SPILLWAY',
      'EXECUTE', 'EXTRACT', 'WATCHING', 'ENTERING', 'HOLDING',
      'PRIMED', 'ROTATING', 'CASCADING', 'ACTIVE', 'OBSERVE'
    ];
    return Object.values(states).filter(s => activeStates.includes(s)).length;
  }

  _countDormant(states) {
    return Object.values(states).filter(s => s === 'DORMANT').length;
  }

  // ============================================================================
  // TRANSITION DETECTION
  // ============================================================================

  async _detectTransitions(states, market, rme, cme, como, forex) {
    const engineMap = {
      crypto: states.crypto, forex: states.forex, reit: states.reit,
      stocks: states.stocks, como: states.como,   grid: states.grid
    };

    for (const [engine, state] of Object.entries(engineMap)) {
      const prev = this.prevStates[engine];
      if (prev && prev !== state && prev !== 'UNKNOWN' && state !== 'UNKNOWN') {
        console.log(`[OBS] 🔔 Transition detected: ${engine.toUpperCase()} ${prev} → ${state}`);

        await this.storage.logTransition({
          engine,
          from_state:     prev,
          to_state:       state,
          btc_price:      market.btcPrice,
          fear_greed:     market.fearGreed,
          vix:            cme.vix,
          fed_rate:       rme.fedRate,
          treasury_yield: rme.treasuryYield,
          oil_price:      como.oilPrice,
          dxy_price:      como.dxyPrice,
          eur_usd:        forex.eurUsd
        });

        await this.notifier.send([
          `<b>[OBS] 🔔 State Transition Recorded</b>`,
          ``,
          `Engine: ${engine.toUpperCase()}`,
          `${prev} → ${state}`,
          ``,
          `Market conditions at transition:`,
          `BTC: $${market.btcPrice?.toLocaleString() || '--'}`,
          `F&G: ${market.fearGreed || '--'}`,
          `VIX: ${cme.vix || '--'}`,
          ``,
          `<i>Recorded for pattern analysis.</i>`
        ].join('\n'), 'info');
      }
    }
  }

  // ============================================================================
  // PATTERN ANALYSIS
  // ============================================================================

  async _analysePatterns() {
    console.log(`\n[OBS] 🧠 Running pattern analysis (${this.obsCount} observations)...`);

    const observations = await this.storage.getObservations(this.obsCount);
    if (observations.length < 10) {
      console.log('[OBS] ⚠️  Not enough data for pattern analysis yet (need 10+)');
      return;
    }

    const durations   = this.analytics.analyseStateDurations(observations);
    const transitions = this.analytics.analyseTransitionConditions(observations);
    const correlation = this.analytics.analyseEngineCorrelation(observations);
    const regimes     = this.analytics.analyseMarketRegimes(observations);
    const insights    = this.analytics.generateInsights(durations, transitions, correlation);

    // Store patterns
    await this.storage.logPattern(
      'state_durations', 'all',
      `State duration analysis — ${observations.length} observations`,
      durations, observations.length
    );

    await this.storage.logPattern(
      'engine_correlation', 'all',
      `Engine co-activity correlation — ${observations.length} observations`,
      correlation, observations.length
    );

    await this.storage.logPattern(
      'market_regimes', 'all',
      `Market regime distribution — ${observations.length} observations`,
      regimes, observations.length
    );

    console.log(`[OBS] ✅ Pattern analysis complete — ${insights.length} insights generated`);

    // Send summary to Telegram every 7 days of data
    if (this.obsCount % (this.patternInterval * 7) === 0) {
      await this._sendPatternReport(insights, durations, correlation, regimes, observations.length);
    }
  }

  async _sendPatternReport(insights, durations, correlation, regimes, obsCount) {
    const topInsights = insights.slice(0, 5);

    await this.notifier.send([
      `<b>[OBS] 🧠 Pattern Analysis Report</b>`,
      `Observations: ${obsCount}`,
      ``,
      `<b>Top Insights:</b>`,
      ...topInsights.map(i => `• ${i.insight}`),
      ``,
      `<b>Market Regime Distribution:</b>`,
      `Extreme Fear: ${regimes.extreme_fear?.count || 0} obs`,
      `Fear: ${regimes.fear?.count || 0} obs`,
      `Neutral: ${regimes.neutral?.count || 0} obs`,
      `Greed: ${regimes.greed?.count || 0} obs`
    ].join('\n'), 'report');
  }

  async _dailySummary() {
    const today = new Date().toISOString().substring(0, 10);
    const observations = await this.storage.getObservations(96); // last 24h
    const transitions  = await this.storage.getTransitions(50);

    if (!observations.length) return;

    const todayObs    = observations.filter(o => o.timestamp?.startsWith(today));
    const todayTrans  = transitions.filter(t => t.timestamp?.startsWith(today));

    const avgFG  = todayObs.reduce((s, o) => s + (o.fear_greed || 0), 0) / (todayObs.length || 1);
    const avgBTC = todayObs.reduce((s, o) => s + (o.btc_price || 0), 0) / (todayObs.length || 1);
    const avgVIX = todayObs.reduce((s, o) => s + (o.vix || 0), 0) / (todayObs.length || 1);
    const activePct  = todayObs.filter(o => o.active_engines > 0).length / (todayObs.length || 1) * 100;
    const dormantPct = todayObs.filter(o => o.dormant_engines >= 5).length / (todayObs.length || 1) * 100;

    await this.storage.logDailySummary({
      date:           today,
      obs_count:      todayObs.length,
      transitions:    todayTrans.length,
      avg_fear_greed: +avgFG.toFixed(1),
      avg_btc_price:  +avgBTC.toFixed(2),
      avg_vix:        +avgVIX.toFixed(2),
      active_pct:     +activePct.toFixed(1),
      dormant_pct:    +dormantPct.toFixed(1),
      summary:        { todayObs: todayObs.length, todayTrans: todayTrans.length }
    });

    await this.notifier.send([
      `<b>[OBS] 📅 Daily Summary — ${today}</b>`,
      ``,
      `Observations: ${todayObs.length}`,
      `Transitions: ${todayTrans.length}`,
      ``,
      `Avg F&G: ${avgFG.toFixed(1)}`,
      `Avg BTC: $${Math.round(avgBTC).toLocaleString()}`,
      `Avg VIX: ${avgVIX.toFixed(2)}`,
      ``,
      `Active engine time: ${activePct.toFixed(1)}%`,
      `All dormant time: ${dormantPct.toFixed(1)}%`,
      ``,
      `Total observations to date: ${this.obsCount}`
    ].join('\n'), 'report');
  }

  async _enableStrategist() {
    try {
      const fs     = require('fs');
      const path   = require('path');
      const cfgPath = path.join(__dirname, '..', 'config.js');
      let cfg = fs.readFileSync(cfgPath, 'utf8');

      if (cfg.includes('enabled:         false,  // Enable after Observer')) {
        cfg = cfg.replace(
          'enabled:         false,  // Enable after Observer has 96+ observations (~24h)',
          'enabled:         true,   // Auto-enabled by Observer after 96 observations'
        );
        fs.writeFileSync(cfgPath, cfg);
        console.log('[OBS] ✅ Strategist auto-enabled in config.js');

        await this.notifier.send([
          '<b>[OBS] 🧠 Strategist Auto-Enabled</b>',
          '',
          'Observer has reached 96 observations.',
          'O.E Strategist is now enabled in config.',
          '',
          'Restart cce-bot to activate the Strategist:',
          '<code>pm2 restart cce-bot</code>',
          '',
          'Then use /help in Telegram to see available commands.'
        ].join('\n'), 'info');
      }
    } catch (err) {
      console.error('[OBS] ❌ Auto-enable Strategist failed:', err.message);
    }
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  getStatus() {
    return {
      obsCount:  this.obsCount,
      isRunning: this.isRunning,
      prevStates: this.prevStates
    };
  }
}

module.exports = CCEOBSEngine;

// src/data-feed.js
// Market data aggregation — prices, sentiment, dominance, historical OHLCV

'use strict';

const ccxt = require('ccxt');
const axios = require('axios');

// Safe defaults returned on total failure
const SAFE_DEFAULTS = {
  btc_price:        0,
  eth_price:        0,
  sol_price:        0,
  rndr_price:       0,
  fet_price:        0,
  fear_greed_index: { value: 50 },
  btc_dominance:    50,
  etf_flows_7d:     0,
  historical_prices: [],
  lunarcrush:       null
};

class MarketDataFeed {
  constructor(config) {
    this.config        = config || {};
    this.lunarCrushKey = this.config.apis?.lunarCrushKey;

    this.kraken = new ccxt.kraken({
      timeout: 10000  // 10s timeout on all CCXT calls
    });

    this._lunarCrush402Warned = false;
  }

  async getMarketData() {
    try {
      // -----------------------------------------------------------------------
      // 1. Fetch live tickers (BTC, ETH, SOL, RENDER/RNDR, FET)
      // Note: RNDR migrated to RENDER on Kraken — try both via fallback
      // -----------------------------------------------------------------------
      let tickers = {};
      try {
        tickers = await this.kraken.fetchTickers(['BTC/USD', 'ETH/USD', 'SOL/USD', 'RENDER/USD', 'FET/USD']);
      } catch (e) {
        console.warn('   ⚠️  Specific ticker fetch failed, falling back to fetchTickers()...');
        try {
          tickers = await this.kraken.fetchTickers();
        } catch (e2) {
          console.warn('   ⚠️  Fallback ticker fetch also failed:', e2.message);
        }
      }

      // -----------------------------------------------------------------------
      // 2. Fetch historical OHLCV for SMA calculations (last 200 daily candles)
      // -----------------------------------------------------------------------
      let historicalPrices = [];
      try {
        const ohlcv = await this.kraken.fetchOHLCV('BTC/USD', '1d', undefined, 200);
        historicalPrices = ohlcv.map(candle => candle[4]); // Close prices
      } catch (e) {
        console.warn('   ⚠️  Failed to fetch historical OHLCV:', e.message);
        // Signals that depend on SMA will degrade gracefully
      }

      // -----------------------------------------------------------------------
      // 3. Fear & Greed Index
      // -----------------------------------------------------------------------
      let fearGreed = { value: 50 }; // Default: neutral
      try {
        const fgUrl = this.config.apis?.fearGreed || 'https://api.alternative.me/fng/';
        const response = await axios.get(fgUrl, { timeout: 5000 });
        if (response.data?.data?.length > 0) {
          fearGreed = { value: parseInt(response.data.data[0].value) };
        }
      } catch (e) {
        console.warn('   ⚠️  Failed to fetch Fear & Greed Index, using default (50)');
      }

      // -----------------------------------------------------------------------
      // 4. LunarCrush Sentiment (optional)
      // API v4: Bearer token auth — NOT the v3 query param ?key= style
      // Endpoint: GET /api4/public/coins/BTC/v1
      // Requires Builder plan or above for /coins/ endpoint
      // -----------------------------------------------------------------------
      let lunarData = null;
      if (this.lunarCrushKey && !this._lunarCrush402Warned) {
        try {
          const response = await axios.get(
            'https://lunarcrush.com/api4/public/coins/BTC/v1',
            {
              headers: { Authorization: `Bearer ${this.lunarCrushKey}` },
              timeout: 5000
            }
          );
          if (response.data?.data) {
            const raw = response.data.data;
            lunarData = {
              galaxy_score: raw.galaxy_score,
              // v4 renamed dominance → market_dominance
              dominance: raw.market_dominance ?? raw.dominance ?? null
            };
            console.log(`   ℹ️  LunarCrush: Galaxy Score ${lunarData.galaxy_score}, Dominance ${lunarData.dominance}%`);
          }
        } catch (e) {
          const status = e.response?.status;
          const hint = status === 401 ? ' (Check API key — Bearer auth required for v4)'
                     : status === 402 ? ' (Builder plan required for /coins/ endpoint — remove LUNARCRUSH_API_KEY to silence this)'
                     : status === 404 ? ' (Endpoint not found — verify /api4/public/coins/BTC/v1)'
                     : '';
          if (status === 402) this._lunarCrush402Warned = true; // Suppress future 402 noise
          console.warn(`   ⚠️  LunarCrush fetch failed: ${e.message}${hint}`);
        }
      }

      // -----------------------------------------------------------------------
      // 5. BTC Dominance
      // Priority: LunarCrush v4 → CoinGecko → CoinPaprika → live price proxy
      // -----------------------------------------------------------------------
      let btcDominance = 55.0; // Default fallback

      if (lunarData?.dominance != null) {
        btcDominance = parseFloat(lunarData.dominance);
      } else {
        let dominanceFetched = false;

        // CoinGecko
        if (!dominanceFetched) {
          try {
            const cg = await axios.get('https://api.coingecko.com/api/v3/global', { timeout: 4000 });
            if (cg.data?.data?.market_cap_percentage?.btc) {
              btcDominance = cg.data.data.market_cap_percentage.btc;
              console.log(`   ℹ️  BTC Dominance (CoinGecko): ${btcDominance.toFixed(2)}%`);
              dominanceFetched = true;
            }
          } catch (e) {
            console.warn('   ⚠️  CoinGecko dominance fetch failed:', e.message);
          }
        }

        // CoinPaprika
        if (!dominanceFetched) {
          try {
            const cp = await axios.get('https://api.coinpaprika.com/v1/global', { timeout: 4000 });
            if (cp.data?.bitcoin_dominance_percentage) {
              btcDominance = cp.data.bitcoin_dominance_percentage;
              console.log(`   ℹ️  BTC Dominance (CoinPaprika): ${btcDominance.toFixed(2)}%`);
              dominanceFetched = true;
            }
          } catch (e) {
            console.warn('   ⚠️  CoinPaprika dominance fetch failed:', e.message);
          }
        }

        // Live price proxy (matches backtest formula: BTC / (BTC + ETH × 25))
        if (!dominanceFetched) {
          const btcLast = tickers['BTC/USD']?.last;
          const ethLast = tickers['ETH/USD']?.last;
          if (btcLast && ethLast) {
            btcDominance = (btcLast / (btcLast + ethLast * 25)) * 100;
            console.log(`   ℹ️  BTC Dominance (price proxy): ${btcDominance.toFixed(2)}%`);
          } else {
            console.warn('   ⚠️  All dominance sources failed. Using default (55.0%)');
          }
        }
      }

      // -----------------------------------------------------------------------
      // 6. ETF Flow Proxy (7-day price trend)
      // Real ETF flow data requires paid APIs. This uses 7-day BTC price change
      // as a directional proxy for net institutional inflows/outflows.
      //
      // Calibration: $1 price change ≈ $100k proxy flow impact.
      // A ~$5k 7-day drop at current prices ≈ -$500M (severe failure threshold).
      // Adjust multiplier if strategy thresholds are recalibrated.
      // -----------------------------------------------------------------------
      let etfFlowsProxy = 0;
      if (historicalPrices.length >= 7) {
        const price7dAgo   = historicalPrices[historicalPrices.length - 7];
        const currentPrice = tickers['BTC/USD']?.last || 0;
        etfFlowsProxy = (currentPrice - price7dAgo) * 100000;
      }

      // -----------------------------------------------------------------------
      // 7. Assemble and return
      // -----------------------------------------------------------------------
      return {
        btc_price:         tickers['BTC/USD']?.last    || 0,
        eth_price:         tickers['ETH/USD']?.last    || 0,
        sol_price:         tickers['SOL/USD']?.last    || 0,
        rndr_price:        tickers['RENDER/USD']?.last || tickers['RNDR/USD']?.last || 0,
        fet_price:         tickers['FET/USD']?.last    || 0,
        fear_greed_index:  fearGreed,
        lunarcrush:        lunarData,
        btc_dominance:     btcDominance,
        etf_flows_7d:      etfFlowsProxy,
        historical_prices: historicalPrices
      };

    } catch (error) {
      console.error('❌ Data Feed Error:', error.message);
      return { ...SAFE_DEFAULTS };
    }
  }
}

module.exports = MarketDataFeed;
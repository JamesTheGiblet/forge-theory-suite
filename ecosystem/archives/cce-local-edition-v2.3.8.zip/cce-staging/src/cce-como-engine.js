// src/cce-como-engine.js
// CCE Commodities Engine (COMO) — Multi-Commodity Cascade
// Thesis: Oil leads commodity rotation. Gold follows 1-2 weeks later.
//         Copper follows 2-3 weeks later. We ride each stage of the cascade.

'use strict';

const { COMOStateMachine, COMOSignals } = require('./como-strategy');
const COMODataFeed                       = require('./como-data-feed');
const COMOStorageManager                 = require('./como-storage');

class CCECOMOEngine {
  constructor(config, notifier) {
    this.config   = config;
    this.notifier = notifier;

    this.fsm      = new COMOStateMachine(config.como?.fsm || {});
    this.signals  = new COMOSignals();
    this.dataFeed = new COMODataFeed(config);
    this.storage  = new COMOStorageManager(config.database?.path);

    this.isRunning       = false;
    this.runCount        = 0;
    this.dryRun          = config.como?.dryRun !== false;
    this.startingCapital = config.como?.startingCapital || 300;
    this.portfolioValue  = this.startingCapital;
    this.lastReportValue = this.startingCapital;

    // Position tracking per commodity
    this.positions = {
      oil:    null,
      gold:   null,
      copper: null
    };
  }

  async start(intervalHours = 24) {
    this.isRunning = true;
    const intervalMs = intervalHours * 60 * 60 * 1000;

    await this.storage.init();

    console.log('\n[COMO] 🛢️  Starting CCE Commodities Engine (COMO)');
    console.log(`[COMO] ⏱️  Check Interval: ${intervalHours}h`);
    console.log(`[COMO] 💰 Starting Capital: £${this.startingCapital}`);
    console.log(`[COMO] 🔧 Mode: ${this.dryRun ? 'DRY RUN' : 'LIVE ⚠️'}`);
    console.log(`[COMO] 📍 Strategy: Multi-Commodity Cascade (Oil → Gold → Copper)\n`);

    await this.notifier.send(
      `<b>[COMO] 🛢️ CCE Commodities Engine Started</b>\nCapital: £${this.startingCapital}\nStrategy: Multi-Commodity Cascade\nMode: ${this.dryRun ? 'DRY RUN' : '⚠️ LIVE'}`,
      'info'
    );

    while (this.isRunning) {
      await this.runCycle();
      if (!this.isRunning) break;

      const nextRun = new Date(Date.now() + intervalMs);
      console.log(`[COMO] ⏳ Next run: ${nextRun.toLocaleString()}`);
      await this._sleep(intervalMs);
    }

    console.log('[COMO] 🛑 COMO engine loop exited.');
  }

  stop() {
    console.log('[COMO] 🛑 Stopping CCE Commodities Engine...');
    this.isRunning = false;
    this.storage.close();
  }

  async runCycle() {
    try {
      this.runCount++;
      console.log(`\n[COMO] ${'─'.repeat(60)}`);
      console.log(`[COMO] 🔄 RUN #${this.runCount} — ${new Date().toISOString()}`);
      console.log(`[COMO]    State: ${this.fsm.currentState} — ${this.fsm.getStateSummary()}`);
      console.log(`[COMO] ${'─'.repeat(60)}`);

      // 1. Fetch market data
      const market = await this.dataFeed.getMarketData();

      if (market.error) {
        console.warn('[COMO] ⚠️  Data feed error — skipping cycle');
        return;
      }

      // 2. Calculate signals
      const sig = this.signals.getAllSignals(market);

      console.log(`[COMO] 🛢️  WTI:    $${market.oilPrice} | Mom5d: ${market.oilMom5d.toFixed(1)}% | Mom20d: ${market.oilMom20d.toFixed(1)}%`);
      console.log(`[COMO] 🥇 Gold:   $${market.goldPrice} | Mom5d: ${market.goldMom5d.toFixed(1)}% | Following: ${market.goldFollowing ? '✅' : '❌'}`);
      console.log(`[COMO] 🔴 Copper: $${market.copperPrice} | Mom5d: ${market.copMom5d.toFixed(1)}% | Following: ${market.copperFollowing ? '✅' : '❌'}`);
      console.log(`[COMO] 💵 DXY:    ${market.dxyPrice.toFixed(2)} | Mom5d: ${market.dxyMom5d.toFixed(1)}% | ${market.dxyStrong ? '⚠️ Strong (blocks entry)' : '✅ Not blocking'}`);
      console.log(`[COMO] 📊 Oil/Gold Corr: ${market.oilGoldCorr}`);

      // 3. FSM context
      const context = {
        oilPrice:         market.oilPrice,
        oilMom5d:         market.oilMom5d,
        oilMom20d:        market.oilMom20d,
        oilAboveSma20:    market.oilAboveSma20,
        oilSma20:         market.oilSma20,
        oilBullish:       market.oilBullish,
        oilBearish:       market.oilBearish,
        oilTrending:      market.oilTrending,
        goldPrice:        market.goldPrice,
        goldMom5d:        market.goldMom5d,
        goldAboveSma20:   market.goldAboveSma20,
        goldFollowing:    market.goldFollowing,
        copperPrice:      market.copperPrice,
        copMom5d:         market.copMom5d,
        copperAboveSma20: market.copperAboveSma20,
        copperFollowing:  market.copperFollowing,
        dxyMom5d:         market.dxyMom5d,
        dxyStrong:        market.dxyStrong,
        dxyWeakening:     market.dxyWeakening,
        oilGoldCorr:      market.oilGoldCorr,
        signals:          sig
      };

      // 4. Evaluate FSM
      const transition = this.fsm.evaluateTransition(context);

      if (transition.transitioned) {
        console.log(`\n[COMO] 📝 STATE: ${transition.from} → ${transition.to}`);
        console.log(`[COMO]    Reason: ${transition.reason}`);
        await this._handleTransition(transition, market);
      } else {
        console.log(`[COMO] ✅ State: ${this.fsm.currentState} (no change)`);
        this._logActivePositions(market);
      }

      // 5. Log cycle
      const daysInState = this.fsm.getDaysInState();
      const totalReturn = ((this.portfolioValue - this.startingCapital) / this.startingCapital) * 100;
      const dailyReturn = ((this.portfolioValue - this.lastReportValue) / this.lastReportValue) * 100;

      await this.storage.logCycle({
        cycle_number:     this.runCount,
        state:            this.fsm.currentState,
        previous_state:   this.fsm.previousState,
        oil_price:        market.oilPrice,
        gold_price:       market.goldPrice,
        copper_price:     market.copperPrice,
        dxy_price:        market.dxyPrice,
        oil_mom_5d:       market.oilMom5d,
        oil_mom_20d:      market.oilMom20d,
        gold_mom_5d:      market.goldMom5d,
        copper_mom_5d:    market.copMom5d,
        dxy_mom_5d:       market.dxyMom5d,
        oil_above_sma20:  market.oilAboveSma20,
        gold_following:   market.goldFollowing,
        copper_following: market.copperFollowing,
        dxy_strong:       market.dxyStrong,
        oil_gold_corr:    market.oilGoldCorr,
        days_in_state:    daysInState,
        portfolio_value:  this.portfolioValue,
        daily_return:     dailyReturn,
        total_return:     totalReturn
      });

      // 6. Weekly report
      if (this.runCount > 0 && this.runCount % 7 === 0) {
        await this._weeklyReport(market);
      }

      console.log(`[COMO] ${'─'.repeat(60)}\n`);

    } catch (err) {
      console.error('[COMO] ❌ Cycle error:', err.message);
      await this.notifier.send(
        `<b>[COMO] ⚠️ Cycle Error</b>\n${err.message}`,
        'error'
      );
    }
  }

  // ============================================================================
  // TRANSITION HANDLERS
  // ============================================================================

  async _handleTransition(transition, market) {
    const { from, to, reason } = transition;

    switch (to) {

      case 'WATCHING': {
        const dir = market.oilBullish ? '📈 BULLISH' : '📉 BEARISH';
        await this.notifier.send([
          `<b>[COMO] 👀 WATCHING — Oil Moving</b>`,
          ``,
          `<b>WTI:</b> $${market.oilPrice} (${dir})`,
          `<b>5d momentum:</b> ${market.oilMom5d.toFixed(1)}%`,
          `<b>DXY:</b> ${market.dxyPrice.toFixed(2)} (${market.dxyStrong ? '⚠️ Strong' : '✅ OK'})`,
          ``,
          `Monitoring for cascade confirmation.`,
          `Reason: ${reason}`
        ].join('\n'), 'info');
        break;
      }

      case 'ROTATING': {
        // Signal oil entry
        this.positions.oil = { price: market.oilPrice, date: new Date() };

        await this.notifier.send([
          `<b>[COMO] 🛢️ ROTATING — Enter Oil Position</b>`,
          ``,
          `<b>Action:</b> BUY WTI/Oil ETF (USO or similar)`,
          `<b>Entry:</b> $${market.oilPrice}`,
          `<b>Oil 5d:</b> ${market.oilMom5d.toFixed(1)}%`,
          `<b>Oil 20d:</b> ${market.oilMom20d.toFixed(1)}%`,
          ``,
          `Gold lag window now open (1-14 days).`,
          `Watch for gold to confirm rotation.`,
          ``,
          `${this.dryRun ? '🔵 DRY RUN' : '⚠️ Place oil trade NOW'}`
        ].join('\n'), 'trade');

        await this.storage.logTrade({
          action: 'BUY', commodity: 'WTI', price: market.oilPrice,
          portfolio_value: this.portfolioValue, oil_price: market.oilPrice,
          gold_price: market.goldPrice, copper_price: market.copperPrice,
          dxy_price: market.dxyPrice, reason
        });
        break;
      }

      case 'CASCADING': {
        // Signal gold entry
        this.positions.gold = { price: market.goldPrice, date: new Date() };

        await this.notifier.send([
          `<b>[COMO] 🥇 CASCADING — Enter Gold Position</b>`,
          ``,
          `<b>Action:</b> BUY Gold ETF (GLD or similar)`,
          `<b>Entry:</b> $${market.goldPrice}`,
          `<b>Gold 5d:</b> +${market.goldMom5d.toFixed(1)}%`,
          `<b>WTI still:</b> $${market.oilPrice}`,
          ``,
          `Copper lag window now open (2-21 days).`,
          `Watch for copper to confirm.`,
          ``,
          `${this.dryRun ? '🔵 DRY RUN' : '⚠️ Place gold trade NOW'}`
        ].join('\n'), 'trade');

        await this.storage.logTrade({
          action: 'BUY', commodity: 'GOLD', price: market.goldPrice,
          portfolio_value: this.portfolioValue, oil_price: market.oilPrice,
          gold_price: market.goldPrice, copper_price: market.copperPrice,
          dxy_price: market.dxyPrice, reason
        });
        break;
      }

      case 'HOLDING': {
        // Signal copper entry if we came from CASCADING with copper confirmed
        if (from === 'CASCADING' && market.copperFollowing) {
          this.positions.copper = { price: market.copperPrice, date: new Date() };

          await this.notifier.send([
            `<b>[COMO] 🔴 HOLDING — Full Cascade Confirmed</b>`,
            ``,
            `<b>Action:</b> BUY Copper ETF (CPER or similar)`,
            `<b>Entry:</b> $${market.copperPrice}`,
            ``,
            `Full position now active:`,
            `🛢️  WTI @ $${this.positions.oil?.price?.toFixed(2) || market.oilPrice}`,
            `🥇 Gold @ $${this.positions.gold?.price?.toFixed(2) || market.goldPrice}`,
            `🔴 Copper @ $${market.copperPrice}`,
            ``,
            `${this.dryRun ? '🔵 DRY RUN' : '⚠️ Place copper trade NOW'}`
          ].join('\n'), 'trade');

          await this.storage.logTrade({
            action: 'BUY', commodity: 'COPPER', price: market.copperPrice,
            portfolio_value: this.portfolioValue, oil_price: market.oilPrice,
            gold_price: market.goldPrice, copper_price: market.copperPrice,
            dxy_price: market.dxyPrice, reason
          });
        } else {
          await this.notifier.send(
            `<b>[COMO] ⏳ HOLDING — Oil + Gold Position Active</b>\nCopper window expired — holding oil + gold.\nWTI: $${market.oilPrice} | Gold: $${market.goldPrice}`,
            'info'
          );
        }
        break;
      }

      case 'EXITING': {
        // Calculate returns and exit all positions
        const exits = [];

        if (this.positions.oil) {
          const ret = ((market.oilPrice - this.positions.oil.price) / this.positions.oil.price * 100);
          exits.push({ name: 'WTI', entry: this.positions.oil.price, exit: market.oilPrice, ret });
          await this.storage.logTrade({
            action: 'SELL', commodity: 'WTI', price: market.oilPrice,
            portfolio_value: this.portfolioValue, oil_price: market.oilPrice,
            gold_price: market.goldPrice, copper_price: market.copperPrice,
            dxy_price: market.dxyPrice, return_pct: ret, reason,
            outcome: ret > 0 ? 'win' : 'loss'
          });
        }
        if (this.positions.gold) {
          const ret = ((market.goldPrice - this.positions.gold.price) / this.positions.gold.price * 100);
          exits.push({ name: 'Gold', entry: this.positions.gold.price, exit: market.goldPrice, ret });
          await this.storage.logTrade({
            action: 'SELL', commodity: 'GOLD', price: market.goldPrice,
            portfolio_value: this.portfolioValue, oil_price: market.oilPrice,
            gold_price: market.goldPrice, copper_price: market.copperPrice,
            dxy_price: market.dxyPrice, return_pct: ret, reason,
            outcome: ret > 0 ? 'win' : 'loss'
          });
        }
        if (this.positions.copper) {
          const ret = ((market.copperPrice - this.positions.copper.price) / this.positions.copper.price * 100);
          exits.push({ name: 'Copper', entry: this.positions.copper.price, exit: market.copperPrice, ret });
          await this.storage.logTrade({
            action: 'SELL', commodity: 'COPPER', price: market.copperPrice,
            portfolio_value: this.portfolioValue, oil_price: market.oilPrice,
            gold_price: market.goldPrice, copper_price: market.copperPrice,
            dxy_price: market.dxyPrice, return_pct: ret, reason,
            outcome: ret > 0 ? 'win' : 'loss'
          });
        }

        // Average return across positions
        const avgRet = exits.length
          ? exits.reduce((s, e) => s + e.ret, 0) / exits.length
          : 0;

        this.portfolioValue = this.portfolioValue * (1 + avgRet / 100);
        const totalReturn   = ((this.portfolioValue - this.startingCapital) / this.startingCapital) * 100;

        const exitLines = exits.map(e =>
          `${e.ret > 0 ? '✅' : '❌'} ${e.name}: $${e.entry.toFixed(2)} → $${e.exit.toFixed(2)} (${e.ret >= 0 ? '+' : ''}${e.ret.toFixed(2)}%)`
        );

        await this.notifier.send([
          `<b>[COMO] 🚪 EXITING — Closing All Positions</b>`,
          ``,
          ...exitLines,
          ``,
          `Avg Return: ${avgRet >= 0 ? '+' : ''}${avgRet.toFixed(2)}%`,
          `Portfolio: £${this.portfolioValue.toFixed(2)}`,
          `Total Return: ${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(2)}%`,
          ``,
          `${this.dryRun ? '🔵 DRY RUN' : '⚠️ Close ALL commodity positions NOW'}`,
          `Reason: ${reason}`
        ].join('\n'), avgRet > 0 ? 'trade' : 'warning');

        // Reset positions
        this.positions = { oil: null, gold: null, copper: null };
        break;
      }

      case 'DORMANT': {
        if (from !== 'DORMANT') {
          await this.notifier.send(
            `<b>[COMO] 😴 Returning to DORMANT</b>\nReason: ${reason}\nWTI: $${market.oilPrice} | DXY: ${market.dxyPrice.toFixed(2)}`,
            'info'
          );
        }
        break;
      }
    }
  }

  _logActivePositions(market) {
    const active = Object.entries(this.positions).filter(([, v]) => v !== null);
    if (!active.length) return;

    active.forEach(([name, pos]) => {
      const prices = { oil: market.oilPrice, gold: market.goldPrice, copper: market.copperPrice };
      const current = prices[name];
      if (!current || !pos) return;
      const unrealised = ((current - pos.price) / pos.price * 100).toFixed(2);
      console.log(`[COMO]    Position: LONG ${name.toUpperCase()} @ $${pos.price.toFixed(2)} | Unrealised: ${unrealised}%`);
    });
  }

  // ============================================================================
  // REPORTING
  // ============================================================================

  async _weeklyReport(market) {
    const totalReturn  = ((this.portfolioValue - this.startingCapital) / this.startingCapital) * 100;
    const periodReturn = ((this.portfolioValue - this.lastReportValue) / this.lastReportValue) * 100;

    await this.notifier.send([
      `<b>[COMO] 📊 Weekly Report</b>`,
      ``,
      `Portfolio: £${this.portfolioValue.toFixed(2)}`,
      `Week: ${periodReturn >= 0 ? '+' : ''}${periodReturn.toFixed(2)}%`,
      `Total: ${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(2)}%`,
      ``,
      `🛢️  WTI: $${market.oilPrice} (${market.oilMom5d.toFixed(1)}% 5d)`,
      `🥇 Gold: $${market.goldPrice} (${market.goldMom5d.toFixed(1)}% 5d)`,
      `🔴 Copper: $${market.copperPrice} (${market.copMom5d.toFixed(1)}% 5d)`,
      `💵 DXY: ${market.dxyPrice.toFixed(2)}`,
      `State: ${this.fsm.currentState}`,
      `Cycles: ${this.runCount}`
    ].join('\n'), 'report');

    this.lastReportValue = this.portfolioValue;
    await this.storage.saveSnapshot(this.portfolioValue, this.fsm.currentState, market.oilPrice, totalReturn);
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = CCECOMOEngine;

// src/rme-storage.js
// CCE REIT Engine (RME) — sql.js persistence layer
// Mirrors forex-storage.js pattern exactly.

'use strict';

const path = require('path');
const fs   = require('fs');

class RMEStorageManager {
  constructor(dbPath) {
    const basePath = path.join(__dirname, '..');
    this.dbPath = dbPath
      ? dbPath.replace('cce-production.db', 'rme-production.db')
      : path.join(basePath, 'data', 'rme-production.db');
    this.db = null;
  }

  async init() {
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const initSqlJs = require('sql.js');
    const SQL = await initSqlJs();

    if (fs.existsSync(this.dbPath)) {
      const buf = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(buf);
    } else {
      this.db = new SQL.Database();
    }

    this._createTables();
    this._saveTimer = setInterval(() => this._persist(), 60000);
    console.log('[RME] Storage initialised (sql.js)');
  }

  _createTables() {
    this.db.run(`CREATE TABLE IF NOT EXISTS rme_cycles (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp        DATETIME,
      cycle_number     INTEGER,
      state            TEXT,
      previous_state   TEXT,
      price            REAL,
      fed_rate         REAL,
      treasury_yield   REAL,
      yield_spread     REAL,
      momentum_4w      REAL,
      rsi              REAL,
      days_in_state    REAL,
      portfolio_value  REAL,
      daily_return     REAL,
      total_return     REAL,
      fed_cutting      INTEGER,
      fed_easing       INTEGER,
      spread_favourable INTEGER
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS rme_trades (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp        DATETIME,
      action           TEXT,
      symbol           TEXT,
      price            REAL,
      portfolio_value  REAL,
      fed_rate         REAL,
      treasury_yield   REAL,
      yield_spread     REAL,
      days_since_decision INTEGER,
      reason           TEXT,
      outcome          TEXT
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS rme_snapshots (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp        DATETIME,
      state            TEXT,
      portfolio_value  REAL,
      price            REAL,
      total_return     REAL
    )`);
  }

  _persist() {
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (err) {
      console.error('[RME] Persist error:', err.message);
    }
  }

  async logCycle(data) {
    this.db.run(
      `INSERT INTO rme_cycles (
        timestamp, cycle_number, state, previous_state, price,
        fed_rate, treasury_yield, yield_spread, momentum_4w, rsi,
        days_in_state, portfolio_value, daily_return, total_return,
        fed_cutting, fed_easing, spread_favourable
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.cycle_number, data.state, data.previous_state,
        data.price, data.fed_rate, data.treasury_yield, data.yield_spread,
        data.momentum_4w, data.rsi, data.days_in_state, data.portfolio_value,
        data.daily_return, data.total_return,
        data.fed_cutting ? 1 : 0, data.fed_easing ? 1 : 0,
        data.spread_favourable ? 1 : 0
      ]
    );
    this._persist();
  }

  async logTrade(data) {
    this.db.run(
      `INSERT INTO rme_trades (
        timestamp, action, symbol, price, portfolio_value,
        fed_rate, treasury_yield, yield_spread,
        days_since_decision, reason, outcome
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.action, data.symbol, data.price,
        data.portfolio_value, data.fed_rate, data.treasury_yield,
        data.yield_spread, data.days_since_decision, data.reason, data.outcome || ''
      ]
    );
    this._persist();
  }

  async saveSnapshot(portfolioValue, state, price, totalReturn) {
    this.db.run(
      `INSERT INTO rme_snapshots (timestamp, state, portfolio_value, price, total_return)
       VALUES (?, ?, ?, ?, ?)`,
      [new Date().toISOString(), state, portfolioValue, price, totalReturn]
    );
    this._persist();
  }

  async getLatestCycle() {
    const result = this.db.exec('SELECT * FROM rme_cycles ORDER BY timestamp DESC LIMIT 1');
    if (!result.length) return null;
    const { columns, values } = result[0];
    const obj = {};
    columns.forEach((col, i) => obj[col] = values[0][i]);
    return obj;
  }

  async getTradeHistory(limit = 20) {
    const result = this.db.exec(
      `SELECT * FROM rme_trades ORDER BY timestamp DESC LIMIT ${limit}`
    );
    if (!result.length) return [];
    const { columns, values } = result[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  }

  close() {
    if (this._saveTimer) clearInterval(this._saveTimer);
    this._persist();
    this.db.close();
    console.log('[RME] Storage closed.');
  }
}

module.exports = RMEStorageManager;

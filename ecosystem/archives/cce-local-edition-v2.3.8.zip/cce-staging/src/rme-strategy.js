// src/rme-strategy.js
// CCE REIT Engine (RME) — 5-State FSM
// Thesis: REITs follow Fed rate cuts with a measurable 2-6 week lag.
// We exploit the lag window between the rate decision and full capital rotation.
//
// States:
//   DORMANT   — No edge. Rates stable or rising. 100% cash.
//   WATCHING  — Rate cut detected. Monitoring for lag confirmation.
//   ENTERING  — Lag confirmed. Deploy capital into REIT position.
//   HOLDING   — In position. Trailing yield spread and momentum.
//   EXITING   — Spread compressing or momentum fading. Rotate out.

'use strict';

class RMEStateMachine {
  constructor(config = {}) {
    this.currentState  = 'DORMANT';
    this.previousState = 'DORMANT';
    this.stateEnteredAt = Date.now();

    // Configurable thresholds
    this.minWatchDays     = config.minWatchDays     || 7;   // Min days in WATCHING before ENTERING
    this.maxWatchDays     = config.maxWatchDays     || 42;  // Give up if no confirmation in 6 weeks
    this.minHoldDays      = config.minHoldDays      || 14;  // Min hold before exit scan
    this.maxHoldDays      = config.maxHoldDays      || 90;  // Force exit after 90 days
    this.minSpread        = config.minSpread        || 0.5; // Min yield spread to enter (%)
    this.exitSpread       = config.exitSpread       || 0.2; // Exit when spread compresses below (%)
    this.momentumExit     = config.momentumExit     || -3;  // Exit if 4w momentum < -3%
  }

  getDaysInState() {
    return (Date.now() - this.stateEnteredAt) / 86400000;
  }

  getStateSummary() {
    const summaries = {
      DORMANT:  'Rates stable/rising — holding cash',
      WATCHING: 'Rate cut detected — awaiting lag confirmation',
      ENTERING: 'Lag confirmed — deploying into REITs',
      HOLDING:  'In position — trailing spread and momentum',
      EXITING:  'Rotating out — spread compressing'
    };
    return summaries[this.currentState] || this.currentState;
  }

  evaluateTransition(context) {
    const from = this.currentState;
    let to = null;
    let reason = '';

    switch (this.currentState) {

      case 'DORMANT':
        // Wake up when Fed starts cutting
        if (context.fedCutting || context.fedEasing) {
          to     = 'WATCHING';
          reason = `Fed cutting — rate ${context.fedRate}%, trend ${context.fedTrend6m.toFixed(2)}% over 6m`;
        }
        break;

      case 'WATCHING': {
        const daysWatching = this.getDaysInState();

        // Timeout — no confirmation, go back to sleep
        if (daysWatching > this.maxWatchDays) {
          to     = 'DORMANT';
          reason = `No lag confirmation after ${Math.round(daysWatching)} days — aborting`;
          break;
        }

        // Return to DORMANT if Fed reverses (hiking again)
        if (context.fedHiking) {
          to     = 'DORMANT';
          reason = 'Fed reversed to hiking — abandoning watch';
          break;
        }

        // Lag confirmation: REIT price rising, Treasury yield falling, spread favourable
        const lagConfirmed = (
          daysWatching >= this.minWatchDays &&
          context.aboveSma20 &&
          context.spreadFavourable &&
          context.treasuryFalling &&
          context.momentum4w > 0
        );

        if (lagConfirmed) {
          to     = 'ENTERING';
          reason = `Lag confirmed after ${Math.round(daysWatching)}d — spread ${context.yieldSpread.toFixed(2)}%, momentum +${context.momentum4w.toFixed(1)}%`;
        }
        break;
      }

      case 'ENTERING':
        // Move straight to HOLDING after signalling entry
        to     = 'HOLDING';
        reason = 'Entry executed — monitoring position';
        break;

      case 'HOLDING': {
        const daysHeld = this.getDaysInState();

        // Force exit after max hold days
        if (daysHeld > this.maxHoldDays) {
          to     = 'EXITING';
          reason = `Max hold period reached (${Math.round(daysHeld)} days)`;
          break;
        }

        // Minimum hold period — don't exit too early
        if (daysHeld < this.minHoldDays) break;

        // Exit conditions
        if (context.yieldSpread < this.exitSpread) {
          to     = 'EXITING';
          reason = `Yield spread compressed to ${context.yieldSpread.toFixed(2)}% (below ${this.exitSpread}% threshold)`;
          break;
        }

        if (context.momentum4w < this.momentumExit) {
          to     = 'EXITING';
          reason = `Momentum fading: ${context.momentum4w.toFixed(1)}% over 4 weeks`;
          break;
        }

        if (context.fedHiking || context.treasuryRising) {
          to     = 'EXITING';
          reason = 'Rate environment reversing — rotating out';
          break;
        }

        // SMA breakdown — structural failure
        if (!context.aboveSma50) {
          to     = 'EXITING';
          reason = `Price broke below SMA50 (${context.sma50}) — structural failure`;
        }
        break;
      }

      case 'EXITING':
        // Move to DORMANT after exit — re-evaluate for next cycle
        if (context.fedCutting || context.fedEasing) {
          to     = 'WATCHING';
          reason = 'Exited position — Fed still cutting, re-entering watch';
        } else {
          to     = 'DORMANT';
          reason = 'Exited position — returning to cash';
        }
        break;
    }

    if (to && to !== from) {
      this.previousState  = from;
      this.currentState   = to;
      this.stateEnteredAt = Date.now();
      return { transitioned: true, from, to, reason };
    }

    return { transitioned: false, from, to: from, reason: '' };
  }
}

class RMESignals {
  // Additional signal calculations beyond what the data feed provides

  getRSI(closes, period = 14) {
    if (closes.length < period + 1) return 50;
    let gains = 0, losses = 0;
    for (let i = closes.length - period; i < closes.length; i++) {
      const diff = closes[i] - closes[i - 1];
      if (diff > 0) gains  += diff;
      else          losses -= diff;
    }
    const avgGain = gains  / period;
    const avgLoss = losses / period;
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return +(100 - 100 / (1 + rs)).toFixed(2);
  }

  getDrawdownFromPeak(closes) {
    if (!closes.length) return 0;
    const peak    = Math.max(...closes);
    const current = closes[closes.length - 1];
    return +((current - peak) / peak * 100).toFixed(2);
  }

  getAllSignals(market) {
    return {
      rsi:             this.getRSI(market.closes),
      drawdownFromPeak: this.getDrawdownFromPeak(market.closes),
      aboveSma20:      market.aboveSma20,
      aboveSma50:      market.aboveSma50,
      momentum4w:      market.momentum4w,
      spreadFavourable: market.spreadFavourable,
      yieldSpread:     market.yieldSpread,
      treasuryFalling: market.treasuryFalling,
      fedEasing:       market.fedEasing,
      daysSinceDecision: market.daysSinceDecision
    };
  }
}

module.exports = { RMEStateMachine, RMESignals };

// src/forex-storage.js
'use strict';

class ForexStorageManager {
  constructor(dbPath) {
    this.dbPath = dbPath || './data/cce-production.db';
    this.db     = null;
    this._sqljs = false;
  }

  async init() {
    try {
      const Database = require('better-sqlite3');
      this.db = new Database(this.dbPath);
      this.db.pragma('journal_mode = WAL');
      this._createTables();
      console.log('[FOREX] Storage initialised (better-sqlite3)');
    } catch (e) {
      try {
        const initSqlJs = require('sql.js');
        const fs = require('fs');
        const SQL = await initSqlJs();
        if (fs.existsSync(this.dbPath)) {
          this.db = new SQL.Database(fs.readFileSync(this.dbPath));
        } else {
          this.db = new SQL.Database();
        }
        this._sqljs  = true;
        this._dbPath = this.dbPath;
        this._createTables();
        console.log('[FOREX] Storage initialised (sql.js)');
      } catch (e2) {
        console.warn('[FOREX] Storage unavailable:', e2.message);
        this.db = null;
      }
    }
  }

  _createTables() {
    const tables = [
      `CREATE TABLE IF NOT EXISTS forex_cycles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT, cycle_number INTEGER, state TEXT, previous_state TEXT,
        price REAL, z_score REAL, rsi REAL, atr REAL, session TEXT,
        portfolio_value REAL, daily_return REAL, total_return REAL, has_position INTEGER DEFAULT 0
      )`,
      `CREATE TABLE IF NOT EXISTS forex_trades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT, direction TEXT, entry_price REAL, stop_loss REAL,
        target REAL, exit_price REAL, stop_pips REAL, target_pips REAL,
        result_pips REAL, result_pct REAL, outcome TEXT,
        partial_close INTEGER DEFAULT 0, hold_hours REAL, reason TEXT
      )`,
      `CREATE TABLE IF NOT EXISTS forex_snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT, portfolio_value REAL, state TEXT, price REAL
      )`
    ];
    tables.forEach(sql => this._run(sql));
  }

  async logCycle(data) {
    this._run(
      `INSERT INTO forex_cycles (timestamp,cycle_number,state,previous_state,price,z_score,rsi,atr,session,portfolio_value,daily_return,total_return,has_position) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [new Date().toISOString(), data.cycle_number||0, data.state||'', data.previous_state||null, data.price||0, data.z_score||0, data.rsi||0, data.atr||0, data.session||'', data.portfolio_value||0, data.daily_return||0, data.total_return||0, data.has_position?1:0]
    );
  }

  async logTrade(data) {
    this._run(
      `INSERT INTO forex_trades (timestamp,direction,entry_price,stop_loss,target,exit_price,stop_pips,target_pips,result_pips,result_pct,outcome,partial_close,hold_hours,reason) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [new Date().toISOString(), data.direction||'BUY', data.entry_price||0, data.stop_loss||0, data.target||0, data.exit_price||0, data.stop_pips||0, data.target_pips||0, data.result_pips||0, data.result_pct||0, data.outcome||'unknown', data.partial_close?1:0, data.hold_hours||0, data.reason||'']
    );
  }

  async saveSnapshot(portfolioValue, state, price) {
    this._run(
      `INSERT INTO forex_snapshots (timestamp,portfolio_value,state,price) VALUES (?,?,?,?)`,
      [new Date().toISOString(), portfolioValue, state, price]
    );
  }

  _run(sql, params = []) {
    if (!this.db) return;
    try {
      if (this._sqljs) {
        this.db.run(sql, params);
        const fs = require('fs');
        fs.writeFileSync(this._dbPath, Buffer.from(this.db.export()));
      } else {
        params.length ? this.db.prepare(sql).run(...params) : this.db.exec(sql);
      }
    } catch (e) {
      console.error('[FOREX] Storage write error:', e.message);
    }
  }
}

module.exports = ForexStorageManager;

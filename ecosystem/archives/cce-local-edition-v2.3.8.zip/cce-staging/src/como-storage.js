// src/como-storage.js
// CCE Commodities Engine (COMO) — sql.js persistence layer

'use strict';

const path = require('path');
const fs   = require('fs');

class COMOStorageManager {
  constructor(dbPath) {
    const basePath = path.join(__dirname, '..');
    this.dbPath = dbPath
      ? dbPath.replace('cce-production.db', 'como-production.db')
      : path.join(basePath, 'data', 'como-production.db');
    this.db = null;
  }

  async init() {
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const initSqlJs = require('sql.js');
    const SQL = await initSqlJs();

    if (fs.existsSync(this.dbPath)) {
      const buf = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(buf);
    } else {
      this.db = new SQL.Database();
    }

    this._createTables();
    this._saveTimer = setInterval(() => this._persist(), 60000);
    console.log('[COMO] Storage initialised (sql.js)');
  }

  _createTables() {
    this.db.run(`CREATE TABLE IF NOT EXISTS como_cycles (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp        DATETIME,
      cycle_number     INTEGER,
      state            TEXT,
      previous_state   TEXT,
      oil_price        REAL,
      gold_price       REAL,
      copper_price     REAL,
      dxy_price        REAL,
      oil_mom_5d       REAL,
      oil_mom_20d      REAL,
      gold_mom_5d      REAL,
      copper_mom_5d    REAL,
      dxy_mom_5d       REAL,
      oil_above_sma20  INTEGER,
      gold_following   INTEGER,
      copper_following INTEGER,
      dxy_strong       INTEGER,
      oil_gold_corr    REAL,
      days_in_state    REAL,
      portfolio_value  REAL,
      daily_return     REAL,
      total_return     REAL
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS como_trades (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp        DATETIME,
      action           TEXT,
      commodity        TEXT,
      price            REAL,
      portfolio_value  REAL,
      oil_price        REAL,
      gold_price       REAL,
      copper_price     REAL,
      dxy_price        REAL,
      days_held        REAL,
      return_pct       REAL,
      reason           TEXT,
      outcome          TEXT
    )`);

    this.db.run(`CREATE TABLE IF NOT EXISTS como_snapshots (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp        DATETIME,
      state            TEXT,
      portfolio_value  REAL,
      oil_price        REAL,
      total_return     REAL
    )`);
  }

  _persist() {
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (err) {
      console.error('[COMO] Persist error:', err.message);
    }
  }

  async logCycle(data) {
    this.db.run(
      `INSERT INTO como_cycles (
        timestamp, cycle_number, state, previous_state,
        oil_price, gold_price, copper_price, dxy_price,
        oil_mom_5d, oil_mom_20d, gold_mom_5d, copper_mom_5d, dxy_mom_5d,
        oil_above_sma20, gold_following, copper_following, dxy_strong,
        oil_gold_corr, days_in_state, portfolio_value, daily_return, total_return
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.cycle_number, data.state, data.previous_state,
        data.oil_price, data.gold_price, data.copper_price, data.dxy_price,
        data.oil_mom_5d, data.oil_mom_20d, data.gold_mom_5d, data.copper_mom_5d, data.dxy_mom_5d,
        data.oil_above_sma20 ? 1 : 0, data.gold_following ? 1 : 0,
        data.copper_following ? 1 : 0, data.dxy_strong ? 1 : 0,
        data.oil_gold_corr, data.days_in_state, data.portfolio_value,
        data.daily_return, data.total_return
      ]
    );
    this._persist();
  }

  async logTrade(data) {
    this.db.run(
      `INSERT INTO como_trades (
        timestamp, action, commodity, price, portfolio_value,
        oil_price, gold_price, copper_price, dxy_price,
        days_held, return_pct, reason, outcome
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        new Date().toISOString(), data.action, data.commodity, data.price,
        data.portfolio_value, data.oil_price, data.gold_price,
        data.copper_price, data.dxy_price, data.days_held || 0,
        data.return_pct || 0, data.reason, data.outcome || ''
      ]
    );
    this._persist();
  }

  async saveSnapshot(portfolioValue, state, oilPrice, totalReturn) {
    this.db.run(
      `INSERT INTO como_snapshots (timestamp, state, portfolio_value, oil_price, total_return)
       VALUES (?, ?, ?, ?, ?)`,
      [new Date().toISOString(), state, portfolioValue, oilPrice, totalReturn]
    );
    this._persist();
  }

  async getLatestCycle() {
    const result = this.db.exec('SELECT * FROM como_cycles ORDER BY timestamp DESC LIMIT 1');
    if (!result.length) return null;
    const { columns, values } = result[0];
    const obj = {};
    columns.forEach((col, i) => obj[col] = values[0][i]);
    return obj;
  }

  async getTradeHistory(limit = 20) {
    const result = this.db.exec(
      `SELECT * FROM como_trades ORDER BY timestamp DESC LIMIT ${limit}`
    );
    if (!result.length) return [];
    const { columns, values } = result[0];
    return values.map(row => {
      const obj = {};
      columns.forEach((col, i) => obj[col] = row[i]);
      return obj;
    });
  }

  close() {
    if (this._saveTimer) clearInterval(this._saveTimer);
    this._persist();
    this.db.close();
    console.log('[COMO] Storage closed.');
  }
}

module.exports = COMOStorageManager;

// src/cce-rme-engine.js
// CCE REIT Engine (RME) — Interest Rate Lag Exploiter
// Runs as a third engine inside the same process as CCE Crypto + Forex.
// Completely independent capital, state machine, and data feed.
// Shares only the NotificationService (prefixed [RME]).
//
// Thesis: REITs follow Fed rate cuts with a 2-6 week lag.
//         We enter after lag is confirmed, hold through rotation,
//         exit when yield spread compresses or momentum fades.

'use strict';

const { RMEStateMachine, RMESignals } = require('./rme-strategy');
const RMEDataFeed                      = require('./rme-data-feed');
const RMEStorageManager                = require('./rme-storage');

class CCERMEEngine {
  constructor(config, notifier) {
    this.config   = config;
    this.notifier = notifier;

    this.fsm      = new RMEStateMachine(config.rme?.fsm || {});
    this.signals  = new RMESignals();
    this.dataFeed = new RMEDataFeed(config);
    this.storage  = new RMEStorageManager(config.database?.path);

    this.isRunning       = false;
    this.runCount        = 0;
    this.dryRun          = config.rme?.dryRun !== false; // Default: dry run
    this.startingCapital = config.rme?.startingCapital || 300;
    this.portfolioValue  = this.startingCapital;
    this.lastReportValue = this.startingCapital;
    this.inPosition      = false;
    this.entryPrice      = null;
    this.entryDate       = null;
  }

  async start(intervalHours = 24) {
    this.isRunning = true;
    const intervalMs = intervalHours * 60 * 60 * 1000;

    await this.storage.init();

    console.log('\n[RME] 🏢 Starting CCE REIT Engine (RME)');
    console.log(`[RME] ⏱️  Check Interval: ${intervalHours}h`);
    console.log(`[RME] 💰 Starting Capital: £${this.startingCapital}`);
    console.log(`[RME] 🔧 Mode: ${this.dryRun ? 'DRY RUN' : 'LIVE ⚠️'}`);
    console.log(`[RME] 📍 Symbol: ${this.config.rme?.symbol || 'VNQ'} | Strategy: Interest Rate Lag\n`);

    await this.notifier.send(
      `<b>[RME] 🏢 CCE REIT Engine Started</b>\nCapital: £${this.startingCapital}\nSymbol: ${this.config.rme?.symbol || 'VNQ'}\nMode: ${this.dryRun ? 'DRY RUN' : '⚠️ LIVE'}`,
      'info'
    );

    while (this.isRunning) {
      await this.runCycle();
      if (!this.isRunning) break;

      const nextRun = new Date(Date.now() + intervalMs);
      console.log(`[RME] ⏳ Next run: ${nextRun.toLocaleString()}`);
      await this._sleep(intervalMs);
    }

    console.log('[RME] 🛑 RME engine loop exited.');
  }

  stop() {
    console.log('[RME] 🛑 Stopping CCE REIT Engine...');
    this.isRunning = false;
    this.storage.close();
  }

  async runCycle() {
    try {
      this.runCount++;
      console.log(`\n[RME] ${'─'.repeat(60)}`);
      console.log(`[RME] 🔄 RUN #${this.runCount} — ${new Date().toISOString()}`);
      console.log(`[RME]    State: ${this.fsm.currentState} — ${this.fsm.getStateSummary()}`);
      console.log(`[RME] ${'─'.repeat(60)}`);

      // 1. Fetch market data
      const market = await this.dataFeed.getMarketData();

      if (market.error) {
        console.warn('[RME] ⚠️  Data feed error — skipping cycle');
        return;
      }

      // 2. Calculate signals
      const sig = this.signals.getAllSignals(market);

      console.log(`[RME] 🏢 ${market.symbol}: $${market.price.toFixed(2)}`);
      console.log(`[RME] 🏦 Fed Rate: ${market.fedRate}% | 10Y Treasury: ${market.treasuryYield.toFixed(2)}%`);
      console.log(`[RME] 📊 Yield Spread: ${market.yieldSpread.toFixed(2)}% | RSI: ${sig.rsi}`);
      console.log(`[RME] 📈 Momentum (4w): ${market.momentum4w.toFixed(1)}% | Days since Fed decision: ${market.daysSinceDecision}`);
      console.log(`[RME] 🔑 Fed: ${market.fedCutting ? '✂️ Cutting' : market.fedHiking ? '📈 Hiking' : '⏸️ Holding'} | Treasury: ${market.treasuryFalling ? '📉 Falling' : market.treasuryRising ? '📈 Rising' : '➡️ Stable'}`);

      // 3. Build FSM context
      const context = {
        price:             market.price,
        fedRate:           market.fedRate,
        fedCutting:        market.fedCutting,
        fedEasing:         market.fedEasing,
        fedHolding:        market.fedHolding,
        fedHiking:         market.fedHiking,
        fedTrend6m:        market.fedTrend6m,
        daysSinceDecision: market.daysSinceDecision,
        treasuryYield:     market.treasuryYield,
        treasuryFalling:   market.treasuryFalling,
        treasuryRising:    market.treasuryRising,
        yieldSpread:       market.yieldSpread,
        spreadFavourable:  market.spreadFavourable,
        aboveSma20:        market.aboveSma20,
        aboveSma50:        market.aboveSma50,
        momentum4w:        market.momentum4w,
        sma50:             market.sma50,
        signals:           sig
      };

      // 4. Evaluate FSM transition
      const transition = this.fsm.evaluateTransition(context);

      if (transition.transitioned) {
        console.log(`\n[RME] 📝 STATE: ${transition.from} → ${transition.to}`);
        console.log(`[RME]    Reason: ${transition.reason}`);
        await this._handleTransition(transition, market, sig);
      } else {
        console.log(`[RME] ✅ State: ${this.fsm.currentState} (no change)`);
        if (this.inPosition) {
          const unrealised = this.entryPrice
            ? (((market.price - this.entryPrice) / this.entryPrice) * 100).toFixed(2)
            : '0.00';
          console.log(`[RME]    Position: LONG ${market.symbol} @ $${this.entryPrice?.toFixed(2)} | Unrealised: ${unrealised}%`);
        }
      }

      // 5. Log cycle
      const daysInState  = this.fsm.getDaysInState();
      const totalReturn  = ((this.portfolioValue - this.startingCapital) / this.startingCapital) * 100;
      const dailyReturn  = ((this.portfolioValue - this.lastReportValue) / this.lastReportValue) * 100;

      await this.storage.logCycle({
        cycle_number:      this.runCount,
        state:             this.fsm.currentState,
        previous_state:    this.fsm.previousState,
        price:             market.price,
        fed_rate:          market.fedRate,
        treasury_yield:    market.treasuryYield,
        yield_spread:      market.yieldSpread,
        momentum_4w:       market.momentum4w,
        rsi:               sig.rsi,
        days_in_state:     daysInState,
        portfolio_value:   this.portfolioValue,
        daily_return:      dailyReturn,
        total_return:      totalReturn,
        fed_cutting:       market.fedCutting,
        fed_easing:        market.fedEasing,
        spread_favourable: market.spreadFavourable
      });

      // 6. Weekly report every 7 cycles (7 days at 24h interval)
      if (this.runCount > 0 && this.runCount % 7 === 0) {
        await this._weeklyReport(market);
      }

      console.log(`[RME] ${'─'.repeat(60)}\n`);

    } catch (err) {
      console.error('[RME] ❌ Cycle error:', err.message);
      await this.notifier.send(
        `<b>[RME] ⚠️ Cycle Error</b>\n${err.message}`,
        'error'
      );
    }
  }

  // ============================================================================
  // TRANSITION HANDLERS
  // ============================================================================

  async _handleTransition(transition, market, sig) {
    const { from, to, reason } = transition;

    switch (to) {

      case 'WATCHING': {
        const msg = [
          `<b>[RME] 👀 WATCHING — Rate Cut Detected</b>`,
          ``,
          `Fed Rate: ${market.fedRate}%`,
          `6m Trend: ${market.fedTrend6m.toFixed(2)}%`,
          `10Y Treasury: ${market.treasuryYield.toFixed(2)}%`,
          `${market.symbol}: $${market.price.toFixed(2)}`,
          ``,
          `Monitoring for lag confirmation (7-42 days)`,
          `Reason: ${reason}`
        ].join('\n');
        await this.notifier.send(msg, 'info');
        break;
      }

      case 'ENTERING': {
        this.inPosition = true;
        this.entryPrice = market.price;
        this.entryDate  = new Date();

        const msg = [
          `<b>[RME] 🏢 ENTERING — Deploy into REITs</b>`,
          ``,
          `<b>Action:</b> BUY ${market.symbol}`,
          `<b>Entry:</b>  $${market.price.toFixed(2)}`,
          `<b>Capital:</b> £${this.portfolioValue.toFixed(2)}`,
          ``,
          `<b>Fed Rate:</b> ${market.fedRate}%`,
          `<b>Treasury:</b> ${market.treasuryYield.toFixed(2)}%`,
          `<b>Yield Spread:</b> ${market.yieldSpread.toFixed(2)}%`,
          `<b>Days since Fed decision:</b> ${market.daysSinceDecision}`,
          ``,
          `${this.dryRun ? '🔵 DRY RUN — No action needed' : `⚠️ BUY ${market.symbol} on your broker NOW`}`
        ].join('\n');

        await this.notifier.send(msg, 'trade');

        await this.storage.logTrade({
          action:              'BUY',
          symbol:              market.symbol,
          price:               market.price,
          portfolio_value:     this.portfolioValue,
          fed_rate:            market.fedRate,
          treasury_yield:      market.treasuryYield,
          yield_spread:        market.yieldSpread,
          days_since_decision: market.daysSinceDecision,
          reason
        });
        break;
      }

      case 'HOLDING':
        // Transition from ENTERING to HOLDING — no action needed
        console.log(`[RME] ✅ Position active — monitoring`);
        break;

      case 'EXITING': {
        const holdDays = this.entryDate
          ? Math.round((Date.now() - this.entryDate.getTime()) / 86400000)
          : 0;

        const returnPct = this.entryPrice
          ? (((market.price - this.entryPrice) / this.entryPrice) * 100)
          : 0;

        const outcome = returnPct > 0 ? 'WIN' : returnPct < 0 ? 'LOSS' : 'BREAK EVEN';
        const emoji   = returnPct > 0 ? '✅' : returnPct < 0 ? '❌' : '➖';

        // Update portfolio
        this.portfolioValue = this.portfolioValue * (1 + returnPct / 100);

        const totalReturn = ((this.portfolioValue - this.startingCapital) / this.startingCapital) * 100;

        const msg = [
          `<b>[RME] ${emoji} EXIT — ${outcome}</b>`,
          ``,
          `Entry:  $${this.entryPrice?.toFixed(2)}`,
          `Exit:   $${market.price.toFixed(2)}`,
          `Return: ${returnPct >= 0 ? '+' : ''}${returnPct.toFixed(2)}%`,
          `Hold:   ${holdDays} days`,
          ``,
          `Portfolio: £${this.portfolioValue.toFixed(2)}`,
          `Total Return: ${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(2)}%`,
          ``,
          `${this.dryRun ? '🔵 DRY RUN' : `⚠️ SELL ${market.symbol} on your broker NOW`}`,
          `Reason: ${reason}`
        ].join('\n');

        await this.notifier.send(msg, returnPct > 0 ? 'trade' : 'warning');

        await this.storage.logTrade({
          action:              'SELL',
          symbol:              market.symbol,
          price:               market.price,
          portfolio_value:     this.portfolioValue,
          fed_rate:            market.fedRate,
          treasury_yield:      market.treasuryYield,
          yield_spread:        market.yieldSpread,
          days_since_decision: holdDays,
          reason,
          outcome: outcome.toLowerCase()
        });

        this.inPosition = false;
        this.entryPrice = null;
        this.entryDate  = null;
        break;
      }

      case 'DORMANT': {
        if (from !== 'DORMANT') {
          await this.notifier.send(
            `<b>[RME] 😴 Returning to DORMANT</b>\nReason: ${reason}`,
            'info'
          );
        }
        break;
      }
    }
  }

  // ============================================================================
  // REPORTING
  // ============================================================================

  async _weeklyReport(market) {
    const totalReturn  = ((this.portfolioValue - this.startingCapital) / this.startingCapital) * 100;
    const periodReturn = ((this.portfolioValue - this.lastReportValue) / this.lastReportValue) * 100;

    const msg = [
      `<b>[RME] 📊 Weekly Report</b>`,
      ``,
      `Portfolio: £${this.portfolioValue.toFixed(2)}`,
      `Week: ${periodReturn >= 0 ? '+' : ''}${periodReturn.toFixed(2)}%`,
      `Total: ${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(2)}%`,
      ``,
      `${market.symbol}: $${market.price.toFixed(2)}`,
      `Fed Rate: ${market.fedRate}%`,
      `Treasury: ${market.treasuryYield.toFixed(2)}%`,
      `Spread: ${market.yieldSpread.toFixed(2)}%`,
      `State: ${this.fsm.currentState}`,
      `Cycles: ${this.runCount}`
    ].join('\n');

    await this.notifier.send(msg, 'report');
    this.lastReportValue = this.portfolioValue;

    await this.storage.saveSnapshot(
      this.portfolioValue,
      this.fsm.currentState,
      market.price,
      totalReturn
    );
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = CCERMEEngine;
